#ifndef T_DLG_H
#define T_DLG_H

#include <QDialog>

namespace Ui {
class T_Dlg;
}

class T_Dlg : public QDialog
{
    Q_OBJECT

public:
    explicit T_Dlg(QWidget *parent = 0);
    ~T_Dlg();

private slots:
    void on_BTN_G_PARA_clicked();

    void on_BTN_S_PARA_clicked();

private:
    Ui::T_Dlg *ui;
};

#endif // T_DLG_H
