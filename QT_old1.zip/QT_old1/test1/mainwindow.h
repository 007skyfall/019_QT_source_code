#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QPushButton>
#include <QLabel>

#include "qimageviewer.h"
#include "qIrDev.h"

#include "../include/ir_types.h"
#include "../include/ir_errinfo.h"
#include "../include/ir_cam.h"


#define TEST_EVENT QEvent::User + 100

typedef unsigned short WORD;
typedef	int32_t			BOOL;



namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    QPushButton *m_BtnOpen;
    QPushButton *m_BtnStart;
    QPushButton *m_BtnStop;
    QPushButton *m_BtnClose;

    QPushButton *m_Btn8bits;
    QPushButton *m_Btn14bits;

    QPushButton *m_BtnPalette;

    QPushButton *m_BtnT;


    QLabel *m_label1;
    QLabel *m_label2;
    QLabel *m_label3;

    QString m_strIp;


    QImageViewer *m_ImageView;

    BYTE *m_pPalette;
    BYTE *m_buf;

    ir_video_palette_t m_VideoPalette;
    CqIrDev* m_pDev;
    int m_nStarted = 0;


    BOOL m_bReadPtTOn = FALSE;		//点取温度
    BOOL m_bIs14BitsT = FALSE;		//14位数据是温度数据

    void OnReadPointT() ;
protected:

    void timerEvent( QTimerEvent *event );

    int m_nTimerId = 0;

    int m_nTimerId2 = 0;
private:
    Ui::MainWindow *ui;

public slots:

    void UpdateImg();

    void OnClickedOpen();
    void OnClickedStart();
    void OnClickedStop();
    void OnClickedClose();

    void OnClicked8bits();
    void OnClicked14bits();
    void OnClickedPalette();
    void OnClickedT();

protected:
     void customEvent(QEvent *event);

public:

     void postMessage();

     int m_nIndx_Palette;
     //设置调色板
     void SetPalette(QString fileName);

public:

};


#endif // MAINWINDOW_H
