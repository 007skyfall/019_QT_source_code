#include "palettedlg.h"
#include "ui_palettedlg.h"

PaletteDlg::PaletteDlg(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::PaletteDlg)
{
    ui->setupUi(this);

    m_nIndex = 0;
}

PaletteDlg::~PaletteDlg()
{
    delete ui;
}
void PaletteDlg::setPalette(int nIndex)
{
    if(nIndex == 1)
    {
        ui->radioButton->setChecked(true);
    }
    else if(nIndex == 2)
    {
        ui->radioButton_2->setChecked(true);
    }
    else if(nIndex == 3)
    {
        ui->radioButton_3->setChecked(true);
    }
    else if(nIndex == 4)
    {
        ui->radioButton_4->setChecked(true);
    }
    else if(nIndex == 5)
    {
        ui->radioButton_5->setChecked(true);
    }
    else if(nIndex == 6)
    {
        ui->radioButton_6->setChecked(true);
    }
    else if(nIndex == 7)
    {
        ui->radioButton_7->setChecked(true);
    }
    else if(nIndex == 8)
    {
        ui->radioButton_8->setChecked(true);
    }
    else if(nIndex == 9)
    {
        ui->radioButton_9->setChecked(true);
    }
    else if(nIndex == 10)
    {
        ui->radioButton_10->setChecked(true);
    }
    else if(nIndex == 11)
    {
        ui->radioButton_11->setChecked(true);
    }
    else if(nIndex == 12)
    {
        ui->radioButton_12->setChecked(true);
    }
}

QString PaletteDlg::GetFileName()
{
    if(ui->radioButton->isChecked())
    {
        m_nIndex = 1;
        return ui->radioButton->text();
    }
    if(ui->radioButton_2->isChecked())
    {
         m_nIndex = 2;
        return ui->radioButton_2->text();
    }
    if(ui->radioButton_3->isChecked())
    {
         m_nIndex = 3;
        return ui->radioButton_3->text();
    }
    if(ui->radioButton_4->isChecked())
    {
         m_nIndex = 4;
        return ui->radioButton_4->text();
    }
    if(ui->radioButton_5->isChecked())
    {
         m_nIndex = 5;
        return ui->radioButton_5->text();
    }
    if(ui->radioButton_6->isChecked())
    {
         m_nIndex = 6;
        return ui->radioButton_6->text();
    }
    if(ui->radioButton_7->isChecked())
    {
         m_nIndex = 7;
        return ui->radioButton_7->text();
    }

    if(ui->radioButton_8->isChecked())
    {
         m_nIndex = 8;
        return ui->radioButton_8->text();
    }
    if(ui->radioButton_9->isChecked())
    {
         m_nIndex = 9;
        return ui->radioButton_9->text();
    }
    if(ui->radioButton_10->isChecked())
    {
         m_nIndex = 10;
        return ui->radioButton_10->text();
    }
    if(ui->radioButton_11->isChecked())
    {
         m_nIndex = 11;
        return ui->radioButton_11->text();
    }
    if(ui->radioButton_12->isChecked())
    {
         m_nIndex = 12;
        return ui->radioButton_12->text();
    }

}
