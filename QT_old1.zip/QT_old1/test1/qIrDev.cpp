// qIrDev.cpp: implementation of the CqIrDev class.
//
//////////////////////////////////////////////////////////////////////

#include "mainwindow.h"

#include "qIrDev.h"
#include "ImgProc.h"

#include <QDebug>
#include <QMutex>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

extern MainWindow *g_MainWindow ;

//(1)

extern stMultiMinMaxPara g_stMultiMinMaxPara;
extern stMultiMinMax g_stMultiMinMax;
extern stSecondMinMax g_stSecondMinMax;


QMutex g_mutex;

//(2)
#ifdef _WIN32
unsigned int __stdcall wait_img_thread(void *p)
#else
void * wait_img_thread(void *p)
#endif
{
	CqIrDev* pIrDev =(CqIrDev*)p;
	ir_dev_handle_t ir_handle =pIrDev->m_ir_handle;
	char lpStr[128];

    qDebug("wait_img_thread*********************");

	while (pIrDev->m_capture_running == 1)
	{
		ir_img_buf_t img;
		//int ret = ir_read_img(ir_handle,   &img,  5);
		int ret = ir_wait_buf(ir_handle,   &img,  5);
		if ( (ret == 0) && (pIrDev->m_capture_running == 1) )
		{

			if(pIrDev->m_bIdle)
			{
				if( (img.video_fmt.fourcc==IR_VIDEO_R080) || (img.video_fmt.fourcc==IR_VIDEO_R140) ||  (img.video_fmt.fourcc==IR_VIDEO_R08J) || (img.video_fmt.fourcc==IR_VIDEO_R14J))
				{
                    //CSingleLock lock(&pIrDev->m_critDIB, TRUE);
                    g_mutex.lock();
					//(1)
                    //if(pIrDev->m_hDib==NULL)
                    if(pIrDev->m_nMalloc==0)
					{
						memcpy(&pIrDev->m_fmt,&img.video_fmt,sizeof(ir_video_format_t));
						pIrDev->MkNewBuf(img.video_fmt.rect.width, img.video_fmt.rect.height,img.video_fmt.fourcc);
					}
					else if( (pIrDev->m_fmt.rect.width != img.video_fmt.rect.width) || (pIrDev->m_fmt.rect.height != img.video_fmt.rect.height) || (pIrDev->m_fmt.fourcc != img.video_fmt.fourcc))	//Í¼Ïñ´óÐ¡±ä»¯ÁË
					{
						pIrDev->FreeAllBuf();
						pIrDev->MkNewBuf(img.video_fmt.rect.width, img.video_fmt.rect.height,img.video_fmt.fourcc);
					}
					
					//(2)
					memcpy(&pIrDev->m_fmt,&img.video_fmt,sizeof(ir_video_format_t));


                    //if(pIrDev->m_hDib !=NULL)
                    if(pIrDev->m_nMalloc!=0)
					{
						//(3)
                /*		if(pIrDev->m_bForceChangePalette)
						{
							ChangePalette(pIrDev->m_hDib,256,pIrDev->m_pPalette);
							ChangePalette(pIrDev->m_hDibPal,256,pIrDev->m_pPalette);
							pIrDev->m_bForceChangePalette = FALSE;
						}

						//(4)
						if( (img.video_fmt.fourcc==IR_VIDEO_R08J) || (img.video_fmt.fourcc==IR_VIDEO_R14J))
						{

							JpegBuf2DibEx(&pIrDev->m_hDib,img.data,img.video_fmt.img_size);

							sprintf(lpStr,"Jpeg size=%d\n",img.video_fmt.img_size);
							OutputDebugString(lpStr);

							//(3)
							if(pIrDev->m_pUserWin!=NULL)
								pIrDev->m_pUserWin->PostMessage(pIrDev->m_nUserMessage, 0, 0);

						}
                        else
                    */
                        if(img.video_fmt.fourcc==IR_VIDEO_R140)
						{
							//(1)
							if(pIrDev->m_pImg14!=NULL)
								memcpy(pIrDev->m_pImg14,img.data,img.video_fmt.rect.width*img.video_fmt.rect.height*sizeof(unsigned short));


							FindMultiMinMax((WORD*)pIrDev->m_pImg14, img.video_fmt.rect.width, img.video_fmt.rect.height, &g_stMultiMinMax);
                            //FindSecondMinMax((WORD*) pIrDev->m_pImg14, img.video_fmt.rect.width, img.video_fmt.rect.height, &g_stMultiMinMaxPara, &g_stMultiMinMax, &g_stSecondMinMax);

							pIrDev->m_width = img.video_fmt.rect.width;
                            pIrDev->m_height = img.video_fmt.rect.height;
                            //(2)
                            //LPSTR lpbi = (LPSTR )GlobalLock(pIrDev->m_hDib);
                            //LPSTR pImg = FindDIBBits(lpbi);

							//(3)
							ImgPara aRAW;
							ImgPara aIMG;

							aRAW.nWidth=img.video_fmt.rect.width;
							aRAW.nHeight=img.video_fmt.rect.height;
							aRAW.wBpps=14;
							aRAW.wChannel=1;
							aRAW.pData=img.data;


							aIMG.nWidth=img.video_fmt.rect.width;
							aIMG.nHeight=img.video_fmt.rect.height;
							aIMG.wBpps=8;
							aIMG.wChannel=1;
                            aIMG.pData=pIrDev->m_pImg8;

                            BOOL bOK = PlatEqual_2( &aRAW,  &aIMG, 200,255,0,FALSE);

                            if(g_MainWindow != NULL)
                            {

                                    //qDebug("14bit");
                                g_MainWindow->postMessage();
                            }

							//(4)
                            //GlobalUnlock(pIrDev->m_hDib);

							//(5)
                            //if(pIrDev->m_pUserWin!=NULL)
                                //pIrDev->m_pUserWin->PostMessage(pIrDev->m_nUserMessage, 0, 0);

                            // pIrDev->NewImgData();
						}
						else
						{
							//(1)
							if(pIrDev->m_pImg8!=NULL)
								memcpy(pIrDev->m_pImg8,img.data,img.video_fmt.rect.width*img.video_fmt.rect.height*sizeof(unsigned char));


                            pIrDev->m_width = img.video_fmt.rect.width;
                            pIrDev->m_height = img.video_fmt.rect.height;

                    /*		//(2)
                            //LPSTR lpbi = (LPSTR )GlobalLock(pIrDev->m_hDib);
                            //LPSTR pImg = FindDIBBits(lpbi);

							//(3)
							//memcpy(pImg,img.data,img.video_fmt.img_size);
							int nLineBits=img.video_fmt.rect.width;
							int nPosDest = nLineBits*(img.video_fmt.rect.height-1);
							int nPosSrc =0; 
							for(int i=0;i<img.video_fmt.rect.height;i++)
							{
								memcpy(pImg+nPosDest,img.data+nPosSrc,nLineBits);
								nPosDest-=nLineBits;
								nPosSrc+=nLineBits;
							}
							GlobalUnlock(pIrDev->m_hDib);

							//(4)
							if(pIrDev->m_pUserWin!=NULL)
								pIrDev->m_pUserWin->PostMessage(pIrDev->m_nUserMessage, 0, 0);
                     */

                            //pIrDev->NewImgData();
                            if(g_MainWindow != NULL)
                            {
                                        //qDebug("8bit");
                                g_MainWindow->postMessage();
                            }
						}

					}
                    g_mutex.unlock();
				}
			}
		}
		ir_queue_buf(ir_handle);
	}

	pIrDev->m_capture_running = 2;		//Ïß³ÌÍË³ö±êÖ¾

	return 0;
}

//(3)
void CqIrDev::MkNewBuf(int nWid,int nHei,ir_video_palette_t pal)
{
/*	if(m_hDib==NULL)
	{
		if((pal==IR_VIDEO_R080) || (pal==IR_VIDEO_R140))
		{
			m_hDib=CreateDib(nWid, nHei,8);

			if(m_hDib!=NULL)
				ChangePalette(m_hDib,256,m_pPalette);
		}
		else
		{
			m_hDib=CreateDib(nWid, nHei,24);
		}
	}
 */
    if(m_nMalloc==0)
    {
        m_nMalloc = 1;
    }

	if(m_pImg14==NULL)
	{
		m_pImg14=malloc(nWid*nHei*sizeof(unsigned short));
	}
	if(m_pImg8==NULL)
	{
		m_pImg8=malloc(nWid*nHei*sizeof(unsigned char));
	}
}

void CqIrDev::FreeAllBuf()
{
    /*if(m_hDib != NULL)
	{
		FreeDIBHandle(m_hDib);
		m_hDib=NULL;
	}
    */
    if(m_nMalloc!=0)
    {
        m_nMalloc = 0;
    }
	if(m_pImg14!=NULL)
	{
		free(m_pImg14);
		m_pImg14=NULL;
	}
	if(m_pImg8!=NULL)
	{
		free(m_pImg8);
		m_pImg8=NULL;
	}
}



//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CqIrDev::CqIrDev()
{
	//(1)
	m_ir_handle = NULL;

	//(2)
	m_bIdle = TRUE;

	//(3)
	m_hDib = NULL;

	//(4)
	memset(&m_fmt,0,sizeof(ir_video_format_t));

	//(5)
	memset(&m_DevInfo,0,sizeof(ir_dev_info_t));

	//(6)
	m_capture_running = 0;
    m_npthread = 0;
    //m_hCap_thread = NULL;
    //mThread_id = 0;

	//(7)
	m_pImg14=NULL;
	m_pImg8=NULL;

    m_nMalloc = 0;

	//(8)
/*	m_pUserWin = NULL;
	m_nUserMessage =0;

	//(9)
	int i=0;
	int nPalNum=256;
	m_pPalette=new PALETTEENTRY[nPalNum];
	if(m_pPalette==NULL)
		return;

	for(i=0;i<nPalNum;i++)
	{
		m_pPalette->peRed=i;
		m_pPalette->peGreen=i;
		m_pPalette->peBlue=i;
		m_pPalette->peFlags=0;
	}

	//(11)
	m_bForceChangePalette = FALSE;

	//(12)
	m_hDibPal = NULL;

	int nPalWid=16;
	int nPalHei=256;

	m_hDibPal=CreateDib(nPalWid, nPalHei, 8);
	LPSTR lpbi = (LPSTR )GlobalLock(m_hDibPal);
	LPSTR pImg = FindDIBBits(lpbi);
	for(i=0;i<nPalHei;i++)
	{
		memset(pImg+i*nPalWid,i,nPalWid);
	}
	GlobalUnlock(m_hDibPal);
*/
	//(13)
	//m_nBitsBak = 0;

	//(14)
	m_LastVideoFourcc = -1;

	//(15)
	m_nLastImgID =0;


	init_FindMultiMinMax(&g_stMultiMinMaxPara, &g_stMultiMinMax, &g_stSecondMinMax);
}


CqIrDev::~CqIrDev()
{
	StopDev();
	CloseDev();

	FreeAllBuf();
/*	if(m_hDibPal != NULL)
	{
		FreeDIBHandle(m_hDibPal);
		m_hDibPal=NULL;
	}

	if(m_pPalette!=NULL)
	{
		delete m_pPalette;
		m_pPalette = NULL;
	}
*/
}


int CqIrDev::OpenDev(ir_dev_info_t *pdev, ir_net_status_callback_func_t callback_func, void *user_data)
{
	if (m_ir_handle != NULL)
	{
		return IR_E_OPENED;
	}

	m_DevInfo = *pdev;

	int	ret = ir_open(&m_ir_handle,  pdev, (ir_net_status_callback_func_t)callback_func,(void*)user_data);

	return ret;
}
/*
int CqIrDev::retryOpenDev(ir_dev_info_t *pdev, ir_net_status_callback_func_t callback_func, void *user_data)
{
	if (m_ir_handle != NULL)
	{
		return IR_E_OPENED;
	}
	if(pdev == NULL)
	{
		return IR_E_INVALID_PARAMETER;
	}

	//(0)
	eth_conf_t m_device[MAX_DEV_NUM];
	memset(&m_device[0],0,sizeof(eth_conf_t)*MAX_DEV_NUM);

	//(1)
	int nDevNum=0;
	int ret = ir_GetIP(m_device,(int32*)&nDevNum);
	if(ret != 0)
	{
		return IR_E_FAILURE;
	}

	if(nDevNum<=0)
	{
		return IR_E_NO_DEVICE;	//No Device
	}

	//(2)try match IP
	unsigned char *p;
    p = (unsigned char*)&(pdev->ip_addr); 
	char lpStr[64]; 
	sprintf(lpStr,"%u.%u.%u.%u",p[0],p[1],p[2],p[3]); 

	//(3)
	int nFinded=0;
	int i=0;
	for(i=0;i<nDevNum;i++)
	{
		if(strcmp(lpStr,m_device[i].lpIP)==0)
		{
			nFinded=1;
			break;
		}
	}
	//(4)
	if(nFinded==1)
	{
		ret = ir_reboot_UDP(&m_device[i]);
		if(ret == IR_E_OK)
		{
			//(4.1)
			for(i=0;i<17;i++)	//µÈ´ýÏµÍ³ÖØÆô17Ãë,
			{
				Sleep(1000);
#if 0
				MSG message;
				while (::PeekMessage( &message, NULL, 0, 0, PM_REMOVE ) ) 
				{
					::TranslateMessage( &message );
					::DispatchMessage(  &message );
				}
#endif
			}

			//(4.2)
			m_DevInfo = *pdev;
			ret = ir_open(&m_ir_handle,  pdev, (ir_net_status_callback_func_t)callback_func,(void*)user_data);
		}
	}
	else
		ret = IR_E_NO_DEVICE;	//IPÃ»ÓÐÆ¥Åä

	return ret;
}
*/

int CqIrDev::DevCtl(ir_ctl_code_t ctl_code,  void *ctl_para)
{
	int nRet = IR_E_INVALID_HANDLE;
	if(m_ir_handle!=NULL)
	{
		nRet = ir_ctl( m_ir_handle ,   ctl_code,  ctl_para);

		if(ctl_code == SET_CAM_VIDEO_FORCC)	//±¸·Ýµ±Ç°µÄÍ¼Ïñ¸ñÊ½. µ±»Ö¸´Á¬½ÓÊ±Ê¹ÓÃ¡£
		{
			if(nRet == 0)
				m_LastVideoFourcc = *(int*)ctl_para;
		}
		if(ctl_code == GET_CAM_VIDEO_FORCC)
		{
			if(nRet == 0)
				m_LastVideoFourcc = *(int*)ctl_para;
		}
	}

	return nRet;
}

int CqIrDev::CloseDev()
{
	int rc=-1;
	if(m_ir_handle != NULL)
	{
		StopDev();

		rc=ir_close(m_ir_handle);
		m_ir_handle = NULL;
	}

	return rc;
}
#if 0
int CqIrDev::GetLastRdyBuf() 
{
	ir_img_buf_t img;
	char lpStr[128];
	
	int ret = ir_get_last_rdy_buf(m_ir_handle, &img);
	//sprintf(lpStr,"LastImgID=%d\n",img.time.tv_sec);
	//OutputDebugString(lpStr);
	if(ret == 0)
	{
		if(m_nLastImgID != img.time.tv_sec)		//Í¼ÏñÐòºÅ
		{
			if( (img.video_fmt.fourcc==IR_VIDEO_R080) || (img.video_fmt.fourcc==IR_VIDEO_R140) ||  (img.video_fmt.fourcc==IR_VIDEO_R08J) || (img.video_fmt.fourcc==IR_VIDEO_R14J))
			{
				//(1)
				if(m_hDib==NULL)
				{
					memcpy(&m_fmt,&img.video_fmt,sizeof(ir_video_format_t));
					MkNewBuf(img.video_fmt.rect.width, img.video_fmt.rect.height,img.video_fmt.fourcc);
				}
				else if( (m_fmt.rect.width != img.video_fmt.rect.width) || (m_fmt.rect.height != img.video_fmt.rect.height) || (m_fmt.fourcc != img.video_fmt.fourcc))	//Í¼Ïñ´óÐ¡±ä»¯ÁË
				{
					FreeAllBuf();
					MkNewBuf(img.video_fmt.rect.width, img.video_fmt.rect.height,img.video_fmt.fourcc);
				}
				
				//(2)
				memcpy(&m_fmt,&img.video_fmt,sizeof(ir_video_format_t));
				
				
				if(m_hDib !=NULL)
				{
					//(3)
					if(m_bForceChangePalette)
					{
						ChangePalette(m_hDib,256,m_pPalette);
						ChangePalette(m_hDibPal,256,m_pPalette);
						m_bForceChangePalette = FALSE;
					}
					
					//(4)
					if( (img.video_fmt.fourcc==IR_VIDEO_R08J) || (img.video_fmt.fourcc==IR_VIDEO_R14J))
					{
						
						JpegBuf2DibEx(&m_hDib,img.data,img.video_fmt.img_size);
						
						sprintf(lpStr,"Jpeg size=%d\n",img.video_fmt.img_size);
						OutputDebugString(lpStr);
						
						//(3)
						if(m_pUserWin!=NULL)
							m_pUserWin->PostMessage(m_nUserMessage, 0, 0);
						
					}
					else if(img.video_fmt.fourcc==IR_VIDEO_R140)
					{
						//(1)
						if(m_pImg14!=NULL)
							memcpy(m_pImg14,img.data,img.video_fmt.rect.width*img.video_fmt.rect.height*sizeof(unsigned short));
						//(2)
						LPSTR lpbi = (LPSTR )GlobalLock(m_hDib);
						LPSTR pImg = FindDIBBits(lpbi);
						
						//(3)
						ImgPara aRAW;
						ImgPara aIMG;
						
						aRAW.nWidth=img.video_fmt.rect.width;
						aRAW.nHeight=img.video_fmt.rect.height;
						aRAW.wBpps=14;
						aRAW.wChannel=1;
						aRAW.pData=img.data;
						
						
						aIMG.nWidth=img.video_fmt.rect.width;
						aIMG.nHeight=img.video_fmt.rect.height;
						aIMG.wBpps=8;
						aIMG.wChannel=1;
						aIMG.pData=pImg;
						
						BOOL bOK = PlatEqual_2( &aRAW,  &aIMG, 200,255,0,TRUE);
						
						//(4)
						GlobalUnlock(m_hDib);
						
						//(5)
						if(m_pUserWin!=NULL)
							m_pUserWin->PostMessage(m_nUserMessage, 0, 0);
					}
					else
					{
						//(1)
						if(m_pImg8!=NULL)
							memcpy(m_pImg8,img.data,img.video_fmt.rect.width*img.video_fmt.rect.height*sizeof(unsigned char));
						
						//(2)
						LPSTR lpbi = (LPSTR )GlobalLock(m_hDib);
						LPSTR pImg = FindDIBBits(lpbi);
						
						//(3)
						//memcpy(pImg,img.data,img.video_fmt.img_size);
						int nLineBits=img.video_fmt.rect.width;
						int nPosDest = nLineBits*(img.video_fmt.rect.height-1);
						int nPosSrc =0; 
						for(int i=0;i<img.video_fmt.rect.height;i++)
						{
							memcpy(pImg+nPosDest,img.data+nPosSrc,nLineBits);
							nPosDest-=nLineBits;
							nPosSrc+=nLineBits;
						}
						GlobalUnlock(m_hDib);
						
						//(4)
						if(m_pUserWin!=NULL)
							m_pUserWin->PostMessage(m_nUserMessage, 0, 0);
					}

				}
			}
			m_nLastImgID = img.time.tv_sec;
		}
	}
	
	//£¡
	ir_queue_buf(m_ir_handle);
	return 0;
}
#endif


//Æô¶¯Éè±¸²É¼¯Í¼Ïñ¡£²É¼¯µÄÍ¼Ïñ¿ÉÒÔÓÃir_get_last_rdy_buf²éÑ¯µ½¡£
int CqIrDev::StartCapImg(void *user_data) 
{
	int rc =0;
	if(m_ir_handle != NULL)
	{
		rc = ir_start_video(m_ir_handle,user_data);
		if(rc != 0)
		{
			OutputDebugString("CqIrDev: ir_start_video failed\n");
		}
	}	
	return rc;
}

//¿ØÖÆÉè±¸Í£Ö¹²É¼¯Í¼Ïñ
int CqIrDev::StopCapImg() 
{
	int rc=0;

	if(m_ir_handle!=NULL)
	{
		//(1)
		rc = ir_stop_video(m_ir_handle);
	}
	return rc;
}

//Æô¶¯Éè±¸²É¼¯Í¼Ïñ¡¢Æô¶¯Ïß³Ì»ñÈ¡Í¼Ïñ
int CqIrDev::StartDev(void *user_data) 
{
	int rc =-1;
    if(m_npthread == 1)
    {

        return IR_E_STARTED;
    }

	if(m_ir_handle != NULL)
	{
		rc = ir_start_video(m_ir_handle,user_data);
		if(rc != 0)
		{
			OutputDebugString("CqIrDev: ir_start_video failed\n");
			return rc;
		}

		m_capture_running=1;	// capture start flag 
/*		m_hCap_thread = (HANDLE)_beginthreadex(NULL,
			0,
			wait_img_thread,
			this,
			0,
			&(mThread_id));

		if(m_hCap_thread ==NULL)
		{
			OutputDebugString("CREATE THREAD FAILED\n");
			m_capture_running=0;
			//CloseHandle(m_hCap_thread);
			m_hCap_thread=NULL;
			mThread_id=0;
			rc = ir_stop_video(m_ir_handle);
			return IR_E_FAILURE;
		}
  */

        if (pthread_create(&m_tid, NULL,wait_img_thread,(void *)this))
        {
            //			handle_close(m_tid);

            rc = ir_stop_video(m_ir_handle);

            OutputDebugString("******pthread_create is err!");
            return IR_E_FAILURE;
        }

        m_npthread = 1;
	}
	return rc;
}

//¿ØÖÆÉè±¸Í£Ö¹²É¼¯£¬¹Ø±ÕÏß³Ì
int CqIrDev::StopDev() 
{
	int rc=0;
    if(m_npthread == 0)
            return IR_E_STOPED;

	if(m_ir_handle!=NULL)
	{
		//(1)
		rc = ir_stop_video(m_ir_handle);

		//(2)
		m_capture_running=0;
/*		WaitForSingleObject(m_hCap_thread,INFINITE);

		m_capture_running=0;
		CloseHandle(m_hCap_thread);
		m_hCap_thread=NULL;
		mThread_id=0;
 */
        pthread_join(m_tid,NULL);


        m_capture_running=0;

        m_npthread = 0;
	}
	return rc;
}

int CqIrDev::Get14BitsV(int x,int y)
{
	int nV =0;

	if(m_pImg14!=NULL)
	{
		WORD* pImg14 = (WORD*)m_pImg14;
		int nPos = x + y*m_fmt.rect.width;
		nV = pImg14[nPos];
	}
	return nV;
}

//°Ñ14Î»Êý¾Ý×ª»»ÎªÉãÊÏÎÂ¶È£¨¸ß·Ö±æÄ£Ê½£º0.04£©
double CqIrDev::V2Degree_HighResolution(int nV)
{
	return (nV*0.04 - ABS_ZERO_DEGREE);
}
//°Ñ14Î»Êý¾Ý×ª»»ÎªÉãÊÏÎÂ¶È£¨µÍ·Ö±æÄ£Ê½£º0.4£©
double CqIrDev::V2Degree_LowResolution(int nV)
{
	return (nV*0.4 - ABS_ZERO_DEGREE);
}


