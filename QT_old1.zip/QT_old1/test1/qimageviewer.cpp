#include "qimageviewer.h"
#include<QPainter>
#include<QImage>
#include <QMutex>

#include "ImgProc.h"

#define __CROSS_SIZE__ 10

extern stMultiMinMax g_stMultiMinMax;

extern QMutex g_mutex;

QImageViewer::QImageViewer(QLabel *parent) : QLabel(parent)
{
    m_width = 336;
    m_height = 256;

    m_buf = NULL;

    setStyleSheet(QString::fromUtf8("border:1px solid red"));
}



void QImageViewer::SetDrawRect(int nFactor)
{
    int nPalWid=16;
    int nPalHei=256;
//    m_recImg.left =0;
//    m_recImg.top = 0;
//    m_recImg.right = m_width*nFactor;
//    m_recImg.bottom = m_height*nFactor;


    m_recImg.setRect(0,0,m_width*nFactor,m_height*nFactor);

}

void QImageViewer::DrawPt(QPainter* p, QRect *rect, int m_nMaxT_x, int m_nMaxT_y)
{
    //QRect由于历史原因，bottom()和right()函数返回的值偏离了矩形的真正的右下角:right()函数返回left() + width() - 1, bottom()函数返回top() + height() - 1。bottomRight()函数返回的点也是如此。

    //最大温度点的位置
    int nLeft = m_nMaxT_x - __CROSS_SIZE__;
    if (nLeft < rect->left())
        nLeft = rect->left();

    int nRight = m_nMaxT_x + __CROSS_SIZE__;
    if (nRight >= rect->right())
        //nRight = rect->right() - 1;
        nRight = rect->right();

    int nTop = m_nMaxT_y - __CROSS_SIZE__;
    if (nTop < rect->top())
        nTop = rect->top();

    int nBottom = m_nMaxT_y + __CROSS_SIZE__;
    if (nBottom >= rect->bottom())
        //nBottom = rect->bottom() - 1;
        nBottom = rect->bottom();

//    pDC->MoveTo(nLeft, m_nMaxT_y);
//    pDC->LineTo(nRight, m_nMaxT_y);

//    pDC->MoveTo(m_nMaxT_x, nTop);
//    pDC->LineTo(m_nMaxT_x, nBottom);

    p->drawLine(QPoint(nLeft,m_nMaxT_y),QPoint(nRight,m_nMaxT_y));
    p->drawLine(QPoint(m_nMaxT_x,nTop),QPoint(m_nMaxT_x,nBottom));

}

void QImageViewer::Draw_rect(QPainter* p, QRect* pRect, BOOL bShow)
{
    if (bShow)
    {
//		CPen LinePenMax;
//		CPen LinePenMin;
//		CPen * pOldPen;

//		LinePenMax.CreatePen(PS_SOLID, 1, RGB(255, 0, 0));
//		pOldPen = pDC->SelectObject(&LinePenMax);

         p->setPen(QPen(Qt::red, 1, Qt::SolidLine));

        //最大温度点的位置
        int i;
        for (i = 0; i < g_stMultiMinMax.nMaxV_Num; i++)
            DrawPt(p, pRect, g_stMultiMinMax.p_ptMaxV[i].x*m_nFactor, g_stMultiMinMax.p_ptMaxV[i].y*m_nFactor);



//		LinePenMin.CreatePen(PS_SOLID, 1, RGB(0, 0, 255));
//		pOldPen = pDC->SelectObject(&LinePenMin);

        p->setPen(QPen(Qt::blue, 1, Qt::SolidLine));

        for (i = 0; i < g_stMultiMinMax.nMinV_Num; i++)
            DrawPt(p, pRect, g_stMultiMinMax.p_ptMinV[i].x*m_nFactor, g_stMultiMinMax.p_ptMinV[i].y*m_nFactor);


//		pDC->SelectObject(pOldPen);
    }
}

void QImageViewer::paintEvent(QPaintEvent *event)
{
    QWidget::paintEvent(event);

    if(m_buf != NULL)
    {
        g_mutex.lock();

        QPainter painter(this);
        QImage *image=new QImage(m_buf,m_width,m_height,QImage::Format_RGB888);
        painter.drawImage(0,0,*image);

        delete image;

        //painter.drawText(50, 50, "Hello DevDiv!");

        if(m_VideoPalette == IR_VIDEO_R140)
        {
            Draw_rect(&painter, &m_recImg, TRUE);
        }

        g_mutex.unlock();
    }

}

