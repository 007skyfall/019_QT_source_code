#ifndef QIMAGEVIEWER_H
#define QIMAGEVIEWER_H

#include <QWidget>
#include <QLabel>

#include "../include/ir_types.h"
#include "../include/ir_errinfo.h"
#include "../include/ir_cam.h"

class QImageViewer : public QLabel
{
    Q_OBJECT
public:
    explicit QImageViewer(QLabel *parent = 0);

    uchar* m_buf;
    int m_width;
    int m_height;

    ir_video_palette_t m_VideoPalette;
    QRect m_recImg;

    int m_nFactor = 1;

    void SetDrawRect(int nFactor);

    void DrawPt(QPainter* p, QRect *rect, int m_nMaxT_x, int m_nMaxT_y);
    void Draw_rect(QPainter* p, QRect* pRect, BOOL bShow);

signals:

public slots:

protected:
    void paintEvent(QPaintEvent *);
};

#endif // QIMAGEVIEWER_H
