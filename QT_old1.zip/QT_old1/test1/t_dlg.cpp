#include "t_dlg.h"
#include "ui_t_dlg.h"

#include "tau2_ctl.h"
//#include "spi.h"
#include "mainwindow.h"

extern MainWindow *g_MainWindow;

T_Dlg::T_Dlg(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::T_Dlg)
{
    ui->setupUi(this);
}

T_Dlg::~T_Dlg()
{
    delete ui;
}
void nV2Str(int nV,int nMin,int nMax,double fMin,double fMax,char* lpStr)
{
    double dV= ( (double)(nV-nMin)/(double)(nMax-nMin)) * (fMax-fMin) +	fMin;
    sprintf(lpStr,"%.2f",dV);
}
void T_Dlg::on_BTN_G_PARA_clicked()
{
    int nV=0;
    int rc=0;
    stSCENE_Para aPara;

    rc = camTau2_Get_Scene_Para(g_MainWindow->m_pDev->m_ir_handle,0,&nV);
    aPara.nRAD_EMISSIVITY=nV;
    rc = camTau2_Get_Scene_Para(g_MainWindow->m_pDev->m_ir_handle,1,&nV);
    aPara.nRAD_TBKG_X100=nV;
    rc = camTau2_Get_Scene_Para(g_MainWindow->m_pDev->m_ir_handle,2,&nV);
    aPara.nRAD_TRANSMISSION_WIN=nV;
    rc = camTau2_Get_Scene_Para(g_MainWindow->m_pDev->m_ir_handle,3,&nV);
    aPara.nRAD_TWIN_X100=nV;
    rc = camTau2_Get_Scene_Para(g_MainWindow->m_pDev->m_ir_handle,4,&nV);
    aPara.nRAD_TAU_ATM=nV;
    rc = camTau2_Get_Scene_Para(g_MainWindow->m_pDev->m_ir_handle,5,&nV);
    aPara.nRAD_TATM_X100=nV;
    rc = camTau2_Get_Scene_Para(g_MainWindow->m_pDev->m_ir_handle,6,&nV);
    aPara.nRAD_REFL_WIN=nV;
    rc = camTau2_Get_Scene_Para(g_MainWindow->m_pDev->m_ir_handle,7,&nV);
    aPara.nRAD_TREFL_X100=nV;

    char lpStr[64];
    //1
    nV2Str(aPara.nRAD_EMISSIVITY,4096,8192,0.5,1.0,lpStr);	////sprintf(lpStr,"%.2f",aPara.nRAD_EMISSIVITY/1.0);
    //m_strRAD_EMISSIVITY = lpStr;
    QString str = QString(QLatin1String(lpStr));
    ui->EDIT_RAD_EMISSIVITY->setText(str);

    //2,
    sprintf(lpStr,"%.2f",aPara.nRAD_TBKG_X100/100.0);
    //m_strRAD_TBKG_X100 = lpStr;
    str = QString(QLatin1String(lpStr));
    ui->EDIT_RAD_TBKG_X100->setText(str);

    //3,
    nV2Str(aPara.nRAD_TRANSMISSION_WIN,4096,8192,0.5,1.0,lpStr);	//sprintf(lpStr,"%.2f",aPara.nRAD_TRANSMISSION_WIN/1.0);
    //m_strRAD_TRANSMISSION_WIN = lpStr;
    str = QString(QLatin1String(lpStr));
    ui->EDIT_RAD_TRANSMISSION_WIN->setText(str);

    //4
    sprintf(lpStr,"%.2f",aPara.nRAD_TWIN_X100/100.0);
    //m_strRAD_TWIN_X100 = lpStr;
    str = QString(QLatin1String(lpStr));
    ui->EDIT_RAD_TWIN_X100->setText(str);

    //5
    nV2Str(aPara.nRAD_TAU_ATM,4096,8192,0.5,1.0,lpStr);//sprintf(lpStr,"%.2f",aPara.nRAD_TAU_ATM/1.0);
    //m_strRAD_TAU_ATM = lpStr;
    str = QString(QLatin1String(lpStr));
    ui->EDIT_RAD_TAU_ATM->setText(str);

    //6
    sprintf(lpStr,"%.2f",aPara.nRAD_TATM_X100/100.0);
    //m_strRAD_TATM_X100 = lpStr;
    str = QString(QLatin1String(lpStr));
    ui->EDIT_RAD_TATM_X100->setText(str);

    //7
    sprintf(lpStr,"%.2f",aPara.nRAD_REFL_WIN/100.0);
    //m_strRAD_REFL_WIN = lpStr;
    str = QString(QLatin1String(lpStr));
    ui->EDIT_RAD_REFL_WIN->setText(str);

    //8
    sprintf(lpStr,"%.2f",aPara.nRAD_TREFL_X100/100.0);
    //m_strRAD_TREFL_X100 = lpStr;
    str = QString(QLatin1String(lpStr));
    ui->EDIT_RAD_TREFL_X100->setText(str);

}
int dV2Int(double dV,int nMin,int nMax,double fMin,double fMax)
{
    return nMin + (nMax - nMin)*(dV - fMin)/(fMax - fMin);
}
void T_Dlg::on_BTN_S_PARA_clicked()
{

    double dV;
    int nV;
    int rc;

    //1
    //dV = atof(m_strRAD_EMISSIVITY);
    dV = ui->EDIT_RAD_EMISSIVITY->text().toFloat();
    nV = dV2Int(dV,4096,8192,0.5,1.0);
    rc = camTau2_Set_Scene_Para(g_MainWindow->m_pDev->m_ir_handle,0,nV);

    //2,
    //dV = atof(m_strRAD_TBKG_X100);
    dV = ui->EDIT_RAD_TBKG_X100->text().toFloat();
    nV = dV*100;
    rc = camTau2_Set_Scene_Para(g_MainWindow->m_pDev->m_ir_handle,1,nV);

    //3,
    //dV = atof(m_strRAD_TRANSMISSION_WIN);
    dV = ui->EDIT_RAD_EMISSIVITY->text().toFloat();
    nV = dV2Int(dV,4096,8192,0.5,1.0);
    rc = camTau2_Set_Scene_Para(g_MainWindow->m_pDev->m_ir_handle,2,nV);

    //4
    //dV = atof(m_strRAD_TWIN_X100);
    dV = ui->EDIT_RAD_TWIN_X100->text().toFloat();
    nV = dV*100;
    rc = camTau2_Set_Scene_Para(g_MainWindow->m_pDev->m_ir_handle,3,nV);

    //5
    //dV = atof(m_strRAD_TAU_ATM);
    dV = ui->EDIT_RAD_TAU_ATM->text().toFloat();
    nV = dV2Int(dV,4096,8192,0.5,1.0);
    rc = camTau2_Set_Scene_Para(g_MainWindow->m_pDev->m_ir_handle,4,nV);

    //6
    //dV = atof(m_strRAD_TATM_X100);
    dV = ui->EDIT_RAD_TATM_X100->text().toFloat();
    nV = dV*100;
    rc = camTau2_Set_Scene_Para(g_MainWindow->m_pDev->m_ir_handle,5,nV);

    //7
    //dV = atof(m_strRAD_REFL_WIN);
    dV = ui->EDIT_RAD_REFL_WIN->text().toFloat();
    nV = dV*100;
    rc = camTau2_Set_Scene_Para(g_MainWindow->m_pDev->m_ir_handle,6,nV);

    //8
    //dV = atof(m_strRAD_TREFL_X100);
    dV = ui->EDIT_RAD_TREFL_X100->text().toFloat();
    nV = dV*100;
    rc = camTau2_Set_Scene_Para(g_MainWindow->m_pDev->m_ir_handle,7,nV);
}
