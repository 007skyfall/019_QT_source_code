//qiao
//2013.12.7
//
#ifndef __TAU2_CTL__
#define __TAU2_CTL__

#include "../include/ir_types.h"
#include "../include/ir_errinfo.h"
#include "../include/ir_cam.h"



#ifndef max
#define max(a,b)            (((a) > (b)) ? (a) : (b))
#endif

#ifndef min
#define min(a,b)            (((a) < (b)) ? (a) : (b))
#endif

#define FALSE   0
#define TRUE    1
#define NULL    0
//typedef unsigned char       BYTE;
typedef unsigned short      WORD;
//typedef unsigned long       DWORD;
//typedef int                 BOOL;

#ifdef __cplusplus
extern "C" {
#endif


/*
typedef struct _stGET_SPOT_METER_DATA
{
	unsigned short nSyncFlag;
	unsigned short nFrmCnt;
	unsigned short nAv;
	unsigned short nStdDev;
	unsigned short nMin;
	unsigned short nMax;
	short nMin_x;
	short nMin_y;
	short nMax_x;
	short nMax_y;
}stGET_SPOT_METER_DATA;
*/
//2015.12.4
typedef struct _stGET_SPOT_METER_DATA
{
	unsigned short nSyncFlag;
	unsigned short nFrmCnt;
	short nAv;
	unsigned short nStdDev;
	short nMin;
	short nMax;
	short nMin_x;
	short nMin_y;
	short nMax_x;
	short nMax_y;
}stGET_SPOT_METER_DATA;


typedef struct _stGET_SPOT_METER_COORDINATES
{
	unsigned short nSyncFlag;
	unsigned short nFrmCnt;
	short nLeft;
	short nTop;
	short nRight;
	short nBottom;
}stGET_SPOT_METER_COORDINATES;


typedef struct _stSET_SPOT_METER_COORDINATES
{
	short nLeft;
	short nTop;
	short nRight;
	short nBottom;
}stSET_SPOT_METER_COORDINATES;


typedef struct _stSCENE_Para
{
	short nRAD_EMISSIVITY;
	short nRAD_TBKG_X100;
	short nRAD_TRANSMISSION_WIN;
	short nRAD_TWIN_X100;
	short nRAD_TAU_ATM;
	short nRAD_TATM_X100;
	short nRAD_REFL_WIN;
	short nRAD_TREFL_X100;
}stSCENE_Para;


#if 0		//¶¨Òå¸ÄÔÚ"FlirCam_common.h"

//(4.1)
typedef struct _stCamFuncProp
{
    int32_t nUserCtlCode;
    int32_t nFuncCode;		//FlirÎÄµµ¶¨ÒåµÄ¿ØÖÆ×Ö
    int32_t opProperty;		//CanDO=0x01,CanGet=0x02,CanSet=0x04
	char lpFuncName[64];
}stCamFuncProp;

//(4.2)
typedef struct _stCamOpData
{
	//(1)Ð´Ïà»úÊý¾Ý¡¢²ÎÊý
	unsigned char lpCMD[MAX_CMD_LEN];
    int32_t nFuncCode;
	unsigned char lpData[MAX_CMD_LEN];
    int32_t nDataLen;

	//(2)´ÓÏà»ú¶ÁÈ¡µÄÊý¾Ý¡¢Ï£Íû¶ÁÈ¡µÄ³¤¶È
    int32_t nWantRcvLen;
	unsigned char lpRcvBuf[MAX_CMD_LEN];

	//(3)
	unsigned char lpResponse[MAX_CMD_LEN];
}stCamOpData;

#endif		//#if 0


//*pCamSeri:		Camera serial number
//*pSensorSeri:		Sensor serial number
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_SERIAL_NUMBER(ir_dev_handle_t fd,DWORD *pCamSeri,DWORD *pSensorSeri);


//*pSWmajor:		SW major version
//*pSWminor:		SW minor version
//pFWmajor:			FW major version
//pFWminor:			FW minor version
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_REVISION(ir_dev_handle_t fd,WORD *pSWmajor,WORD *pSWminor,WORD *pFWmajor,WORD *pFWminor);


//return:
//	0:	ok
//	<0:	error
int camTau2_DO_FFC(ir_dev_handle_t fd);

//*pnMode:		can only be: 0,1,2
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_Gain_Mode(ir_dev_handle_t fd,int* pnMode);

//nMode:		can only be: 0,1,2
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_Gain_Mode(ir_dev_handle_t fd,int nMode);


//*nAGCType:		can only be: 0,1,2,3,4,5,6
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_AGC_TYPE(ir_dev_handle_t fd,int* pnAGCType);

//nAGCType:		can only be: 0,1,2,3,4,5,6
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_AGC_TYPE(ir_dev_handle_t fd,int nAGCType);

//*pnContrast:		0~255,default: 20
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_CONTRAST(ir_dev_handle_t fd,int* pnContrast);

//nContrast:		0~255,default: 20
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_CONTRAST(ir_dev_handle_t fd,int nContrast);


//*pnBrightness:	default: 8192
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_BRIGHTNESS(ir_dev_handle_t fd,int* pnBrightness);


//nBrightness:	default: 8192
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_BRIGHTNESS(ir_dev_handle_t fd,int nBrightness);


//*pnBrightness:	default: 0
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_BRIGHTNESS_Bias(ir_dev_handle_t fd,int* pnBrightnessBias);

//nBrightness:	default: 0
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_BRIGHTNESS_Bias(ir_dev_handle_t fd,int nBrightnessBias);



//*pnDDE_GAIN:
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_DDE_GAIN(ir_dev_handle_t fd,int* pnDDE_GAIN);

//nDDE_GAIN:
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_DDE_GAIN(ir_dev_handle_t fd,int nDDE_GAIN);


//*pnAGC_FILTER:		default 64
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_AGC_FILTER(ir_dev_handle_t fd,int* pnAGC_FILTER);

//nAGC_FILTER:	default 64
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_AGC_FILTER(ir_dev_handle_t fd,int nAGC_FILTER);


//*pnPlateauLeval:	0~1000.  default 150
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_PLATEAU_LEVEL(ir_dev_handle_t fd,int* pnPlateauLeval);

//nPlateauLeval:	0~1000. default 150
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_PLATEAU_LEVEL(ir_dev_handle_t fd,int nPlateauLeval);

//*pnPlateauLeval:	0~1000.  default 150
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_PLATEAU_LEVEL(ir_dev_handle_t fd,int* pnPlateauLeval);

//nPlateauLeval:	0~1000. default 150
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_PLATEAU_LEVEL(ir_dev_handle_t fd,int nPlateauLeval);

//*pnAGCMidpoint:		default 127. 0~255
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_AGC_Midpoint(ir_dev_handle_t fd,int* pnAGCMidpoint);

//nAGCMidpoint:	default 127. 0~255
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_AGC_Midpoint(ir_dev_handle_t fd,int nAGCMidpoint);


//lpPart:	Bytes 0-31: Part number (ASCII)
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_CameraPart(ir_dev_handle_t fd,char* lpPart);

//*pnMaxAGCGain:	0~2047.  default 12
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_MAX_AGC_GAIN(ir_dev_handle_t fd,int* pnMaxAGCGain);

//*pnVideoStandard:		
//0x0000 = NTSC, 30Hz
//0x0001 = PAL, 25Hz
//0x0002 = reserved
//0x0003 = reserved
//0x0004 = NTSC, 60Hz,
//0x0005 = PAL, 50Hz
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_Video_Standard(ir_dev_handle_t fd,int* pnVideoStandard);

//nVideoStandard:		
//0x0000 = NTSC, 30Hz
//0x0001 = PAL, 25Hz
//0x0002 = reserved
//0x0003 = reserved
//0x0004 = NTSC, 60Hz,
//0x0005 = PAL, 50Hz
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_Video_Standard(ir_dev_handle_t fd,int nVideoStandard);

//nMaxAGCGain:	0~2047. default 12
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_MAX_AGC_GAIN(ir_dev_handle_t fd,int nMaxAGCGain);

//*pnDDE_THRESHOLD:		0~255
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_DDE_THRESHOLD(ir_dev_handle_t fd,int* pnDDE_THRESHOLD);

//nDDE_THRESHOLD:		0~255
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_DDE_THRESHOLD(ir_dev_handle_t fd,int nDDE_THRESHOLD);

//*pnSPATIALE_THRESHOLD:
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_SPATIAL_THRESHOLD(ir_dev_handle_t fd,int* pnSPATIALE_THRESHOLD);

//nSPATIALE_THRESHOLD:
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_SPATIAL_THRESHOLD(ir_dev_handle_t fd,int nSPATIALE_THRESHOLD);


//*pnMode:
//		returned value: 0x0000 = disabled;0x0001 = enabled
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_LVDS_MODE(ir_dev_handle_t fd,int *pnMode);

//Set the LVDS Mode
//nMode:
//		0x00 = disabled
//		0x01 = enabled
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_LVDS_MODE(ir_dev_handle_t fd,int nMode);

//*pnMode:
//		returned value: 0x0000 = 14bit;	0x0001 = 8bit
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_LVDS_Bits(ir_dev_handle_t fd,int *pnBits);

//Set the LVDS Mode
//nMode:
//		0x00 = 14 bits
//		0x01 = 8 bits
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_LVDS_Bits(ir_dev_handle_t fd,int nBits);


int camTau2_GET_SPOT_METER_DATA(ir_dev_handle_t fd,stGET_SPOT_METER_DATA *pData);
int camTau2_GET_SPOT_METER_COORDINATES(ir_dev_handle_t fd,stGET_SPOT_METER_COORDINATES *pCoord);
int camTau2_Set_SPOT_METER_COORDINATES(ir_dev_handle_t fd,stSET_SPOT_METER_COORDINATES *pCoord);

//»ñÈ¡scene²ÎÊý¡£
//nSubCMD:  0~7,see "102-PS242-43-Tau2_Quark_SoftwareIDD_Rev130.pdf"
//0x0100=RAD_EMISSIVITY
//0x0101=RAD_TBKG_X100
//0x0102=RAD_TRANSMISSION_WIN
//0x0103= RAD_TWIN_X100
//0x0104= RAD_TAU_ATM
//0x0105= RAD_TATM_X100
//0x0106=RAD_REFL_WIN
//0x0107=RAD_TREFL_X100
int camTau2_Get_Scene_Para(ir_dev_handle_t fd,int nSubCMD,int* pnV);
int camTau2_Set_Scene_Para(ir_dev_handle_t fd,int nSubCMD,int nV);

//»ñÈ¡¾µÍ·²ÎÊý
//nLensID:	0=Lens #0, 1=Lens #1
//pfLenF:	¾µÍ·FÊý£¬4096-65535 (0.5-7.9999)
//pfLenTransmission£º	¾µÍ·Í¸¹ýÂÊ£¬4096-8192 (0.5-1.0)
int camTau2_Get_Lens_Para(ir_dev_handle_t fd,int nLensID,double* pfLenF,double* pfLenTransmission);

//ÉèÖÃ¾µÍ·²ÎÊý
//nLensID:	0=Lens #0, 1=Lens #1
//fLenF:	¾µÍ·FÊý£¬4096-65535 (0.5-7.9999)
//fLenTransmission£º	¾µÍ·Í¸¹ýÂÊ£¬4096-8192 (0.5-1.0)
int camTau2_Set_Lens_Para(ir_dev_handle_t fd,int nLensID,double fLenF,double fLenTransmission);



int camTau2_Get_FPA_T(ir_dev_handle_t fd,double* pdT);
int camTau2_Get_Housing_T(ir_dev_handle_t fd,double* pdT);


//nMode:	0:  low resolution mode;
//			1:  high resolution mode.
int camTau2_Set_TLinOutputMode(ir_dev_handle_t fd,int nMode);
int camTau2_Get_TLinOutputMode(ir_dev_handle_t fd,WORD* pMode);

int camTau2_Get_TLinEnableStatus(ir_dev_handle_t fd,WORD* pStatus);
int camTau2_Set_TLinEnableStatus(ir_dev_handle_t fd,int nEnable);

int camTau2_Get_FFC_MODE(ir_dev_handle_t fd,int* pnFFCMode);
int camTau2_Set_FFC_MODE(ir_dev_handle_t fd,int nFFCMode);


//±£´æÉèÖÃ
int camTau2_SaveSetting(ir_dev_handle_t fd);

//»Ö¸´³ö³§ÉèÖÃ
int camTau2_RestoreFactoryDefault(ir_dev_handle_t fd);


//Ïà»ú¸´Î»
int camTau2_ResetCam(ir_dev_handle_t fd);

int camTau2_Get_VIDEO_ORIENTATION(ir_dev_handle_t fd,int* pnVideoOrientation);
int camTau2_Set_VIDEO_ORIENTATION(ir_dev_handle_t fd,int nVideoOrientation);

int camTau2_Get_TAU2_SPOT_DISPLAY(ir_dev_handle_t fd,int* pnMode);
int camTau2_Set_SPOT_DISPLAY(ir_dev_handle_t fd,int nMode);
#ifdef __cplusplus
}
#endif	

#endif//__TAU2_CTL__

