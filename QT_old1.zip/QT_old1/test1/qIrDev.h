// qIrDev.h: interface for the CqIrDev class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_QIRDEV_H__8E5B3D9B_5283_40F1_8A57_F918FB5BDBBC__INCLUDED_)
#define AFX_QIRDEV_H__8E5B3D9B_5283_40F1_8A57_F918FB5BDBBC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "../include/ir_types.h"
#include "../include/ir_errinfo.h"
#include "../include/ir_cam.h"



typedef void *HANDLE;
typedef int   BOOL;

#define MAX_IMG_WID	336	//640
#define MAX_IMG_HEI	256	//512

#define ABS_ZERO_DEGREE	273.15

class CqIrDev  
{
public:
	CqIrDev();
	virtual ~CqIrDev();

public:
	ir_dev_handle_t m_ir_handle;
	ir_video_format_t m_fmt;

	HANDLE m_hDibPal;
	HANDLE m_hDib;

	void* m_pImg14;
	void* m_pImg8;
    int m_width;
    int m_height;
    int m_nMalloc;

	BOOL m_bIdle;

	int m_capture_running;

	//int m_nBitsBak;

    //PALETTEENTRY    *m_pPalette;
    //BOOL m_bForceChangePalette;			//¸Ä±äµ÷É«°å

	int m_LastVideoFourcc;

    //CWnd* m_pUserWin;
    //UINT m_nUserMessage;
public:
	int OpenDev(ir_dev_info_t *pdev, ir_net_status_callback_func_t callback_func, void *user_data);
	//int retryOpenDev(ir_dev_info_t *pdev, ir_net_status_callback_func_t callback_func, void *user_data);
	int CloseDev();
	
	//int GetLastRdyBuf();

	int StartCapImg(void *user_data);
	int StopCapImg();

	int StartDev(void *user_data);
	int StopDev();
	int DevCtl(ir_ctl_code_t ctl_code,  void *ctl_para);

	void FreeAllBuf();
	void MkNewBuf(int nWid,int nHei,ir_video_palette_t pal);
    //void ReisterUserWindow(CWnd* pWnd,UINT nMessage);
    //void UserChangePalette(PALETTEENTRY* pPalette,int nNum);
	
	int Get14BitsV(int x,int y);
	double V2Degree_HighResolution(int nV);
	double V2Degree_LowResolution(int nV);
private:
    //HANDLE m_hCap_thread;
    //unsigned mThread_id;

    pthread_t m_tid;
    int m_npthread;

	ir_dev_info_t m_DevInfo;

	int m_nLastImgID;




private:

public:


};

#endif // !defined(AFX_QIRDEV_H__8E5B3D9B_5283_40F1_8A57_F918FB5BDBBC__INCLUDED_)
