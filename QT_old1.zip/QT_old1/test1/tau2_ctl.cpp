/*
*	Copyright (C) 2006  irDNA
*
*	tau2_ctl.c
*	
*	This program is free software; you can redistribute it and/or modify
*	it under the terms of the GNU General Public License as published by
*	the Free Software Foundation; either version 2 of the License, or
*	(at your option) any later version.
*
*	This program is distributed in the hope that it will be useful,
*	but WITHOUT ANY WARRANTY; without even the implied warranty of
*	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*	GNU General Public License for more details.
*   
*   Qiao
*	Date:		2013-12-7
*   ¶ÔTau2Ïà»ú¿ØÖÆµÄÒ»²¿·Ö¡£½ö½öÉèÖÃLVDS mode¡¢LVDS bits¡£
*/
//#include "stdafx.h"

//#include "../camera_SDK/include/ir_errinfo.h"
//#include "ircam/tau2def.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Tau2def.h"
#include "tau2_ctl.h"



//*pnMode:
//		returned value: 0x0000 = disabled;0x0001 = enabled
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_LVDS_MODE(ir_dev_handle_t fd,int *pnMode)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_DIGITAL_OUTPUT_MODE;
	aCamData.lpData[0]=0x04;		//	Gets the LVDS Mode
	aCamData.lpData[1]=0x00;		
	aCamData.nDataLen = 2;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		//(3.2)
		uint16_t* pwData = (uint16_t*)(aCamData.lpResponse);
		//(3.3)
		*pnMode = be16_to_le16(*pwData);

		return IR_E_OK;
	}
	else
		return nRet;
}

//Set the LVDS Mode
//nMode:
//		0x00 = disabled
//		0x01 = enabled
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_LVDS_MODE(ir_dev_handle_t fd,int nMode)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_DIGITAL_OUTPUT_MODE;
	aCamData.lpData[0]=0x05;		//	sets the LVDS Mode
	aCamData.lpData[1]=nMode;		
	aCamData.nDataLen = 2;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		//(3.2)
		uint16_t* pwData = (uint16_t*)(aCamData.lpResponse);
		//(3.3)
		int aMode = be16_to_le16(*pwData);
		return IR_E_OK;
	}
	else
		return nRet;
}

//*pnMode:
//		returned value: 0x0000 = 14bit;	0x0001 = 8bit
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_LVDS_Bits(ir_dev_handle_t fd,int *pnBits)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_DIGITAL_OUTPUT_MODE;
	aCamData.lpData[0]=0x09;		//	Gets the LVDS Bits
	aCamData.lpData[1]=0x00;		
	aCamData.nDataLen = 2;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		//(3.2)
		uint16_t* pwData = (uint16_t*)(aCamData.lpResponse);
		//(3.3)
		*pnBits = be16_to_le16(*pwData);

		return IR_E_OK;
	}
	else
		return nRet;
}

//Set the LVDS Mode
//nMode:
//		0x00 = 14 bits
//		0x01 = 8 bits
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_LVDS_Bits(ir_dev_handle_t fd,int nBits)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_DIGITAL_OUTPUT_MODE;
	aCamData.lpData[0]=0x07;		//	Sets the LVDS Mode
	aCamData.lpData[1]=nBits;		
	aCamData.nDataLen = 2;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		//(3.2)
		uint16_t* pwData = (uint16_t*)(aCamData.lpResponse);
		//(3.3)
		int aMode = be16_to_le16(*pwData);
//printf("set LVDS bits=0x%x\n",aMode);
		return IR_E_OK;
	}
	else
		return nRet;
}

//*pCamSeri:		Camera serial number
//*pSensorSeri:		Sensor serial number
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_SERIAL_NUMBER(ir_dev_handle_t fd,DWORD *pCamSeri,DWORD *pSensorSeri)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_SERIAL_NUMBER;
	aCamData.nDataLen = 0;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +8;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		DWORD* pdwData = (DWORD*)(aCamData.lpResponse);
		//(3.2)
		if(pCamSeri != NULL)
			*pCamSeri = be32_to_le32(pdwData[0]);
		//(3.3)
		if(pSensorSeri != NULL)
			*pSensorSeri = be32_to_le32(pdwData[1]);

		return IR_E_OK;
	}
	else
		return nRet;
}


//*pSWmajor:		SW major version
//*pSWminor:		SW minor version
//pFWmajor:			FW major version
//pFWminor:			FW minor version
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_REVISION(ir_dev_handle_t fd,WORD *pSWmajor,WORD *pSWminor,WORD *pFWmajor,WORD *pFWminor)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_GET_REVISION;
	aCamData.nDataLen = 0;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +8;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		WORD* pwData = (WORD*)(aCamData.lpResponse);
		//(3.2)
		if(pSWmajor != NULL)
			*pSWmajor = be16_to_le16(pwData[0]);
		//(3.3)
		if(pSWminor != NULL)
			*pSWminor = be16_to_le16(pwData[1]);

		//(3.4)
		if(pFWmajor != NULL)
			*pFWmajor = be16_to_le16(pwData[2]);
		//(3.5)
		if(pFWminor != NULL)
			*pFWminor = be16_to_le16(pwData[3]);

		return IR_E_OK;
	}
	else
		return nRet;
}


//return:
//	0:	ok
//	<0:	error
int camTau2_DO_FFC(ir_dev_handle_t fd)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_DO_FFC;
	aCamData.nDataLen = 0;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +0;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{

		return IR_E_OK;
	}
	else
		return nRet;
}


//*pnMode:		can only be: 0,1,2
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_Gain_Mode(ir_dev_handle_t fd,int* pnMode)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_GAIN_MODE;
	aCamData.nDataLen = 0;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		BYTE* pbData = (BYTE*)(aCamData.lpResponse);
		//(3.2)
		if(pnMode != NULL)
			*pnMode = pbData[1];
		return IR_E_OK;
	}
	else
		return nRet;
}
//nMode:		can only be: 0,1,2
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_Gain_Mode(ir_dev_handle_t fd,int nMode)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_GAIN_MODE;
	aCamData.lpData[0]= 0;
	aCamData.lpData[1]= nMode;		
	aCamData.nDataLen = 2;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		BYTE* pbData = (BYTE*)(aCamData.lpResponse);
		//(3.2)
		BYTE bMode = pbData[1];
		return IR_E_OK;
	}
	else
		return nRet;
}


//*pnAGCType:		can only be: 0,1,2,3,4,5,6
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_AGC_TYPE(ir_dev_handle_t fd,int* pnAGCType)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_AGC_TYPE;
	aCamData.nDataLen = 0;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +0;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		BYTE* pbData = (BYTE*)(aCamData.lpResponse);
		//(3.2)
		if(pnAGCType != NULL)
			*pnAGCType = pbData[1];
		return IR_E_OK;
	}
	else
		return nRet;
}


//nAGCType:		can only be: 0,1,2,3,4,5,6
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_AGC_TYPE(ir_dev_handle_t fd,int nAGCType)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_AGC_TYPE;
	aCamData.lpData[0]= 0;
	aCamData.lpData[1]= nAGCType;		
	aCamData.nDataLen = 2;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		BYTE* pbData = (BYTE*)(aCamData.lpResponse);
		//(3.2)
		BYTE bAGCType = pbData[1];
		return IR_E_OK;
	}
	else
		return nRet;
}

//*pnContrast:		0~255,default: 20
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_CONTRAST(ir_dev_handle_t fd,int* pnContrast)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_CONTRAST;
	aCamData.nDataLen = 0;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		BYTE* pbData = (BYTE*)(aCamData.lpResponse);
		//(3.2)
		if(pnContrast != NULL)
			*pnContrast = pbData[1];
		return IR_E_OK;
	}
	else
		return nRet;

}

//nContrast:		0~255,default: 20
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_CONTRAST(ir_dev_handle_t fd,int nContrast)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_CONTRAST;
	aCamData.lpData[0]= 0;
	aCamData.lpData[1]= nContrast;		
	aCamData.nDataLen = 2;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		BYTE* pbData = (BYTE*)(aCamData.lpResponse);
		//(3.2)
		BYTE bContrast = pbData[1];
		return IR_E_OK;
	}
	else
		return nRet;

}


//*pnBrightness:	default: 8192
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_BRIGHTNESS(ir_dev_handle_t fd,int* pnBrightness)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_BRIGHTNESS;
	aCamData.nDataLen = 0;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		WORD* pwData = (WORD*)(aCamData.lpResponse);
		//(3.2)
		if(pnBrightness != NULL)
			*pnBrightness = be16_to_le16(pwData[0]);
		return IR_E_OK;
	}
	else
		return nRet;
}

//nBrightness:	default: 8192
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_BRIGHTNESS(ir_dev_handle_t fd,int nBrightness)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_BRIGHTNESS;
	aCamData.lpData[0]= (BYTE)((nBrightness & 0xFF00)>>8);
	aCamData.lpData[1]= (BYTE)((nBrightness & 0X00FF));
	aCamData.nDataLen = 2;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		WORD* pwData = (WORD*)(aCamData.lpResponse);
		//(3.2)
		WORD bBrightness = be16_to_le16(pwData[0]);
		return IR_E_OK;
	}
	else
		return nRet;
}


//*pnBrightness:	default: 0
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_BRIGHTNESS_Bias(ir_dev_handle_t fd,int* pnBrightnessBias)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_BRIGHTNESS_BIAS;
	aCamData.nDataLen = 0;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		WORD* pwData = (WORD*)(aCamData.lpResponse);
		//(3.2)
		if(pnBrightnessBias != NULL)
			*pnBrightnessBias = be16_to_le16(pwData[0]);
		return IR_E_OK;
	}
	else
		return nRet;
}

//nBrightness:	default: 0
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_BRIGHTNESS_Bias(ir_dev_handle_t fd,int nBrightnessBias)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_BRIGHTNESS_BIAS;
	aCamData.lpData[0]= (BYTE)((nBrightnessBias & 0xFF00)>>8);
	aCamData.lpData[1]= (BYTE)((nBrightnessBias & 0X00FF));
	aCamData.nDataLen = 2;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		WORD* pwData = (WORD*)(aCamData.lpResponse);
		//(3.2)
		WORD bBrightnessBias = be16_to_le16(pwData[0]);
		return IR_E_OK;
	}
	else
		return nRet;

}


//*pnDDE_GAIN:
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_DDE_GAIN(ir_dev_handle_t fd,int* pnDDE_GAIN)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_DDE_GAIN;
	aCamData.nDataLen = 0;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		BYTE* pbData = (BYTE*)(aCamData.lpResponse);
		//(3.2)
		if(pnDDE_GAIN != NULL)
			*pnDDE_GAIN = pbData[1];
		return IR_E_OK;
	}
	else
		return nRet;
}

//nDDE_GAIN:
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_DDE_GAIN(ir_dev_handle_t fd,int nDDE_GAIN)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_DDE_GAIN;
	aCamData.lpData[0]= 0;
	aCamData.lpData[1]= (BYTE)((nDDE_GAIN & 0xFF));
	aCamData.nDataLen = 2;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		BYTE* pData = (BYTE*)(aCamData.lpResponse);
		//(3.2)
		BYTE bDDE_GAIN = pData[1];
		return IR_E_OK;
	}
	else
		return nRet;

}



//*pnAGC_FILTER:		default 64. 0~255
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_AGC_FILTER(ir_dev_handle_t fd,int* pnAGC_FILTER)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_AGC_FILTER;
	aCamData.nDataLen = 0;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		BYTE* pbData = (BYTE*)(aCamData.lpResponse);
		//(3.2)
		if(pnAGC_FILTER != NULL)
			*pnAGC_FILTER = pbData[1];
		return IR_E_OK;
	}
	else
		return nRet;

}

//nAGC_FILTER:	default 64. 0~255
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_AGC_FILTER(ir_dev_handle_t fd,int nAGC_FILTER)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_AGC_FILTER;
	aCamData.lpData[0]= 0;
	aCamData.lpData[1]= (BYTE)((nAGC_FILTER & 0xFF));
	aCamData.nDataLen = 2;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		BYTE* pData = (BYTE*)(aCamData.lpResponse);
		//(3.2)
		BYTE bDDE_GAIN = pData[1];
		return IR_E_OK;
	}
	else
		return nRet;
}

//*pnPlateauLeval:	0~1000.  default 150
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_PLATEAU_LEVEL(ir_dev_handle_t fd,int* pnPlateauLeval)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_PLATEAU_LEVEL;
	aCamData.nDataLen = 0;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		WORD* pwData = (WORD*)(aCamData.lpResponse);
		//(3.2)
		if(pnPlateauLeval != NULL)
			*pnPlateauLeval = be16_to_le16(pwData[0]);
		return IR_E_OK;
	}
	else
		return nRet;
}

//nPlateauLeval:	0~1000. default 150
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_PLATEAU_LEVEL(ir_dev_handle_t fd,int nPlateauLeval)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_PLATEAU_LEVEL;
	aCamData.lpData[0]= (BYTE)((nPlateauLeval & 0xFF00)>>8);
	aCamData.lpData[1]= (BYTE)((nPlateauLeval & 0X00FF));
	aCamData.nDataLen = 2;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		WORD* pwData = (WORD*)(aCamData.lpResponse);
		//(3.2)
		WORD wPlateauLeval = be16_to_le16(pwData[0]);
		return IR_E_OK;
	}
	else
		return nRet;
}



//*pnAGCMidpoint:		default 127. 0~255
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_AGC_Midpoint(ir_dev_handle_t fd,int* pnAGCMidpoint)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_AGC_MIDPOINT;
	aCamData.nDataLen = 0;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		BYTE* pbData = (BYTE*)(aCamData.lpResponse);
		//(3.2)
		if(pnAGCMidpoint != NULL)
			*pnAGCMidpoint = pbData[1];
		return IR_E_OK;
	}
	else
		return nRet;
}

//nAGCMidpoint:	default 127. 0~255
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_AGC_Midpoint(ir_dev_handle_t fd,int nAGCMidpoint)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_AGC_MIDPOINT;
	aCamData.lpData[0]= 0;
	aCamData.lpData[1]= (BYTE)((nAGCMidpoint & 0xFF));
	aCamData.nDataLen = 2;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		BYTE* pData = (BYTE*)(aCamData.lpResponse);
		//(3.2)
		BYTE bnAGCMidpoint = pData[1];
		return IR_E_OK;
	}
	else
		return nRet;
}



//lpPart:	Bytes 0-31: Part number (ASCII)
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_CameraPart(ir_dev_handle_t fd,char* lpPart)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_CAMERA_PART;
	aCamData.nDataLen = 0;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +32;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		char* pData = (char*)(aCamData.lpResponse);
		//(3.2)
		if(lpPart != NULL)
			sprintf(lpPart,"%s",pData);
		return IR_E_OK;
	}
	else
		return nRet;
}


//*pnMaxAGCGain:	0~2047.  default 12
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_MAX_AGC_GAIN(ir_dev_handle_t fd,int* pnMaxAGCGain)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_MAX_AGC_GAIN;
	aCamData.nDataLen = 0;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		WORD* pwData = (WORD*)(aCamData.lpResponse);
		//(3.2)
		if(pnMaxAGCGain != NULL)
			*pnMaxAGCGain = be16_to_le16(pwData[0]);
		return IR_E_OK;
	}
	else
		return nRet;
}

//nMaxAGCGain:	0~2047. default 12
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_MAX_AGC_GAIN(ir_dev_handle_t fd,int nMaxAGCGain)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_MAX_AGC_GAIN;
	aCamData.lpData[0]= (BYTE)((nMaxAGCGain & 0xFF00)>>8);
	aCamData.lpData[1]= (BYTE)((nMaxAGCGain & 0X00FF));
	aCamData.nDataLen = 2;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		WORD* pwData = (WORD*)(aCamData.lpResponse);
		//(3.2)
		WORD wnMaxAGCGain = be16_to_le16(pwData[0]);
		return IR_E_OK;
	}
	else
		return nRet;
}



//*pnVideoStandard:		
//0x0000 = NTSC, 30Hz
//0x0001 = PAL, 25Hz
//0x0002 = reserved
//0x0003 = reserved
//0x0004 = NTSC, 60Hz,
//0x0005 = PAL, 50Hz
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_Video_Standard(ir_dev_handle_t fd,int* pnVideoStandard)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_VIDEO_STANDARD;
	aCamData.nDataLen = 0;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		BYTE* pbData = (BYTE*)(aCamData.lpResponse);
		//(3.2)
		if(pnVideoStandard != NULL)
			*pnVideoStandard = pbData[1];
		return IR_E_OK;
	}
	else
		return nRet;
}

//nVideoStandard:		
//0x0000 = NTSC, 30Hz
//0x0001 = PAL, 25Hz
//0x0002 = reserved
//0x0003 = reserved
//0x0004 = NTSC, 60Hz,
//0x0005 = PAL, 50Hz
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_Video_Standard(ir_dev_handle_t fd,int nVideoStandard)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_VIDEO_STANDARD;
	aCamData.lpData[0]= 0;
	aCamData.lpData[1]= (BYTE)((nVideoStandard & 0xFF));
	aCamData.nDataLen = 2;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		BYTE* pData = (BYTE*)(aCamData.lpResponse);
		//(3.2)
		BYTE bnVideoStandard = pData[1];
		return IR_E_OK;
	}
	else
		return nRet;
}



//*pnDDE_THRESHOLD:		0~255
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_DDE_THRESHOLD(ir_dev_handle_t fd,int* pnDDE_THRESHOLD)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_DDE_THRESHOLD;
	aCamData.nDataLen = 0;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		BYTE* pbData = (BYTE*)(aCamData.lpResponse);
		//(3.2)
		if(pnDDE_THRESHOLD != NULL)
			*pnDDE_THRESHOLD = pbData[1];
		return IR_E_OK;
	}
	else
		return nRet;
}

//nDDE_THRESHOLD:		0~255
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_DDE_THRESHOLD(ir_dev_handle_t fd,int nDDE_THRESHOLD)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_DDE_THRESHOLD;
	aCamData.lpData[0]= 0;
	aCamData.lpData[1]= (BYTE)((nDDE_THRESHOLD & 0xFF));
	aCamData.nDataLen = 2;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		BYTE* pData = (BYTE*)(aCamData.lpResponse);
		//(3.2)
		BYTE bnDDE_THRESHOLD = pData[1];
		return IR_E_OK;
	}
	else
		return nRet;
}


//*pnSPATIALE_THRESHOLD:
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_SPATIAL_THRESHOLD(ir_dev_handle_t fd,int* pnSPATIALE_THRESHOLD)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_SPATIAL_THRESHOLD;
	aCamData.nDataLen = 0;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		WORD* pwData = (WORD*)(aCamData.lpResponse);
		//(3.2)
		if(pnSPATIALE_THRESHOLD != NULL)
			*pnSPATIALE_THRESHOLD = be16_to_le16(pwData[0]);
		return IR_E_OK;
	}
	else
		return nRet;
}

//nSPATIALE_THRESHOLD:
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_SPATIAL_THRESHOLD(ir_dev_handle_t fd,int nSPATIALE_THRESHOLD)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_SPATIAL_THRESHOLD;
	aCamData.lpData[0]= (BYTE)((nSPATIALE_THRESHOLD & 0xFF00)>>8);
	aCamData.lpData[1]= (BYTE)((nSPATIALE_THRESHOLD & 0xFF));
	aCamData.nDataLen = 2;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		WORD* pwData = (WORD*)(aCamData.lpResponse);
		//(3.2)
		WORD wSPATIALE_THRESHOLD = be16_to_le16(pwData[0]);
		return IR_E_OK;
	}
	else
		return nRet;
}

//GET_SPOT_METER_ DATA:	¶ÁÈ¡ÎÂ¶È
//return:
//	0:	ok
//	<0:	error
int camTau2_GET_SPOT_METER_DATA(ir_dev_handle_t fd,stGET_SPOT_METER_DATA *pData)
{
	if(pData==NULL)
		return IR_E_PTR_NULL;
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_GET_SPOT_METER_DATA;
	aCamData.nDataLen = 2;
	aCamData.lpData[0]= 0x00;
	aCamData.lpData[1]= 0x01;		//reply in Celsius x 10
	aCamData.nWantRcvLen = FIXED_CMD_LEN +20;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		WORD* pwData = (WORD*)(aCamData.lpResponse);
		short* psData = (short*)(aCamData.lpResponse);
		//(3.2)
		if(pData != NULL)
		{
			pData->nSyncFlag = be16_to_le16(pwData[0]);
			pData->nFrmCnt = be16_to_le16(pwData[1]);
			pData->nAv = be16_to_le16(pwData[2]);
			pData->nStdDev = be16_to_le16(pwData[3]);
			pData->nMin = be16_to_le16(pwData[4]);
			pData->nMax = be16_to_le16(pwData[5]);
			pData->nMin_x = be16_to_le16(psData[6]);
			pData->nMin_y = be16_to_le16(psData[7]);
			pData->nMax_x = be16_to_le16(psData[8]);
			pData->nMax_y = be16_to_le16(psData[9]);
		}
		
		if(pData->nSyncFlag==0)
			return IR_E_OK;
		else
			return IRCAM_BUSY;
	}
	else
		return nRet;
}

//TAU2_GET_SPOT_METER_COORDINATES:
//return:
//	0:	ok
//	<0:	error
int camTau2_GET_SPOT_METER_COORDINATES(ir_dev_handle_t fd,stGET_SPOT_METER_COORDINATES *pCoord)
{
	if(pCoord==NULL)
		return IR_E_PTR_NULL;

	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_GET_SPOT_METER_COORDINATES;
	aCamData.nDataLen = 2;
	aCamData.lpData[0]= 0x01;
	aCamData.lpData[1]= 0x00;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +12;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		WORD* pwData = (WORD*)(aCamData.lpResponse);
		short* psData = (short*)(aCamData.lpResponse);
		//(3.2)
		if(pCoord != NULL)
		{
			pCoord->nSyncFlag = be16_to_le16(pwData[0]);
			pCoord->nFrmCnt = be16_to_le16(pwData[1]);
			pCoord->nLeft = be16_to_le16(psData[2]);
			pCoord->nTop = be16_to_le16(psData[3]);
			pCoord->nRight = be16_to_le16(psData[4]);
			pCoord->nBottom = be16_to_le16(psData[5]);
		}
		return IR_E_OK;
	}
	else
		return nRet;
}
//TAU2_GET_SPOT_METER_COORDINATES:
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_SPOT_METER_COORDINATES(ir_dev_handle_t fd,stSET_SPOT_METER_COORDINATES *pRect)
{
	if(pRect==NULL)
		return IR_E_PTR_NULL;

	stCamOpData aCamData;
	unsigned short* pData=(unsigned short*)aCamData.lpData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_SET_SPOT_METER_COORDINATES;
	aCamData.nDataLen = 8;
	pData[0]=be16_to_le16(pRect->nLeft);
	pData[1]=be16_to_le16(pRect->nTop);
	pData[2]=be16_to_le16(pRect->nRight);
	pData[3]=be16_to_le16(pRect->nBottom);
	aCamData.nWantRcvLen = FIXED_CMD_LEN +4;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		WORD* pwData = (WORD*)(aCamData.lpResponse);
		
		unsigned short nSyncFlag = be16_to_le16(pwData[0]);
		unsigned short nFrmCnt = be16_to_le16(pwData[1]);
		return IR_E_OK;
	}
	else
		return nRet;
}

//»ñÈ¡scene²ÎÊý¡£
//nSubCMD:  0~7,see "102-PS242-43-Tau2_Quark_SoftwareIDD_Rev130.pdf"
//0x0100=RAD_EMISSIVITY
//0x0101=RAD_TBKG_X100
//0x0102=RAD_TRANSMISSION_WIN
//0x0103= RAD_TWIN_X100
//0x0104= RAD_TAU_ATM
//0x0105= RAD_TATM_X100
//0x0106=RAD_REFL_WIN
//0x0107=RAD_TREFL_X100
int camTau2_Get_Scene_Para(ir_dev_handle_t fd,int nSubCMD,int* pnV)
{
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_LENS_RESPONSE_PARAMS;
	aCamData.nDataLen = 2;
	aCamData.lpData[0]= 0x01;
	aCamData.lpData[1]= nSubCMD;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		short* pwData = (short*)(aCamData.lpResponse);
		if(pnV!=NULL)
			*pnV = be16_to_le16(pwData[0]);
	}
	return nRet;
}

int camTau2_Set_Scene_Para(ir_dev_handle_t fd,int nSubCMD,int nV)
{
	stCamOpData aCamData;
	short* pData=(short*)aCamData.lpData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_LENS_RESPONSE_PARAMS;
	aCamData.nDataLen = 4;
	aCamData.lpData[0]= 0x01;
	aCamData.lpData[1]= nSubCMD;
	pData[1]=be16_to_le16(nV);
	aCamData.nWantRcvLen = FIXED_CMD_LEN +0;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	return nRet;
}

//ÕûÐÎÖµ×ª»»Îª¸¡µãµÄ¾µÍ·FÊý
//(4096-65535) <=> (0.5-7.9999)
double V2F(int nV)
{
	const double Y1=7.9999;
	const double Y0=0.5;
	const double X1=65535.0;
	const double X0=4096.0;
	double K=(Y1-Y0)/(X1-X0);
	double B=0.5;
	return (K*(nV-X0)+B);
}

//¸¡µãµÄ¾µÍ·FÊý×ª»»ÎªÕûÐÎÖµ
//(4096-65535) <=> (0.5-7.9999)
WORD F2V(double fF)
{
	const double Y1=7.9999;
	const double Y0=0.5;
	const double X1=65535.0;
	const double X0=4096.0;
	double K=(Y1-Y0)/(X1-X0);
	double B=0.5;

	return ( (fF - B)/K + X0 + 0.5);
}

//ÕûÐÎÖµ×ª»»Îª¸¡µãµÄ¾µÍ·Í¸¹ýÂÊ
//(4096-8192) <=> (0.5-1.0)
double V2Trans(int nV)
{
	const double Y1=7.9999;
	const double Y0=0.5;
	const double X1=65535.0;
	const double X0=4096.0;
	double K=(Y1-Y0)/(X1-X0);
	double B=0.5;
	return (K*(nV-X0)+B);
}

//¸¡µãµÄ¾µÍ·Í¸¹ýÂÊ×ª»»ÎªÕûÐÎÖµ
//(4096-8192) <=> (0.5-1.0)
WORD Trans2V(double fTrans)
{
	const double Y1=7.9999;
	const double Y0=0.5;
	const double X1=65535.0;
	const double X0=4096.0;
	double K=(Y1-Y0)/(X1-X0);
	double B=0.5;

	return ( (fTrans - B)/K + X0 + 0.5);
}


//»ñÈ¡¾µÍ·²ÎÊý
//nLensID:	0=Lens #0, 1=Lens #1
//pfLenF:	¾µÍ·FÊý£¬4096-65535 (0.5-7.9999)
//pfLenTransmission£º	¾µÍ·Í¸¹ýÂÊ£¬4096-8192 (0.5-1.0)
int camTau2_Get_Lens_Para(ir_dev_handle_t fd,int nLensID,double* pfLenF,double* pfLenTransmission)
{
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_LENS_RESPONSE_PARAMS;
	aCamData.nDataLen = 2;

	aCamData.lpData[0]= 0x00;
	aCamData.lpData[1]= nLensID;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +4;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		short* pwData = (short*)(aCamData.lpResponse);
		if(pfLenF!=NULL)
		{
			int nV = be16_to_le16(pwData[0]);
			*pfLenF=V2F(nV);
		}
		if(pfLenTransmission!=NULL)
		{
			int nV = be16_to_le16(pwData[1]);
			*pfLenTransmission=V2Trans(nV);
		}
	}
	return nRet;
}

//ÉèÖÃ¾µÍ·²ÎÊý
//nLensID:	0=Lens #0, 1=Lens #1
//fLenF:	¾µÍ·FÊý£¬4096-65535 (0.5-7.9999)
//fLenTransmission£º	¾µÍ·Í¸¹ýÂÊ£¬4096-8192 (0.5-1.0)
int camTau2_Set_Lens_Para(ir_dev_handle_t fd,int nLensID,double fLenF,double fLenTransmission)
{
	stCamOpData aCamData;
	short* pData=(short*)aCamData.lpData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_LENS_RESPONSE_PARAMS;
	aCamData.nDataLen = 6;
	aCamData.lpData[0]= 0x00;
	aCamData.lpData[1]= nLensID;

	WORD nV = F2V(fLenF);
	pData[1]=be16_to_le16(nV);

	nV = Trans2V(fLenTransmission);
	pData[2]=be16_to_le16(nV);
	aCamData.nWantRcvLen = FIXED_CMD_LEN +0;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	return nRet;
}


int camTau2_Get_FPA_T(ir_dev_handle_t fd,double* pdT)
{
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_READ_SENSOR;
	aCamData.nDataLen = 2;
	aCamData.lpData[0]= 0x00;
	aCamData.lpData[1]= 0x00;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		short* pwData = (short*)(aCamData.lpResponse);
		short nV = be16_to_le16(pwData[0]);
		if(pdT!=NULL)
			*pdT = nV/10.0;
	}
	return nRet;
}

int camTau2_Get_Housing_T(ir_dev_handle_t fd,double* pdT)
{
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_READ_SENSOR;
	aCamData.nDataLen = 2;
	aCamData.lpData[0]= 0x00;
	aCamData.lpData[1]= 0x0A;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		short* pwData = (short*)(aCamData.lpResponse);
		short nV = be16_to_le16(pwData[0]);
		if(pdT!=NULL)
			*pdT = nV/100.0;
	}
	return nRet;
}

//nMode:	0:  low resolution mode;
//			1:  high resolution mode.
int camTau2_Get_TLinOutputMode(ir_dev_handle_t fd,WORD* pMode)
{
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_TLIN_COMMANDS;
	aCamData.nDataLen = 2;
	aCamData.lpData[0]= 0x00;
	aCamData.lpData[1]= 0x10;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		WORD* pwData = (WORD*)(aCamData.lpResponse);
		if(pMode!=NULL)
			*pMode = be16_to_le16(pwData[0]);
	}
	return nRet;
}

//nMode:	0:  low resolution mode;
//			1:  high resolution mode.
int camTau2_Set_TLinOutputMode(ir_dev_handle_t fd,int nMode)
{
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_TLIN_COMMANDS;
	aCamData.nDataLen = 4;
	aCamData.lpData[0]= 0x00;
	aCamData.lpData[1]= 0x10;
	aCamData.lpData[2]= 0x00;
	
	if(nMode==0)
		aCamData.lpData[3]= 0x00;
	else
		aCamData.lpData[3]= 0x01;

	aCamData.nWantRcvLen = FIXED_CMD_LEN +0;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	return nRet;
}


int camTau2_Get_TLinEnableStatus(ir_dev_handle_t fd,WORD* pStatus)
{
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_TLIN_COMMANDS;
	aCamData.nDataLen = 2;
	aCamData.lpData[0]= 0x00;
	aCamData.lpData[1]= 0x40;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		WORD* pwData = (WORD*)(aCamData.lpResponse);
		if(pStatus!=NULL)
			*pStatus = be16_to_le16(pwData[0]);
	}
	return nRet;
}

int camTau2_Set_TLinEnableStatus(ir_dev_handle_t fd,int nEnable)
{
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_TLIN_COMMANDS;
	aCamData.nDataLen = 4;
	aCamData.lpData[0]= 0x00;
	aCamData.lpData[1]= 0x40;
	aCamData.lpData[2]= 0x00;
	if(nEnable==0)
		aCamData.lpData[3]= 0x00;
	else
		aCamData.lpData[3]= 0x01;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +0;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	return nRet;
}


//*pnFFCMode:		can only be: 0(manual),1(auto),2(external)
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_FFC_MODE(ir_dev_handle_t fd,int* pnFFCMode)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_FFC_MODE_SELECT;
	aCamData.nDataLen = 0;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +0;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		BYTE* pbData = (BYTE*)(aCamData.lpResponse);
		//(3.2)
		if(pnFFCMode != NULL)
			*pnFFCMode = pbData[1];
		return IR_E_OK;
	}
	else
		return nRet;
}


//nFFCMode:		can only be: 0(manual),1(auto),2(external)
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_FFC_MODE(ir_dev_handle_t fd,int nFFCMode)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_FFC_MODE_SELECT;
	aCamData.lpData[0]= 0;
	aCamData.lpData[1]= nFFCMode;		
	aCamData.nDataLen = 2;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		BYTE* pbData = (BYTE*)(aCamData.lpResponse);
		//(3.2)
		BYTE bAGCType = pbData[1];
		return IR_E_OK;
	}
	else
		return nRet;
}

//±£´æÉèÖÃ
int camTau2_SaveSetting(ir_dev_handle_t fd)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_SET_DEFAULTS;
	aCamData.nDataLen = 0;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +0;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{

		return IR_E_OK;
	}
	else
		return nRet;
}

//»Ö¸´³ö³§ÉèÖÃ
int camTau2_RestoreFactoryDefault(ir_dev_handle_t fd)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_RESET_FACTORY_DEFAULTS;
	aCamData.nDataLen = 0;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +0;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{

		return IR_E_OK;
	}
	else
		return nRet;
}

//Ïà»ú¸´Î»
int camTau2_ResetCam(ir_dev_handle_t fd)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_CAMERA_RESET;
	aCamData.nDataLen = 0;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +0;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{

		return IR_E_OK;
	}
	else
		return nRet;
}

//*pnVideoOrientation:		can only be: 0,1,2,3,4,5,6
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_VIDEO_ORIENTATION(ir_dev_handle_t fd,int* pnVideoOrientation)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_VIDEO_ORIENTATION;
	aCamData.nDataLen = 0;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +0;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		BYTE* pbData = (BYTE*)(aCamData.lpResponse);
		//(3.2)
		if(pnVideoOrientation != NULL)
			*pnVideoOrientation = pbData[1];
		return IR_E_OK;
	}
	else
		return nRet;
}


//nVideoOrientation:		can only be: 0,1,2,3
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_VIDEO_ORIENTATION(ir_dev_handle_t fd,int nVideoOrientation)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_VIDEO_ORIENTATION;
	aCamData.lpData[0]= 0;
	aCamData.lpData[1]= nVideoOrientation;		
	aCamData.nDataLen = 2;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		BYTE* pbData = (BYTE*)(aCamData.lpResponse);
		//(3.2)
		BYTE bVideoOrientation = pbData[1];
		return IR_E_OK;
	}
	else
		return nRet;
}

//*pnMode:		can only be: 0,1,2,3
//0x0000 = display off
//0x0001 = numeric only
//0x0002 = thermometer only
//0x0003 = numeric & thermometer
//return:
//	0:	ok
//	<0:	error
int camTau2_Get_TAU2_SPOT_DISPLAY(ir_dev_handle_t fd,int* pnMode)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_SPOT_DISPLAY;
	aCamData.nDataLen = 0;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +0;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		BYTE* pbData = (BYTE*)(aCamData.lpResponse);
		//(3.2)
		if(pnMode != NULL)
			*pnMode = pbData[1];
		return IR_E_OK;
	}
	else
		return nRet;
}


//nMode:		can only be: 0,1,2,3
//0x0000 = display off
//0x0001 = numeric only
//0x0002 = thermometer only
//0x0003 = numeric & thermometer
//return:
//	0:	ok
//	<0:	error
int camTau2_Set_SPOT_DISPLAY(ir_dev_handle_t fd,int nMode)
{
	//(1)
	stCamOpData aCamData;
	memset(&aCamData,0,sizeof(stCamOpData));
	aCamData.nFuncCode = TAU2_SPOT_DISPLAY;
	aCamData.lpData[0]= 0;
	aCamData.lpData[1]= nMode;		
	aCamData.nDataLen = 2;
	aCamData.nWantRcvLen = FIXED_CMD_LEN +2;

	//(2)
	int nRet = ir_Wr2Cam_WaitResponse(fd,&aCamData);
	if(nRet == IRCAM_OK)
	{
		BYTE* pbData = (BYTE*)(aCamData.lpResponse);
		//(3.2)
		BYTE bMode = pbData[1];
		return IR_E_OK;
	}
	else
		return nRet;
}
