/********************************************************************************
** Form generated from reading UI file 'palettedlg.ui'
**
** Created by: Qt User Interface Compiler version 5.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PALETTEDLG_H
#define UI_PALETTEDLG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QDialogButtonBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QRadioButton>

QT_BEGIN_NAMESPACE

class Ui_PaletteDlg
{
public:
    QDialogButtonBox *buttonBox;
    QRadioButton *radioButton;
    QRadioButton *radioButton_2;
    QRadioButton *radioButton_3;
    QRadioButton *radioButton_4;
    QRadioButton *radioButton_5;
    QRadioButton *radioButton_6;
    QRadioButton *radioButton_7;
    QRadioButton *radioButton_8;
    QRadioButton *radioButton_9;
    QRadioButton *radioButton_10;
    QRadioButton *radioButton_11;
    QRadioButton *radioButton_12;

    void setupUi(QDialog *PaletteDlg)
    {
        if (PaletteDlg->objectName().isEmpty())
            PaletteDlg->setObjectName(QStringLiteral("PaletteDlg"));
        PaletteDlg->resize(400, 358);
        buttonBox = new QDialogButtonBox(PaletteDlg);
        buttonBox->setObjectName(QStringLiteral("buttonBox"));
        buttonBox->setGeometry(QRect(30, 280, 341, 32));
        buttonBox->setOrientation(Qt::Horizontal);
        buttonBox->setStandardButtons(QDialogButtonBox::Cancel|QDialogButtonBox::Ok);
        radioButton = new QRadioButton(PaletteDlg);
        radioButton->setObjectName(QStringLiteral("radioButton"));
        radioButton->setGeometry(QRect(50, 20, 117, 22));
        radioButton->setChecked(false);
        radioButton_2 = new QRadioButton(PaletteDlg);
        radioButton_2->setObjectName(QStringLiteral("radioButton_2"));
        radioButton_2->setGeometry(QRect(230, 20, 117, 22));
        radioButton_3 = new QRadioButton(PaletteDlg);
        radioButton_3->setObjectName(QStringLiteral("radioButton_3"));
        radioButton_3->setGeometry(QRect(50, 60, 117, 22));
        radioButton_4 = new QRadioButton(PaletteDlg);
        radioButton_4->setObjectName(QStringLiteral("radioButton_4"));
        radioButton_4->setGeometry(QRect(230, 60, 117, 22));
        radioButton_5 = new QRadioButton(PaletteDlg);
        radioButton_5->setObjectName(QStringLiteral("radioButton_5"));
        radioButton_5->setGeometry(QRect(50, 100, 117, 22));
        radioButton_6 = new QRadioButton(PaletteDlg);
        radioButton_6->setObjectName(QStringLiteral("radioButton_6"));
        radioButton_6->setGeometry(QRect(230, 100, 117, 22));
        radioButton_7 = new QRadioButton(PaletteDlg);
        radioButton_7->setObjectName(QStringLiteral("radioButton_7"));
        radioButton_7->setGeometry(QRect(50, 140, 117, 22));
        radioButton_7->setChecked(true);
        radioButton_8 = new QRadioButton(PaletteDlg);
        radioButton_8->setObjectName(QStringLiteral("radioButton_8"));
        radioButton_8->setGeometry(QRect(230, 140, 117, 22));
        radioButton_9 = new QRadioButton(PaletteDlg);
        radioButton_9->setObjectName(QStringLiteral("radioButton_9"));
        radioButton_9->setGeometry(QRect(50, 180, 117, 22));
        radioButton_10 = new QRadioButton(PaletteDlg);
        radioButton_10->setObjectName(QStringLiteral("radioButton_10"));
        radioButton_10->setGeometry(QRect(230, 180, 117, 22));
        radioButton_11 = new QRadioButton(PaletteDlg);
        radioButton_11->setObjectName(QStringLiteral("radioButton_11"));
        radioButton_11->setGeometry(QRect(50, 220, 117, 22));
        radioButton_12 = new QRadioButton(PaletteDlg);
        radioButton_12->setObjectName(QStringLiteral("radioButton_12"));
        radioButton_12->setGeometry(QRect(230, 220, 117, 22));

        retranslateUi(PaletteDlg);
        QObject::connect(buttonBox, SIGNAL(accepted()), PaletteDlg, SLOT(accept()));
        QObject::connect(buttonBox, SIGNAL(rejected()), PaletteDlg, SLOT(reject()));

        QMetaObject::connectSlotsByName(PaletteDlg);
    } // setupUi

    void retranslateUi(QDialog *PaletteDlg)
    {
        PaletteDlg->setWindowTitle(QApplication::translate("PaletteDlg", "Dialog", 0));
        radioButton->setText(QApplication::translate("PaletteDlg", "color1", 0));
        radioButton_2->setText(QApplication::translate("PaletteDlg", "ice_fire", 0));
        radioButton_3->setText(QApplication::translate("PaletteDlg", "color2", 0));
        radioButton_4->setText(QApplication::translate("PaletteDlg", "ironbow1", 0));
        radioButton_5->setText(QApplication::translate("PaletteDlg", "fusion", 0));
        radioButton_6->setText(QApplication::translate("PaletteDlg", "ironbow2", 0));
        radioButton_7->setText(QApplication::translate("PaletteDlg", "globow", 0));
        radioButton_8->setText(QApplication::translate("PaletteDlg", "rain", 0));
        radioButton_9->setText(QApplication::translate("PaletteDlg", "gray0to255", 0));
        radioButton_10->setText(QApplication::translate("PaletteDlg", "rainbow", 0));
        radioButton_11->setText(QApplication::translate("PaletteDlg", "gray255to0", 0));
        radioButton_12->setText(QApplication::translate("PaletteDlg", "sepia", 0));
    } // retranslateUi

};

namespace Ui {
    class PaletteDlg: public Ui_PaletteDlg {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PALETTEDLG_H
