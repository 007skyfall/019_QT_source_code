
#include <sys/types.h>
#include <sys/stat.h>
//#include <io.h>
//#include <direct.h>
//#include "Shlwapi.h"
#include "math.h"
#include "ImgProc.h"

const int g_2POWSize[17] = { 1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384, 32768, 65536 };

/*
����:
	ͳ��ֱ��ͼ���ݡ�

����:
	ImgPara *pImg�������ͼ��ṹָ��
	int *pHistData, �����ֱ��ͼ����ָ��,��Ҫ�ѿ����ڴ�ռ�

����ֵ:
	TRUE��������ȷ�����ݴ����pHistData�У�
	FALSE����������
*/
BOOL MakeHistogram( ImgPara *pImg, int *pHistData )
{
    int i = 0;
    int j = 0;

    if ( pImg == NULL || pHistData == NULL )
    {
        //ErrID2Log( "MakeHistogram", ERR_INVALID_PARA );
        return FALSE;
    }

    BYTE* pDataBy = NULL;

    WORD* pDataWd = NULL;
    uint32_t* pDataDw = NULL;

    //int GrayLevel = ( int )pow( ( double )2, pImg->wBpps );
	int GrayLevel = g_2POWSize[pImg->wBpps];

    for ( i = 0; i < GrayLevel; i++ )
        pHistData[i] = 0;      //ԭʼֱ��ͼ����

    //ͳ��ֱ��ͼ
    int npos = 0;

    //����ͼ��λ��С��8
    if ( pImg->wBpps <= 8 )
    {
        pDataBy = ( unsigned char * )pImg->pData;

        for ( i = 0; i < ( int )pImg->nHeight; i++ )
        {
            for ( j = 0; j < pImg->nWidth; j++ )
            {
                if ( pDataBy[npos] >= GrayLevel )
                {
                    pDataBy[npos] = GrayLevel - 1;
                }

                pHistData[pDataBy[npos]]++;

                npos++;
            }
        }
    }

    //����ͼ��λ����8��16֮��
    else if ( pImg->wBpps <= 16 && pImg->wBpps > 8 )
    {
        pDataWd = ( unsigned short * )pImg->pData;

        for ( i = 0; i < ( int )pImg->nHeight; i++ )
        {
            for ( j = 0; j < pImg->nWidth; j++ )
            {
                if ( pDataWd[npos] >= GrayLevel )
                {
                    //return FALSE;
                    pDataWd[npos] = GrayLevel - 1;
                }

                pHistData[pDataWd[npos]]++;

                npos++;
            }
        }
    }

    //����ͼ��λ����16��32֮��
    else if ( pImg->wBpps <= 32 && pImg->wBpps > 16 )
    {
        pDataDw = ( uint32_t * )pImg->pData;

        for ( i = 0; i < ( int )pImg->nHeight; i++ )
        {
            for ( j = 0; j < pImg->nWidth; j++ )
            {
                if ( pDataDw[npos] >= GrayLevel )
                {
                    pDataDw[npos] = GrayLevel - 1;
                }

                pHistData[pDataDw[npos]]++;

                npos++;
            }
        }
    }
    else
    {
        //ErrID2Log( "MakeHistogram", ERR_BPPS_NOT_MATCH );
        return FALSE;
    }

    return TRUE;
}

void MakeLUT(BYTE *pLUT,uint32_t *pHistSum,int nLUT_Len,int pixNum,int nPlatGrayLevel)
{
	int i;
	for(i=0;i<nLUT_Len;i++)
		pLUT[i] = ( BYTE )( nPlatGrayLevel * pHistSum[i] / pixNum );
}

//��ȥ�ڵ�ƽ��
int AdjMinMax(WORD* pRaw16,int nIMG_WID,int nIMG_HEI)
{
	int nImgSize = nIMG_WID*nIMG_HEI;
	int nMin=16384;
	int nMax=0;
	int i;
	for(i=0;i<nImgSize;i++)
	{
		nMin=min(nMin,pRaw16[i]);
		nMax=max(nMax,pRaw16[i]);
	}
	int nD_MM = nMax - nMin;
	nMin = nMin + nD_MM*0.05;
	nMax = nMax - nD_MM*0.05;

	for(i=0;i<nImgSize;i++)
	{
		if(pRaw16[i] < nMin)
			pRaw16[i] = nMin;
		else if(pRaw16[i] > nMax)
			pRaw16[i] = nMax;
	}
	return 0;
}


/*
����:

      ����ƽֱ̨��ͼ���������ݱ任.
	  �ò����������

����:

	ImgPara *pImg�������ͼ��ṹָ��
	ImgPara *pOutImg�������ͼ��ṹָ��
	int nPlatLevel�������Platֵ
	int nPlatGrayLevel,����ı任�����Ҷȼ�
	bInvertIMG:		�����ͼ���Ƿ����·�ת

����ֵ:

	  TRUE��������ȷ�����ݴ����pOutImg�У�
	  FALSE����������
*/
BOOL PlatEqual_2( ImgPara *pInImg,  ImgPara *pOutImg,  int nPlatLevel, int nPlatGrayLevel, BOOL bAdjMinMax,BOOL bInvertIMG)
{
    uint32_t *pHistogramDataOrg = NULL;
    uint32_t *pHistogramData = NULL;
    uint32_t *pHistSum = NULL;
	BYTE *pLUT = NULL;

    int i = 0;
    int j = 0;

	if(bAdjMinMax)
		AdjMinMax(( unsigned short * )pInImg->pData,pInImg->nWidth,pInImg->nHeight);

    //int InGrayLevel = ( int )pow( ( double )2, pInImg->wBpps );
	int InGrayLevel = g_2POWSize[pInImg->wBpps];
    int RealMaxThres = InGrayLevel - 1;
    int RealMinThres = 0;

    int grayLevel = abs( RealMaxThres - RealMinThres + 1 ); //׼ȷ�����˵�

    //����ָ���ڴ�
    pHistogramDataOrg = ( uint32_t * )malloc( InGrayLevel * sizeof( uint32_t ) );

    if ( pHistogramDataOrg == NULL )
    {
        //ErrID2Log( "PlatEqual", ERR_ALLOC_MEMORY );
        return FALSE;
    }

    pHistogramData = ( uint32_t * )malloc( grayLevel * sizeof( uint32_t ) );

    if ( pHistogramData == NULL )
    {
        free( pHistogramDataOrg );
        //ErrID2Log( "PlatEqual", ERR_ALLOC_MEMORY );
        return FALSE;
    }

    pHistSum = ( uint32_t * )malloc( grayLevel * sizeof( uint32_t ) );

    if ( pHistSum == NULL )
    {
        free( pHistogramDataOrg );
        free( pHistogramData );
        //ErrID2Log( "PlatEqual", ERR_ALLOC_MEMORY );
        return FALSE;
    }

    pLUT = ( BYTE * )malloc( grayLevel * sizeof( BYTE ) );

    if ( pLUT == NULL )
    {
        free( pHistogramDataOrg );
        free( pHistogramData );
		free( pHistSum );
        //ErrID2Log( "PlatEqual", ERR_ALLOC_MEMORY );
        return FALSE;
    }

    for ( i = 0; i < InGrayLevel ; i++ )
    {
        pHistogramDataOrg[i] = 0;
    }

    for ( i = 0; i < grayLevel; i++ )
    {
        pHistogramData[i] = 0;
        pHistSum[i] = 0;
    }

    int pos_raw = 0;

    int pos = 0;

    BYTE* pInDataBy = NULL;
    BYTE* pOutDataBy = NULL;
    WORD* pInDataWd = NULL;
    WORD* pOutDataWd = NULL;
    DWORD* pInDataDw = NULL;
    DWORD* pOutDataDw = NULL;

    //ͳ��ֱ��ͼ
    MakeHistogram( pInImg, ( int * )pHistogramDataOrg );

#if 0
	FILE* fp=fopen("g:\\hist_hist.txt","wt");
	if(fp!=NULL)
	{
		for(i=0;i<16384;i++)
		{
			fprintf(fp,"%d\t%d\n",i,pHistogramDataOrg[i]);
		}
		fclose(fp);
	}
#endif

    int pHist = 0 ;
    int sum = 0;
    int pixNum = 0;

    //����PLATEAU_LEVELֵ����ͳ��ֱ��ͼ

    for ( i = 0; i < grayLevel; i++ )
    {
        //��PLATEAU_LEVELֵ�Ƚ�ͳ��
        if ( ( i + RealMinThres ) <= ( InGrayLevel - 1 ) )
        {
            pHistogramData[i] = pHistogramDataOrg[i+RealMinThres] > nPlatLevel
                                ? nPlatLevel : ( pHistogramDataOrg[i+RealMinThres] );

            sum += pHistogramData[i];  //ֱ��ͼ�ۼ�ֵ

            pHistSum[i] = sum;

            //11.23,������ȡ����ͳ�ƺ���ۼ�ֵ
            pixNum += pHistogramData[i]; //pHistogramDataOrg[i+RealMinThres]; //����ֵ���������
        }
    }

#if 0
	FILE* fp=fopen("g:\\hist_plat_hist.txt","wt");
	fprintf(fp,"��ƽֵ̨���ƺ����������=%d\n",pixNum);
	if(fp!=NULL)
	{
		for(i=0;i<16384;i++)
		{
			fprintf(fp,"%d\t%d\t%d\n",i,pHistogramData[i],pHistSum[i]);
		}
		fclose(fp);
	}
#endif

	MakeLUT(pLUT,pHistSum,grayLevel,pixNum,nPlatGrayLevel);

#if 0
	MakeLUT(pLUT,pHistSum,grayLevel,pixNum+1,nPlatGrayLevel+1);		//ͬFPGA�Ĳ���һ��
	FILE* fp=fopen("g:\\hist_LUT.txt","wt");
	if(fp!=NULL)
	{
		fprintf(fp,"��ƽֵ̨���ƺ����������=%d\n",pixNum);
		fprintf(fp,"i\thist\tP_Hist\tHis_Sum\tLUT\n");
		for(i=0;i<16384;i++)
		{
			fprintf(fp,"%d\t%d\t%d\t%d\t%d\n",i,pHistogramDataOrg[i],pHistogramData[i],pHistSum[i],pLUT[i]);
		}
		fclose(fp);
	}
#endif
	
    pos_raw = 0;

    pos = 0;

    if ( pInImg->wBpps <= 8 )
    {
        if ( pOutImg->wBpps <= 8 )
        {
            pInDataBy = ( unsigned char * )pInImg->pData;
            pOutDataBy = ( unsigned char * )pOutImg->pData;

            for ( i = 0; i < pInImg->nHeight; i++ )
            {
                if(bInvertIMG)
					pos_raw = ( pInImg->nHeight - i - 1 ) * pInImg->nWidth;
				else
					pos_raw = i * pInImg->nWidth;

                for ( j = 0; j < pInImg->nWidth; j++ )
                {
                    if ( pInDataBy[pos_raw] <= RealMinThres )
                    {
                        pOutDataBy[pos] = 0;
                    }
                    else if ( pInDataBy[pos_raw] >= RealMaxThres ) //׼ȷ�����˵�
                    {
                        pOutDataBy[pos] = nPlatGrayLevel;
                    }
                    else
                    {
                        pOutDataBy[pos] = pixNum <= 0 ? 0 : ( BYTE )( nPlatGrayLevel *
                                          pHistSum[pInDataBy[pos_raw] - RealMinThres] / pixNum );
                    }

                    pos++;

                    pos_raw++;
                }
            }
        }
        else
        {
            //ErrID2Log( "PlatEqual", ERR_BPPS_NOT_MATCH );
            return FALSE;
        }
    }
    else if ( pInImg->wBpps > 8 && pInImg->wBpps <= 16 )
    {
        if ( pOutImg->wBpps <= 8 )
        {
            pInDataWd = ( unsigned short * )pInImg->pData;
            pOutDataBy = ( unsigned char * )pOutImg->pData;
            pos_raw = 0;
            pos = 0;

            for ( i = 0; i < pInImg->nHeight; i++ )
            {
				if(bInvertIMG)
					pos_raw = ( pInImg->nHeight - i - 1 ) * pInImg->nWidth;
				else
					pos_raw = i * pInImg->nWidth;

                for ( j = 0; j < pInImg->nWidth; j++ )
                {
					
					pOutDataBy[pos] = pLUT[pInDataWd[pos_raw]];

#if 0
                    if ( pInDataWd[pos_raw] <= RealMinThres )
                    {
                        pOutDataBy[pos] = 0;
                    }
                    else if ( pInDataWd[pos_raw] >= RealMaxThres ) //׼ȷ�����˵�
                    {
                        pOutDataBy[pos] = nPlatGrayLevel;
                    }
                    else
                    {
                        pOutDataBy[pos] = pixNum <= 0 ? 0 : ( BYTE )( nPlatGrayLevel *
                                          pHistSum[pInDataWd[pos_raw] - RealMinThres] / pixNum );
                    }
#endif
                    pos++;

                    pos_raw++;
                }
            }
        }
        else if ( pOutImg->wBpps > 8 && pOutImg->wBpps <= 16 )
        {
            pInDataWd = ( unsigned short * )pInImg->pData;
            pOutDataWd = ( unsigned short * )pOutImg->pData;
            pos_raw = 0;
            pos = 0;

            for ( i = 0; i < pInImg->nHeight; i++ )
            {
				if(bInvertIMG)
					pos_raw = ( pInImg->nHeight - i - 1 ) * pInImg->nWidth;
				else
					pos_raw = i * pInImg->nWidth;

                for ( j = 0; j < pInImg->nWidth; j++ )
                {
                    if ( pInDataWd[pos_raw] <= RealMinThres )
                    {
                        pOutDataWd[pos] = 0;
                    }
                    else if ( pInDataWd[pos_raw] >= RealMaxThres ) //׼ȷ�����˵�
                    {
                        pOutDataWd[pos] = nPlatGrayLevel;
                    }
                    else
                    {
                        pOutDataWd[pos] = pixNum <= 0 ? 0 : ( unsigned short )( nPlatGrayLevel *
                                          pHistSum[pInDataWd[pos_raw] - RealMinThres] / pixNum );
                    }

                    pos++;

                    pos_raw++;
                }
            }
        }
        else
        {
            //ErrID2Log( "PlatEqual", ERR_BPPS_NOT_MATCH );
            return FALSE;
        }
    }
    else
    {
        //ErrID2Log( "PlatEqual", ERR_BPPS_NOT_MATCH );
        return FALSE;
    }

    free( pHistogramData );

    free( pHistogramDataOrg );
    free( pHistSum );
	free(pLUT);

    return TRUE;
}

//--------------------------------------------------
stMultiMinMaxPara g_stMultiMinMaxPara;
stMultiMinMax g_stMultiMinMax;
stSecondMinMax g_stSecondMinMax;
void init_FindMultiMinMax(stMultiMinMaxPara* pPara, stMultiMinMax* p_stMultiMinMax, stSecondMinMax* p_stSecondMinMax)
{
	pPara->nMostMaxV_Num = 5;
	pPara->nMostMinV_Num = 5;
	pPara->nMostSecondMaxV_Num = 100;
	pPara->nMostSecondMinV_Num = 100;
	pPara->fSecondMaxV_ratio = 0.1;
	pPara->fSecondMinV_ratio = 0.1;

	memset(p_stMultiMinMax, 0, sizeof(stMultiMinMax));
	p_stMultiMinMax->p_ptMaxV = (ir_point_t*)malloc(pPara->nMostMaxV_Num*sizeof(ir_point_t));
	p_stMultiMinMax->p_ptMinV = (ir_point_t*)malloc(pPara->nMostMinV_Num*sizeof(ir_point_t));

	memset(p_stSecondMinMax, 0, sizeof(stSecondMinMax));
	p_stSecondMinMax->p_ptSecondMaxV = (ir_ptv*)malloc(pPara->nMostSecondMaxV_Num*sizeof(ir_ptv));
	p_stSecondMinMax->p_ptSecondMinV = (ir_ptv*)malloc(pPara->nMostSecondMinV_Num*sizeof(ir_ptv));
}

void end_FindMultiMinMax(stMultiMinMax* p_stMultiMinMax, stSecondMinMax* p_stSecondMinMax)
{
	if (p_stMultiMinMax)
	{
		SAFE_Free(p_stMultiMinMax->p_ptMaxV);
		SAFE_Free(p_stMultiMinMax->p_ptMinV);
	}
	if (p_stSecondMinMax)
	{
		SAFE_Free(p_stSecondMinMax->p_ptSecondMaxV);
		SAFE_Free(p_stSecondMinMax->p_ptSecondMinV);
	}
}


void rstMultiMax(stMultiMinMax* p_stMultiMinMax)
{
	p_stMultiMinMax->nMaxV_Num = 0;
	p_stMultiMinMax->nMaxV = 0;
}
void rstMultiMin(stMultiMinMax* p_stMultiMinMax)
{
	p_stMultiMinMax->nMinV_Num = 0;
	p_stMultiMinMax->nMinV = 65535;
}
void Add1_MultiMax(stMultiMinMaxPara* pPara,stMultiMinMax* p_stMultiMinMax, int nV, int x, int y)
{
	int num = p_stMultiMinMax->nMaxV_Num;
	if (num < pPara->nMostMaxV_Num)
	{
		p_stMultiMinMax->nMaxV = nV;
		p_stMultiMinMax->p_ptMaxV[num].x = x;
		p_stMultiMinMax->p_ptMaxV[num].y = y;
		p_stMultiMinMax->nMaxV_Num++;
	}
}

void Add1_MultiMin(stMultiMinMaxPara* pPara, stMultiMinMax* p_stMultiMinMax, int nV, int x, int y)
{
	int num = p_stMultiMinMax->nMinV_Num;
	if (num < pPara->nMostMinV_Num)
	{
		p_stMultiMinMax->nMinV = nV;
		p_stMultiMinMax->p_ptMinV[num].x = x;
		p_stMultiMinMax->p_ptMinV[num].y = y;
		p_stMultiMinMax->nMinV_Num++;
	}
}
int FindMultiMinMax(WORD* pRaw16, int nIMG_WID, int nIMG_HEI, stMultiMinMax* pResult)
{
	int nMin = 65536;
	int nMax = 0;
	int i,j;
	int nMin_Last = 65536;
	int nMax_Last = 0;
	int nPos = 0;
	for (i = 0; i<nIMG_HEI; i++)
	{
		for (j = 0; j < nIMG_WID; j++)
		{
			//(1)max
			nMax = max(nMax, pRaw16[nPos]);
			if (nMax > nMax_Last)
			{
				rstMultiMax(&g_stMultiMinMax);
				Add1_MultiMax(&g_stMultiMinMaxPara, &g_stMultiMinMax, nMax, j, i);
				nMax_Last = nMax;
			}
			else if (nMax == nMax_Last)
			{
				Add1_MultiMax(&g_stMultiMinMaxPara, &g_stMultiMinMax, nMax, j, i);
			}

			//(2)min
			if (pRaw16[nPos] > 0)	//�ų�0��
			{
				nMin = min(nMin, pRaw16[nPos]);
				if (nMin < nMin_Last)
				{
					rstMultiMin(&g_stMultiMinMax);
					Add1_MultiMin(&g_stMultiMinMaxPara, &g_stMultiMinMax, nMin, j, i);
					nMin_Last = nMin;
				}
				else if (nMin == nMin_Last)
				{
					Add1_MultiMin(&g_stMultiMinMaxPara, &g_stMultiMinMax, nMin, j, i);
				}
			}
			nPos ++ ;
		}
	}

	return 0;
}


void Add1_SecondMax(stMultiMinMaxPara* pPara, stSecondMinMax* p_stSecondMinMax, int nV, int x, int y)
{
	int num = p_stSecondMinMax->nSecondMaxV_Num;
	if (num < pPara->nMostSecondMaxV_Num)
	{
		p_stSecondMinMax->p_ptSecondMaxV[num].x = x;
		p_stSecondMinMax->p_ptSecondMaxV[num].y = y;
		p_stSecondMinMax->p_ptSecondMaxV[num].v = nV;
		p_stSecondMinMax->nSecondMaxV_Num++;
	}
}

void Add1_SecondMin(stMultiMinMaxPara* pPara, stSecondMinMax* p_stSecondMinMax, int nV, int x, int y)
{
	int num = p_stSecondMinMax->nSecondMinV_Num;
	if (num < pPara->nMostSecondMinV_Num)
	{
		p_stSecondMinMax->p_ptSecondMinV[num].x = x;
		p_stSecondMinMax->p_ptSecondMinV[num].y = y;
		p_stSecondMinMax->p_ptSecondMinV[num].v = nV;
		p_stSecondMinMax->nSecondMinV_Num++;
	}
}

void FindSecondMinMax(WORD* pRaw16, int nIMG_WID, int nIMG_HEI, stMultiMinMaxPara* pPara, stMultiMinMax* pMinMax, stSecondMinMax* pResult)
{
	int H0 = pMinMax->nMaxV*(1.0 - pPara->fSecondMaxV_ratio);
	int H1 = pMinMax->nMaxV;
	int L0 = pMinMax->nMinV;
	int L1 = pMinMax->nMinV*(1.0 + pPara->fSecondMinV_ratio);

	pResult->nSecondMaxV_Num = pResult->nSecondMinV_Num = 0;
	int nPos = 0;
	for (int i = 0; i < nIMG_HEI; i++)
	{
		for (int j = 0; j < nIMG_WID; j++)
		{
			int nV = pRaw16[nPos];
			if ((nV > H0) && (nV <= H1))
			{
				Add1_SecondMax(&g_stMultiMinMaxPara, &g_stSecondMinMax, nV, j, i);
			}
			else if ((nV >= L0) && (nV < L1))
			{
				Add1_SecondMin(&g_stMultiMinMaxPara, &g_stSecondMinMax, nV, j, i);
			}
			nPos++;
		}
	}
}
