#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QDesktopWidget>
#include <QDir>
#include <QDateTime>
#include <QDebug>
#include "palettedlg.h"

#include <QtCore/QFile>
#include <QtCore/QTextStream>

#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#include "t_dlg.h"
#include "tau2_ctl.h"

#include "ImgProc.h"

extern stMultiMinMax g_stMultiMinMax;

typedef struct tagQPal
{
char strID[8];
short nStart;
short nEnd;
}QPal;

MainWindow *g_MainWindow = NULL;

int g_fps_count = 0;
int g_total_cnt = 0;

struct timeval g_lastTime;
struct timeval g_nowTime;

ir_net_status_callback_func_t ir_net_status(ir_net_status_t *status);
ir_net_status_t g_net_st;


ir_net_status_callback_func_t ir_net_status(ir_net_status_t *status)
{
    memcpy(&g_net_st,status,sizeof(ir_net_status_t));

    char lpStr[64];

    if(g_net_st.status==0)	//
    {
        if(g_MainWindow->m_pDev!=NULL)
        {
            if(g_MainWindow->m_pDev->m_LastVideoFourcc != -1)	//恢复以前的图像模式
            {
                ir_video_palette_t vidFourcc = (ir_video_palette_t)g_MainWindow->m_pDev->m_LastVideoFourcc;


                g_MainWindow->m_pDev->DevCtl(SET_CAM_VIDEO_FORCC,&vidFourcc);

                qDebug("恢复以前的图像模式!!!");
            }
        }
        //sprintf(lpStr,"%d月%d日,%02d:%02d:%02d,连接成功",atime.GetMonth(),atime.GetDay(),atime.GetHour(),atime.GetMinute(),atime.GetSecond());
        //SaveLogInfo(m_lpIP,"连接成功",g_lpLogPath,m_bLogOn);

        QString str = g_MainWindow->m_strIp + " 连接成功";
        g_MainWindow->m_label1->setText(str);

    }
    else
    {
        //sprintf(lpStr,"%d月%d日,%02d:%02d:%02d,网络断开",atime.GetMonth(),atime.GetDay(),atime.GetHour(),atime.GetMinute(),atime.GetSecond());
        //SaveLogInfo(m_lpIP,"网络断开",g_lpLogPath,m_bLogOn);

        QString str = g_MainWindow->m_strIp + " 网络断开";
        g_MainWindow->m_label1->setText(str);
    }

    return 0;
}


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);


    g_MainWindow = this;

    m_pDev = NULL;
    m_pPalette = new BYTE[4*256];
    for (int i = 0; i < 256; i++)
    {
        BYTE n = (BYTE)i;
        m_pPalette[i*4+0] = n;
        m_pPalette[i*4+1] = n;
        m_pPalette[i*4+2] = n;
        m_pPalette[i*4+3] = 0;
    }

    m_nIndx_Palette = 7;
    SetPalette("globow_adj.Pal");

    m_VideoPalette = IR_VIDEO_R080;

    int width=QApplication::desktop()->width();
    int height=QApplication::desktop()->height();

    this->resize(width*2/3,height*2/3);


    QWidget* Widget = new QWidget(this);
    setCentralWidget(Widget);

    m_BtnOpen = new QPushButton("Open");
    m_BtnStart = new QPushButton("Start");
    m_BtnStop = new QPushButton("Stop");
    m_BtnClose = new QPushButton("Close");
    m_Btn8bits = new QPushButton("8Bits");
    m_Btn14bits = new QPushButton("14Bits");
    m_BtnPalette = new QPushButton("调色板");
    m_BtnT = new QPushButton("环境参数");

    QSpacerItem* hSpacer1 = new QSpacerItem(20, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);




    QHBoxLayout *Layout = new QHBoxLayout();
    Layout->addWidget(m_BtnOpen);
    Layout->addWidget(m_BtnStart);
    Layout->addWidget(m_BtnStop);
    Layout->addWidget(m_BtnClose);
    Layout->addWidget(m_Btn8bits);
    Layout->addWidget(m_Btn14bits);
    Layout->addWidget(m_BtnPalette);
    Layout->addWidget(m_BtnT);
    Layout->addSpacerItem(hSpacer1);


    m_ImageView = new QImageViewer();
    m_label1 = new QLabel("就绪 - 未打开设备!");
    m_label1->setFixedHeight(30);
    m_label2 = new QLabel("0,[fps=0.00]");
    m_label2->setFixedHeight(30);

    m_label3 = new QLabel("");
    m_label3->setFixedHeight(30);


    m_ImageView->SetDrawRect(m_ImageView->m_nFactor);

    QHBoxLayout *Layout2 = new QHBoxLayout();
    Layout2->addWidget(m_label1);
    Layout2->addWidget(m_label2);
    Layout2->addWidget(m_label3);


    QVBoxLayout *mainLayout = new QVBoxLayout(Widget);

    mainLayout->addLayout(Layout);
    mainLayout->addLayout(Layout2);

    mainLayout->addWidget(m_ImageView);
    //mainLayout->addSpacerItem(vSpacer1);



    m_BtnStart->setEnabled(false);
    m_BtnStop->setEnabled(false);
    m_BtnClose->setEnabled(false);
    m_Btn8bits->setEnabled(false);
    m_Btn14bits->setEnabled(false);


    connect(m_BtnOpen, SIGNAL(clicked()), this, SLOT(OnClickedOpen()));
    connect(m_BtnStart, SIGNAL(clicked()), this, SLOT(OnClickedStart()));

    connect(m_BtnStop, SIGNAL(clicked()), this, SLOT(OnClickedStop()));
    connect(m_BtnClose, SIGNAL(clicked()), this, SLOT(OnClickedClose()));

    connect(m_Btn8bits, SIGNAL(clicked()), this, SLOT(OnClicked8bits()));
    connect(m_Btn14bits, SIGNAL(clicked()), this, SLOT(OnClicked14bits()));

    connect(m_BtnPalette, SIGNAL(clicked()), this, SLOT(OnClickedPalette()));

    connect(m_BtnT, SIGNAL(clicked()), this, SLOT(OnClickedT()));

    m_buf = new BYTE[m_ImageView->m_width * m_ImageView->m_height * 3];

    m_nTimerId = startTimer(8000);


    m_nTimerId2 = startTimer(500);

}

MainWindow::~MainWindow()
{
    OnClickedClose();

    if(m_nTimerId != 0)
    {
        killTimer(m_nTimerId);
        m_nTimerId = 0;
    }

    if(m_nTimerId2 != 0)
    {
        killTimer(m_nTimerId2);
        m_nTimerId2 = 0;
    }

    if(m_pPalette != NULL)
    {
        delete m_pPalette;
        m_pPalette = NULL;
    }

    if(m_buf != NULL)
    {
        delete m_buf;
        m_buf = NULL;
    }


    delete ui;
}

void MainWindow::timerEvent( QTimerEvent *event )
{

    if(event->timerId() == m_nTimerId)
    {
        if(m_pDev !=NULL)
        {
            m_VideoPalette=m_pDev->m_fmt.fourcc;

            if(m_VideoPalette==IR_VIDEO_R080)
            {
                m_Btn8bits->setEnabled(false);
                m_Btn14bits->setEnabled(true);
            }
            else if(m_VideoPalette==IR_VIDEO_R140)
            {
                m_Btn8bits->setEnabled(true);
                m_Btn14bits->setEnabled(false);
            }
        }

        //qDebug( "timer event, id %d",event->timerId() );

        gettimeofday(&g_nowTime,NULL); //gettimeofday(&g_nowTime,&tz);结果一样


        double ds_Second = (g_nowTime.tv_sec-g_lastTime.tv_sec)+(g_nowTime.tv_usec-g_lastTime.tv_usec)/1000000;
        double fps = 0;
        if(ds_Second < 1)
        {
            fps = 0;
        }
        else
        {
            fps = (double)g_fps_count/ds_Second;
        }

        //(3)
        g_lastTime.tv_sec = g_nowTime.tv_sec;
        g_lastTime.tv_usec = g_nowTime.tv_usec;

        //(4)
        QString str;
        str.sprintf("%d,[fps=%.2f]",g_total_cnt,fps);

        //(5)
        g_fps_count = 0;


        m_label2->setText(str);
    }
    else  if(event->timerId() == m_nTimerId2)
    {
        if(m_pDev != NULL)
        {
            if(m_pDev->m_fmt.fourcc == IR_VIDEO_R140)
            {
                int32_t nMaxV = g_stMultiMinMax.nMaxV;
                int32_t nMinV = g_stMultiMinMax.nMinV;
                if(m_bIs14BitsT)
                {
                    double dV1 = m_pDev->V2Degree_HighResolution(nMaxV);
                    double dV2 = m_pDev->V2Degree_HighResolution(nMinV);

                    char lpInfo[128];
                    sprintf(lpInfo,"温度最大值:%.2f度  最小值:%.2f度",dV1,dV2);
                    m_label3->setText(lpInfo);
                }
            }
            else
            {
                 m_label3->setText("");
            }
        }
        else
        {
             m_label3->setText("");
        }

    }


}
void MainWindow::postMessage()
{

    QEvent *event = new QEvent(QEvent::Type(TEST_EVENT));
    qApp->postEvent(this, event);
}

void MainWindow::customEvent(QEvent *event)
{
     int type = event->type();
     if (type == TEST_EVENT)
     {     
          UpdateImg();
          event->accept();
     }
     else
     {
          QMainWindow::customEvent(event);
     }
}
void MainWindow::UpdateImg()
{
     //qDebug("UpdateImg---++++++m_width=%d ,m_height=%d",m_pDev->m_width,m_pDev->m_height);

     m_pDev->m_bIdle=FALSE;

 #if 1
     if(m_ImageView->m_width!=m_pDev->m_width || m_ImageView->m_height != m_pDev->m_height)
     {
         if(m_buf != NULL)
         {
             delete m_buf;
         }

         m_ImageView->m_width = m_pDev->m_width;
         m_ImageView->m_height = m_pDev->m_height;
         m_buf = new BYTE[m_ImageView->m_width * m_ImageView->m_height * 3];

         m_ImageView->SetDrawRect(m_ImageView->m_nFactor);
     }


     int nPos=0;
     int nPalPos=0;
     for (int i = 0; i < m_ImageView->m_height; i++) {
         for (int j = 0; j < m_ImageView->m_width; j++) {
             int color = ((uchar *)(m_pDev->m_pImg8))[nPos];

             nPalPos = color*4;

             m_buf[nPos*3+0] = m_pPalette[nPalPos+0];
             m_buf[nPos*3+1] = m_pPalette[nPalPos+1];
             m_buf[nPos*3+2] = m_pPalette[nPalPos+2];

             nPos++;
         }
     }

     m_ImageView->m_buf = (uchar *)m_buf;

#endif
     m_ImageView->m_VideoPalette=m_pDev->m_fmt.fourcc;

     m_ImageView->update();

     g_fps_count++;
     g_total_cnt++;

     m_pDev->m_bIdle=TRUE;
}

void MainWindow::OnClickedOpen()
{
    ir_dev_info_t device[MAX_DEV_NUM];
    int	count = 0;

    memset(device,0,MAX_DEV_NUM*sizeof(ir_dev_info_t));

    //(1)
#if 0
   int ret = ir_find_dev(device,(int32_t*)&count,"255.255.255.255");
    //int ret = ir_find_dev(device,(int32_t*)&count,"192.168.1.255");
    if(ret != 0)
    {
        qDebug("No Device!!!");
        m_label1->setText("No Device!!!");
        return;
    }
#else
    int ret =0;
    device[0].ip_addr=inet_addr("192.168.0.201");

#endif
    unsigned char *pIP;
    QString strIP;
    strIP = QString::number(count, 10);

    qDebug("Device = %d",count);

    struct sockaddr_in   src;
    src.sin_addr.s_addr   =  device[0].ip_addr;                 //构建网络地址。


    qDebug("IP = %s",inet_ntoa(src.sin_addr));

    QString str = "Open " +  QString(QLatin1String(inet_ntoa(src.sin_addr))) ;
    m_label1->setText(str);

    m_strIp = str;


    if(m_pDev !=NULL)
    {
        delete[] m_pDev;
        m_pDev = NULL;
    }
    m_pDev = new CqIrDev();



    ret = m_pDev->OpenDev(&device[0], (ir_net_status_callback_func_t)ir_net_status,NULL);
    if(ret != 0)
    {
        delete  m_pDev;
        m_pDev = NULL;

        qDebug("******OpenDev is err! ret=%d",ret);
        m_label1->setText("OpenDev is err!");
        return ;
    }


    qDebug("******OpenDev is ok!");


    if(ret ==0)
    {
        /*int nRet = m_pDev->DevCtl( GET_CAM_VIDEO_FORCC,  &m_VideoPalette);

        if(nRet == 0)
        {
            if(m_VideoPalette==IR_VIDEO_R080)
            {
                m_Btn8bits->setEnabled(false);
                m_Btn14bits->setEnabled(true);
            }
            else if(m_VideoPalette==IR_VIDEO_R140)
            {
                m_Btn8bits->setEnabled(true);
                m_Btn14bits->setEnabled(false);
            }
        }*/

        m_VideoPalette = IR_VIDEO_R140;
        int nRet = m_pDev->DevCtl(SET_CAM_VIDEO_FORCC, &m_VideoPalette);

        m_Btn8bits->setEnabled(true);
        m_Btn14bits->setEnabled(false);

        if (!m_bReadPtTOn)
            OnReadPointT();
    }

    m_BtnOpen->setEnabled(false);
    m_BtnStart->setEnabled(true);
    m_BtnStop->setEnabled(false);
    m_BtnClose->setEnabled(true);

}
void MainWindow::OnClickedStart()
{

    if(m_nStarted)
        return ;

    if(m_pDev !=NULL)
    {
        int ret = m_pDev->StartDev(NULL);
        if(ret != 0)
        {
            qDebug("******ir_start_video is err!");
            return ;
        }


        m_nStarted = 1;
        g_fps_count = 0;
        g_total_cnt = 0;
        gettimeofday(&g_lastTime,NULL); //gettimeofday(&g_nowTime,&tz);结果一样

        m_BtnOpen->setEnabled(false);
        m_BtnStart->setEnabled(false);
        m_BtnStop->setEnabled(true);
        m_BtnClose->setEnabled(true);

    }
}
void MainWindow::OnClickedStop()
{
    if(m_nStarted == 0)
        return ;

    if(m_pDev !=NULL)
    {
        //(1)
        m_pDev->StopDev();

        m_nStarted = 0;

        g_fps_count = 0;
        g_total_cnt = 0;
    }

    m_BtnOpen->setEnabled(false);
    m_BtnStart->setEnabled(true);
    m_BtnStop->setEnabled(false);
    m_BtnClose->setEnabled(true);
}

void MainWindow::OnClickedClose()
{
    if(m_pDev !=NULL)
    {
        qDebug("******MainActivity_close!");
        //(1)
        OnClickedStop();
        qDebug("******MainActivity_close - OnStop!");
        //(2)
        m_pDev->CloseDev();

        qDebug("******MainActivity_close - CloseDev!");
        //(3)
        delete  m_pDev;
        qDebug("******MainActivity_close - delete!");
        m_pDev = NULL;

        qDebug("******MainActivity_close - m_pDev = NULL!");

        //(4)

        m_label1->setText("就绪 - 未打开设备!");
        m_label2->setText("0,[fps=0.00]");

        m_BtnOpen->setEnabled(true);
        m_BtnStart->setEnabled(false);
        m_BtnStop->setEnabled(false);
        m_BtnClose->setEnabled(false);

        m_Btn8bits->setEnabled(false);
        m_Btn14bits->setEnabled(false);
    }
}


void MainWindow::OnClicked8bits()
{
    if(m_VideoPalette!=IR_VIDEO_R080)
    {


        m_VideoPalette=IR_VIDEO_R080;
        int nRet = m_pDev->DevCtl( SET_CAM_VIDEO_FORCC,  &m_VideoPalette);

        if(nRet == 0)
        {
            m_Btn8bits->setEnabled(false);
            m_Btn14bits->setEnabled(true);
        }



    }
}
void MainWindow::OnClicked14bits()
{
    if(m_VideoPalette!=IR_VIDEO_R140)
    {
        m_VideoPalette=IR_VIDEO_R140;
        int nRet = m_pDev->DevCtl( SET_CAM_VIDEO_FORCC,  &m_VideoPalette);
        if(nRet == 0)
        {
            m_Btn8bits->setEnabled(true);
            m_Btn14bits->setEnabled(false);
        }

        if (!m_bReadPtTOn)
            OnReadPointT();
    }
}
void MainWindow::OnClickedPalette()
{

    PaletteDlg *dialog = new PaletteDlg;
    dialog->setPalette(m_nIndx_Palette);
    //dialog->show();
    if (dialog->exec() == QDialog::Accepted)
    {


        QString str =  dialog->GetFileName();
        QString fileName = str + "_adj.Pal";

        SetPalette(fileName);
        m_nIndx_Palette = dialog->m_nIndex;

        qDebug("%s", qPrintable( fileName ) );

    } else
    {
        //qDebug("******OnClickedPalette - 222222222222222");
    }

}
void MainWindow::SetPalette(QString fileName)
{

    QString path;
    QDir dir;
    path=dir.currentPath();
    path += "/Para/" + fileName;
    qDebug("%s", qPrintable( path ) );

    char*  ch;
    QByteArray ba = path.toLatin1();
    ch=ba.data();

    FILE *palette_file;
    if ((palette_file=fopen(ch, "rb")) == NULL) //二进制文件
    {
        fclose(palette_file);
        return ;
    }
    QPal qPal;
    memset(&qPal,0,sizeof(QPal));
    fread(&qPal,sizeof(QPal),1,palette_file);
    if(strcmp(qPal.strID,"QPAL_1")==0) //字符串一致
    {
        fread(m_pPalette,4*(qPal.nEnd - qPal.nStart + 1),1,palette_file);
    }

    fclose(palette_file);

}

void MainWindow::OnClickedT()
{
    T_Dlg *dialog = new T_Dlg;
    dialog->exec();
}

void MainWindow::OnReadPointT()
{
    m_bReadPtTOn = !m_bReadPtTOn;

    WORD Status=0;
    if(m_bReadPtTOn)
    {
        camTau2_Set_TLinEnableStatus(m_pDev->m_ir_handle,1);	//设置为输出14位温度模式
        camTau2_Get_TLinEnableStatus(m_pDev->m_ir_handle,&Status);
        if(Status==1)
        {
            camTau2_Set_TLinOutputMode(m_pDev->m_ir_handle,1);	//1:  high resolution mode.
        }
    }
    else	//恢复普通14位数据模式
    {
        camTau2_Set_TLinEnableStatus(m_pDev->m_ir_handle,0);
    }

    m_bIs14BitsT = (Status==1);
}
