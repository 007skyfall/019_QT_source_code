/*
FLIRºìÍâÏà»úµÄ´®¿Ú¿ØÖÆ¶¨Òå£»
²Î¿¼£º¡¶FLIR_Tau2_CtlID_Quark_Software_IDD.pdf¡·
*/


#ifndef __Q_FLIR_Tau2_CtlID_DEF__
#define __Q_FLIR_Tau2_CtlID_DEF__


#ifdef __cplusplus
extern "C" {
#endif

//(1)
/*
´®¿Ú¿ØÖÆ¹¦ÄÜ¶¨Òå¡£
*/
#define TAU2_NO_OP                      0x00
#define TAU2_SET_DEFAULTS               0x01
#define TAU2_CAMERA_RESET               0x02
#define TAU2_RESET_FACTORY_DEFAULTS     0x03
#define TAU2_SERIAL_NUMBER              0x04
#define TAU2_GET_REVISION               0x05
#define TAU2_BAUD_RATE					0x07
#define TAU2_GAIN_MODE					0x0A
#define TAU2_FFC_MODE_SELECT			0x0B
#define TAU2_DO_FFC						0x0C

#define TAU2_FFC_PERIOD                  0x0D
#define TAU2_FFC_TEMP_DELTA              0x0E
#define TAU2_VIDEO_MODE                  0x0F
#define TAU2_VIDEO_PALETTE               0x10
#define TAU2_VIDEO_ORIENTATION           0x11
#define TAU2_DIGITAL_OUTPUT_MODE         0x12
#define TAU2_AGC_TYPE                    0x13
#define TAU2_CONTRAST                    0x14
#define TAU2_BRIGHTNESS                  0x15
#define TAU2_BRIGHTNESS_BIAS             0x18

#define TAU2_LENS_NUMBER				0x1E
#define TAU2_SPOT_METER_MODE			0x1F
#define TAU2_READ_SENSOR				0x20
#define TAU2_EXTERNAL_SYNC				0x21
#define TAU2_ISOTHERM					0x22
#define TAU2_ISOTHERM_THRESHOLDS		0x23
#define TAU2_TEST_PATTERN				0x25
#define TAU2_VIDEO_COLOR_MODE			0x26
#define TAU2_GET_SPOT_METER				0x2A
#define TAU2_SPOT_DISPLAY				0x2B


#define TAU2_DDE_GAIN					0x2C
#define TAU2_SYMBOL_CONTROL				0x2F
#define TAU2_SPLASH_CONTROL				0x31
#define TAU2_EZOOM_CONTROL				0x32
#define TAU2_FFC_WARN_TIME               0x3C
#define TAU2_AGC_FILTER                  0x3E
#define TAU2_PLATEAU_LEVEL               0x3F
#define TAU2_GET_SPOT_METER_DATA			0x43
#define TAU2_GET_SPOT_METER_COORDINATES		0x43
#define TAU2_SET_SPOT_METER_COORDINATES		0x43
#define TAU2_AGC_ROI                     0x4C
#define TAU2_SHUTTER_TEMP				0x4d

#define TAU2_AGC_MIDPOINT                0x55
#define TAU2_CAMERA_PART                 0x66
#define TAU2_READ_ARRAY_AVERAGE			0x68
#define TAU2_MAX_AGC_GAIN                0x6A
#define TAU2_PAN_AND_TILT                0x70
#define TAU2_VIDEO_STANDARD				0x72
#define TAU2_SHUTTER_POSITION            0x79
#define TAU2_TRANSFER_FRAME				0x82
#define TAU2_TLIN_COMMANDS				0x8E
#define TAU2_CORRECTION_MASK				0xB1

#define TAU2_MEMORY_STATUS				0xC4
#define TAU2_WRITE_NVFFC_TABLE			0xC6
#define TAU2_READ_MEMORY					0xD2		//Ò»´Î×î¶à¶Á256×Ö½Ú
#define TAU2_ERASE_MEMORY_BLOCK			0xD4
#define TAU2_GET_NV_MEMORY_SIZE			0xD5
#define TAU2_GET_MEMORY_ADDRESS			0xD6
#define TAU2_GAIN_SWITCH_PARAMS			0xDB
#define TAU2_DDE_THRESHOLD               0xE2
#define TAU2_SPATIAL_THRESHOLD           0xE3
#define TAU2_LENS_RESPONSE_PARAMS		0xE5

//(2)
//#define DHIR_CODE_BASE			0x7D0	//com base control code	2000		//see dhircam_status.h
#define TAU2_CTL_BASE	0x1000		//4096
#define MK_xCTL_CODE(F_CTL_CODE,sub_ctl_code)	(TAU2_CTL_BASE + (F_CTL_CODE*0x10) + (sub_ctl_code))


//(3)
//remark:
//			_G_:	get
//			_S_:	set
//			_D_:	do
enum xir_control_code_t
{
#if 0
//(1)--------------------------------------------
//ÒÔÏÂÊÇphotonÏà»úµÄ¿ØÖÆ×Ö¡£±£ÁôµÄÄ¿µÄÊÇÎªÁË¼æÈÝ´óºãÔ­À´µÄ¶¨Òå¡£²Î¿¼£ºdhircam.h£ºtypedef enum _dhir_control_code{...}

	DHIR_CTL_MIN = 0x100,

	/*	camera information	
	  *	
	  *	Operate object: dhir_camera_info_t
	  */
	DHIR_GET_VERSION_INFO = 0x100,
	
	
	/*	video format control	
	  *
	  *	Operate object: dhir_format_t
	  */
	DHIR_SET_FORMAT = 0x110,
	DHIR_GET_FORMAT,				// format control	


	/*
	  *	GPIO operation
	  *	
	  *	Operate object: unsigned char value, [bit0:bit3]=>[input/output 0:input/output 3]
	  *
	  *	bit		  gpio level
	  *	 0			Low
	  *	 1			High
	  */
	DHIR_QUERY_INPUT_STATUS = 0x120,
	DHIR_SET_OUTPUT_LEVEL,

	/*
	  *	User password check.
	  *
	  *	If you want to access the User Zone, you must check your password through 
	  *	DHPA_CHECK_PASSWORD.
	  *
	  *	Operation object: dhir_check_password_t
	  */
	DHIR_CHECK_PASSWORD = 0x480,		//verify user password
	

	/*
	  *	Modify user password
	  *
	  *	If you modify the user password, you must pass PW number, Old PW and New PW through
	  *	DHPA_MODIFY_PASSWORD
	  *
	  *	Operate object: dhir_modify_password_t
	  */
	DHIR_MODIFY_PASSWORD,		//modify user password
	
	
	/*	Read user zone data
	  *
	  *	Once you check your user zone password, you can read your user zone data.
	  *
	  *	Operate object: dhir_userdata_t
	  */
	DHIR_READ_USERDATA,

	/*	Write user zone data
	  *
	  *	Once you check your user zone password, you can write your user zone data.
	  *
	  *	Operate object: dhir_userdata_t
	  */
	DHIR_WRITE_USERDATA = 0x483,




	/*	Sets all current settings as power-on defaults
	  *
	  *	Operate object: NULL
	  */
	DHIR_SET_DEFAULTS = 	DHIR_CODE_BASE + 0x01, //2001

	/*	A soft camera reset to the default modes
	  *
	  *	Operate object: NULL
	  */
	DHIR_CAMERA_RESET=	DHIR_CODE_BASE + 0x02,

	/*	Resets camera with factory header values
	  *
	  *	Operate object: NULL
	  */	
	DHIR_RESET_FACTORY_DEFAULTS =	DHIR_CODE_BASE + 0x03,

	/*	Gets the serial number of the camera
	  *
	  *	Operate object: int value. 
	  *
	  *	Result Expression: 0x%08x
	  */	
	DHIR_GET_SERIAL_NUMBER=	DHIR_CODE_BASE + 0x04,

	/*	Gets the firmware / software version
	  *
	  *	Operate object: unsigned char value[8]. 
	  *
	  *	Result Expression:S/W:%d.%d.%d.%d,F/W:%d.%d.%d.%d,value[i++]
	  */	
	DHIR_GET_REVISION =		DHIR_CODE_BASE + 0x05,

	/*	Gets and sets the dynamic-range-control mode
	  *
	  *	Operate object: int value
	  *
	  *	Rang: 
	  *		0x0=Automatic,			//not support
	  *		0x1=Low Gain Only,		//not support
	  *		0x2=High Gain Only,
	  *		0x3=Manual (no switching). 
	  */
	DHIR_GET_GAIN_MODE =	 DHIR_CODE_BASE + 0x0A,		//2010
	DHIR_SET_GAIN_MODE =	 DHIR_CODE_BASE + 0x10A,	
	
	/*	Gets and sets the Flat Field Correction (FFC) Mode
	  *
	  *	Operate object: int value
	  *
	  *	Rang: 
	  *		0x0 = Manual,
	  *		0x1 = Automatic,
	  *		0x2 = External.
	  */
	DHIR_GET_FFC_MODE_SELECT =	DHIR_CODE_BASE + 0x0B,
	DHIR_SET_FFC_MODE_SELECT = DHIR_CODE_BASE + 0x10B,

	
	/*	Commands a flat field correction(FFC)
	  *
	  *	Operate object: NULL
	  */	
	DHIR_DO_FFC =	 DHIR_CODE_BASE +0x0C,	

	/*	Gets and sets the interval (in frames) between automatic FFC
	  *
	  *	Operate object: int value
	  *
	  *	unit:33ms
	  */
	DHIR_GET_FFC_PERIOD=	 DHIR_CODE_BASE + 0x0D,
	DHIR_SET_FFC_PERIOD=			DHIR_CODE_BASE + 0x10D,	

	/*	Gets and sets the temperature difference used to trigger automatic FFC.
	  *
	  *	Operate object: int value
	  *
	  *	unit: 0.1 Degree
	  */
	DHIR_GET_FFC_TEMP_DELTA=		DHIR_CODE_BASE + 0x0E,
	DHIR_SET_FFC_TEMP_DELTA=		DHIR_CODE_BASE + 0x10E,

	/*	Gets and sets the video signal mode. 
	  *
	  *	Setting Freeze frame freezes the image; Setting Zoom zooms the image by 2x.
	  *
	  *	Operate object: int value
	  *
	  *	Rang:
	  *		0x0=Real time,
	  *		0x1=Freeze frame,
	  *		0x4=Zoom,			//Not support
	  */
	DHIR_GET_VIDEO_MODE  =		DHIR_CODE_BASE + 0x0F,
	DHIR_SET_VIDEO_MODE  =		DHIR_CODE_BASE + 0x10F,

	/*	Gets and sets the analog video LUT or intensity transform.
	  *
	  *	Operate object: int value
	  *
	  *	Rang:
	  *		0x0 = White hot
	  *		0x1 = Black hot
	  *		0x2 = Fusion
	  *		0x3 = Rainbow
	  *		0x4 = Globow
	  *		0x5 = Ironbow1
	  *		0x6 = Ironbow2
	  *		0x7 = Sepia
	  *		0x8 = Color1
	  *		0x9 = Color2
	  *		0xA = Ice and fire
	  *		0x0B = Rain
	  */
	DHIR_GET_VIDEO_LUT =			DHIR_CODE_BASE + 0x10,
	DHIR_SET_VIDEO_LUT =			DHIR_CODE_BASE + 0x110,

	/*	Gets and sets the analog video orientation, Digital data is unaffected by the revert setting.
	  *
	  *	Operate object: int value
	  *
	  *	Rang:
	  *		0x0 = Normal
	  *		0x1 = Invert
	  *		0x2 = Revert
	  *		0x3 = Invert + Revert
	  */
	DHIR_GET_VIDEO_ORIENTATION =	DHIR_CODE_BASE + 0x11,
	DHIR_SET_VIDEO_ORIENTATION =	DHIR_CODE_BASE + 0x111,

	/*	Gets and sets the digital output channel mode
	  *
	  *	Operate object: int value
	  *
	  *	Rang:
	  *		0x0 = 14-bit data
	  *		0x1 = 8-bit data
	  *		0x3 = 14-bit unfiltered
	  */	
	DHIR_GET_DIGITAL_OUTPUT_MODE  =	DHIR_CODE_BASE + 0x12,
	DHIR_SET_DIGITAL_OUTPUT_MODE  =	DHIR_CODE_BASE + 0x112,
	
	/*	Gets and sets the image optimization mode(AGC)
	  *
	  *	Operate object: int value
	  *
	  *	Rang:	
	  *		0x0 = plateau histogram
	  *		0x1 = once bright
	  *		0x2 = auto bright
	  *		0x3 = manual
	  *		0x5 = linear 
	  *		0x6 = log
	  */
	DHIR_GET_AGC_TYPE  =	DHIR_CODE_BASE + 0x13,
	DHIR_SET_AGC_TYPE  =	DHIR_CODE_BASE + 0x113,

	/*	Gets and sets the manual contrast value
	  *
	  *	Operate object: int value
	  *
	  *	Rang:	0x0~0xFF
	  */
	DHIR_GET_CONTRAST =	DHIR_CODE_BASE + 0x14,
	DHIR_SET_CONTRAST =			DHIR_CODE_BASE + 0x114,
	
	/*	Gets and sets the manual brightness value
	  *
	  *	Operate object: int value
	  *
	  *	Rang:	0x0~0x3FFF
	  */
	DHIR_GET_BRIGHTNESS=			DHIR_CODE_BASE + 0x15,
	DHIR_SET_BRIGHTNESS=			DHIR_CODE_BASE + 0x115,	

	/*	Gets and sets the brightness bias value in the auto bright mode
	  *
	  *	Operate object: int value
	  *
	  *	Rang:	0x0~0xFFF
	  */
	DHIR_GET_BRIGHTNESS_BIA = 	DHIR_CODE_BASE + 0x18,	//2024
	DHIR_SET_BRIGHTNESS_BIA = 	DHIR_CODE_BASE + 0x118,	//2024

	/*	Gets the FPA temp
	  *
	  *	Operate object:short int value
	  *
	  */
	DHIR_GET_READ_TEMP_SENSOR = DHIR_CODE_BASE + 0x20,

	/*	Enables or disables the external sync feature
	  *
	  *	Operate object: int value
	  *
	  *	Rang:
	  *		0x0 = disabled
	  *		0x1 = slave
	  *		0x2 = master
	  */	
	DHIR_GET_EXTERNAL_SYNC  = 	DHIR_CODE_BASE +  0x21,
	DHIR_SET_EXTERNAL_SYNC  = 	DHIR_CODE_BASE +  0x121,

	/*	Gets and sets the test pattern mode
	  *
	  *	Operate object: int value
	  *
	  *	Rang:
	  *		0x0 = test pattern off
	  *		0x1 = ascending ramp
	  */	
	DHIR_GET_TEST_PATTERN = 		DHIR_CODE_BASE + 0x25,
	DHIR_SET_TEST_PATTERN = 		DHIR_CODE_BASE + 0x125,

	/*	Gets and sets the gain of the DDE filter
	  *
	  *	Operate object: int value
	  *
	  *	Rang:0~0xFF
	  */	
	DHIR_GET_DDE_GAIN  = 			DHIR_CODE_BASE + 0x2C,
	DHIR_SET_DDE_GAIN  = 			DHIR_CODE_BASE + 0x12C,

	/*	Gets and sets the AGC ITT filter valuent value
	  *
	  *	Operate object: int value
	  *
	  *	Rang:
	  *		0x0 = immediate,
	  *		0x1~0xFF = Numerator
	  */	
	DHIR_GET_AGC_FILTER = 			DHIR_CODE_BASE + 0x3E,
	DHIR_SET_AGC_FILTER = 			DHIR_CODE_BASE + 0x13E,

	/*	Specifies the Plateau level for Plateau AGC
	  *
	  *	Operate object:int value, 
	  *
	  *	Rang:0~0x3E8
	  */
	DHIR_GET_PLATEAU_LEVEL  = 		DHIR_CODE_BASE + 0x3F,
	DHIR_SET_PLATEAU_LEVEL  = 		DHIR_CODE_BASE + 0x13F,

	/*	Gets and sets the ITT midpoint offset
	  *
	  *	Operate object:int value, 
	  *
	  *	Rang:0~0xFF
	  */
	DHIR_GET_ITT_MIDPOINT = 		DHIR_CODE_BASE + 0x55,
	DHIR_SET_ITT_MIDPOINT = 		DHIR_CODE_BASE + 0x155,	

	/*	Gets the camera part number
	  *
	  *	Operate object:char str[20]
	  *
	  *	Return Value: 16 Bytes char
	  */
	DHIR_GET_CAMERA_PART  = 		DHIR_CODE_BASE + 0x66,

	/*	Gets and sets the max value of video gain
	  *
	  *	Operate object:int value, 
	  *
	  *	Rang:0~0x800
	  */
	DHIR_GET_MAX_AGC_GAIN  = 		DHIR_CODE_BASE + 0x6A,
	DHIR_SET_MAX_AGC_GAIN  = 		DHIR_CODE_BASE + 0x16A,

	/*	Opens or closes the shutter
	  *
	  *	Operate object:int value, 
	  *
	  *	Rang:
	  *		0x0=open
	  *		0x1=close
	  */
	DHIR_GET_SHUTTER_POSITION  = 	DHIR_CODE_BASE + 0x79,
	DHIR_SET_SHUTTER_POSITION  = 	DHIR_CODE_BASE + 0x179,

	/*	Sets the gain of the DDE filter
	  *
	  *	Operate object:int value, 
	  *
	  *	Rang:0x0~0xFF
	  */
	DHIR_GET_DDE_THRESHOLD  = 	DHIR_CODE_BASE +  0xE2,
	DHIR_SET_DDE_THRESHOLD  = 	DHIR_CODE_BASE +  0x1E2,

	/*	Sets the threshold of the DDE filter
	  *
	  *	Operate object:int value, 
	  *
	  *	Rang:0x0~0xF
	  */
	DHIR_GET_SPATIAL_THRESHOLD =	DHIR_CODE_BASE +  0xE3,	//2227
	DHIR_SET_SPATIAL_THRESHOLD =	DHIR_CODE_BASE +  0x1E3,	//2483
	
	 //zqj 08.10.07
       /*	Write palette ID
	  *
	  *	send palette ID to server.
	  *
	  *	Operate object: dhir_palette_t
	  */

	DHIR_SET_PALETTE_ID = DHIR_CODE_BASE +  0xE4,
	DHIR_GET_PALETTE_ID = DHIR_CODE_BASE +  0x1E4,
	  
	  /*	Write USER ID
	  *
	  *	send USER ID to server.
	  *
	  *	Operate object: 
	  * 
	  * value: 0~11
	  */
	
	DHIR_SET_USER_BITMODE = DHIR_CODE_BASE +  0xE5,
	DHIR_GET_USER_BITMODE = DHIR_CODE_BASE +  0x1E5,

//zqj 2008.11.20
		/*	Write camera plat value 
	  *
	  *	send  camera plat value to server.
	  *
	  *	Operate object: 
	  * 
	  * value: 10~2000
	  */
	
	DHIR_SET_CAMERA_14TO8_PLAT_VALUE = DHIR_CODE_BASE +  0xE6,
	DHIR_GET_CAMERA_14TO8_PLAT_VALUE = DHIR_CODE_BASE +  0x1E6,

	DHIR_CTL_MAX,
#endif
//(2)--------------------------------------------
//ÒÔÏÂÊÇTau2Ïà»úµÄÓÃ»§¿ØÖÆ×Ö
	xir_CtlID_MIN				=MK_xCTL_CODE(TAU2_NO_OP,0),
	xir_CtlID_NO_OP				=MK_xCTL_CODE(TAU2_NO_OP,0),
	xir_CtlID_D_SET_DEFAULTS		=MK_xCTL_CODE(TAU2_SET_DEFAULTS,0),
	xir_CtlID_D_CAMERA_RESET		=MK_xCTL_CODE(TAU2_CAMERA_RESET,0),
	xir_CtlID_D_RESET_FACTORY_DEFAULTS	=MK_xCTL_CODE(TAU2_RESET_FACTORY_DEFAULTS,0),
	xir_CtlID_G_SERIAL_NUMBER			=MK_xCTL_CODE(TAU2_SERIAL_NUMBER,0),
	xir_CtlID_G_GET_REVISION			=MK_xCTL_CODE(TAU2_GET_REVISION,0),
	
	xir_CtlID_G_BAUD_RATE		=MK_xCTL_CODE(TAU2_BAUD_RATE,0),
	xir_CtlID_S_BAUD_RATE		=MK_xCTL_CODE(TAU2_BAUD_RATE,1),
	
	xir_CtlID_G_GAIN_MODE		=MK_xCTL_CODE(TAU2_GAIN_MODE,0),
	xir_CtlID_S_GAIN_MODE		=MK_xCTL_CODE(TAU2_GAIN_MODE,1),
	
	xir_CtlID_G_FFC_MODE_SELECT	=MK_xCTL_CODE(TAU2_FFC_MODE_SELECT,0),
	xir_CtlID_S_FFC_MODE_SELECT	=MK_xCTL_CODE(TAU2_FFC_MODE_SELECT,1),

	xir_CtlID_D_DO_FFC			=MK_xCTL_CODE(TAU2_DO_FFC,0),
	xir_CtlID_D_DO_SHORT_FFC	=MK_xCTL_CODE(TAU2_DO_FFC,1),
	xir_CtlID_D_DO_LONG_FFC		=MK_xCTL_CODE(TAU2_DO_FFC,2),

	xir_CtlID_G_FFC_PERIOD		=MK_xCTL_CODE(TAU2_FFC_PERIOD,0),
	xir_CtlID_S_FFC_PERIOD		=MK_xCTL_CODE(TAU2_FFC_PERIOD,1),
	xir_CtlID_S_FFC_PERIOD_H_L_GAIN		=MK_xCTL_CODE(TAU2_FFC_PERIOD,2),		// for high and low gain

	xir_CtlID_G_FFC_TEMP_DELTA	=MK_xCTL_CODE(TAU2_FFC_TEMP_DELTA,0),
	xir_CtlID_S_FFC_TEMP_DELTA	=MK_xCTL_CODE(TAU2_FFC_TEMP_DELTA,1),
	xir_CtlID_S_FFC_TEMP_DELTA_H_L_GAIN	=MK_xCTL_CODE(TAU2_FFC_TEMP_DELTA,2),	// for high and low gain

	xir_CtlID_G_VIDEO_MODE		=MK_xCTL_CODE(TAU2_VIDEO_MODE,0),
	xir_CtlID_S_VIDEO_MODE		=MK_xCTL_CODE(TAU2_VIDEO_MODE,1),			// analog enable and zoom para

	xir_CtlID_G_VIDEO_PALETTE	=MK_xCTL_CODE(TAU2_VIDEO_PALETTE,0),
	xir_CtlID_S_VIDEO_PALETTE	=MK_xCTL_CODE(TAU2_VIDEO_PALETTE,1),
	
	xir_CtlID_G_VIDEO_ORIENTATION	=MK_xCTL_CODE(TAU2_VIDEO_ORIENTATION,0),
	xir_CtlID_S_VIDEO_ORIENTATION	=MK_xCTL_CODE(TAU2_VIDEO_ORIENTATION,1),
	
	xir_CtlID_G_DIGITAL_OUTPUT_XP_MODE	=MK_xCTL_CODE(TAU2_DIGITAL_OUTPUT_MODE,2),
	xir_CtlID_S_DIGITAL_OUTPUT_XP_MODE	=MK_xCTL_CODE(TAU2_DIGITAL_OUTPUT_MODE,3),
	xir_CtlID_G_DIGITAL_OUTPUT_LVDS_MODE	=MK_xCTL_CODE(TAU2_DIGITAL_OUTPUT_MODE,4),
	xir_CtlID_S_DIGITAL_OUTPUT_LVDS_MODE	=MK_xCTL_CODE(TAU2_DIGITAL_OUTPUT_MODE,5),
	xir_CtlID_G_DIGITAL_OUTPUT_CMOS_BITS	=MK_xCTL_CODE(TAU2_DIGITAL_OUTPUT_MODE,8),
	xir_CtlID_S_DIGITAL_OUTPUT_CMOS_BITS	=MK_xCTL_CODE(TAU2_DIGITAL_OUTPUT_MODE,6),
	xir_CtlID_G_DIGITAL_OUTPUT_LVDS_BITS	=MK_xCTL_CODE(TAU2_DIGITAL_OUTPUT_MODE,7),
	xir_CtlID_S_DIGITAL_OUTPUT_LVDS_BITS	=MK_xCTL_CODE(TAU2_DIGITAL_OUTPUT_MODE,9),

	xir_CtlID_G_AGC_TYPE			=MK_xCTL_CODE(TAU2_AGC_TYPE,0),
	xir_CtlID_S_AGC_TYPE			=MK_xCTL_CODE(TAU2_AGC_TYPE,1),

	xir_CtlID_G_CONTRAST			=MK_xCTL_CODE(TAU2_CONTRAST,0),
	xir_CtlID_S_CONTRAST			=MK_xCTL_CODE(TAU2_CONTRAST,1),

	xir_CtlID_G_BRIGHTNESS		=MK_xCTL_CODE(TAU2_BRIGHTNESS,0),
	xir_CtlID_S_BRIGHTNESS		=MK_xCTL_CODE(TAU2_BRIGHTNESS,1),

	xir_CtlID_G_BRIGHTNESS_BIAS	=MK_xCTL_CODE(TAU2_BRIGHTNESS_BIAS,0),
	xir_CtlID_S_BRIGHTNESS_BIAS	=MK_xCTL_CODE(TAU2_BRIGHTNESS_BIAS,1),

	xir_CtlID_G_LENS_NUMBER		=MK_xCTL_CODE(TAU2_LENS_NUMBER,0),
	xir_CtlID_S_LENS_NUMBER		=MK_xCTL_CODE(TAU2_LENS_NUMBER,1),

	xir_CtlID_G_SPOT_METER_MODE	=MK_xCTL_CODE(TAU2_SPOT_METER_MODE,0),
	xir_CtlID_S_SPOT_METER_MODE	=MK_xCTL_CODE(TAU2_SPOT_METER_MODE,1),

	xir_CtlID_G_READ_SENSOR_FPA				=MK_xCTL_CODE(TAU2_READ_SENSOR,0),
	xir_CtlID_G_READ_SENSOR_HOUSING			=MK_xCTL_CODE(TAU2_READ_SENSOR,0x0A),
	xir_CtlID_G_READ_SENSOR_Accelerometer	=MK_xCTL_CODE(TAU2_READ_SENSOR,0x0B),
	
	xir_CtlID_G_EXTERNAL_SYNC	=MK_xCTL_CODE(TAU2_EXTERNAL_SYNC,0),
	xir_CtlID_S_EXTERNAL_SYNC	=MK_xCTL_CODE(TAU2_EXTERNAL_SYNC,1),

	xir_CtlID_G_ISOTHERM			=MK_xCTL_CODE(TAU2_ISOTHERM,0),
	xir_CtlID_S_ISOTHERM			=MK_xCTL_CODE(TAU2_ISOTHERM,1),

	xir_CtlID_G_ISOTHERM_THRESHOLDS	=MK_xCTL_CODE(TAU2_ISOTHERM_THRESHOLDS,0),
	xir_CtlID_S_ISOTHERM_THRESHOLDS	=MK_xCTL_CODE(TAU2_ISOTHERM_THRESHOLDS,1),

	xir_CtlID_G_TEST_PATTERN		=MK_xCTL_CODE(TAU2_TEST_PATTERN,0),
	xir_CtlID_S_TEST_PATTERN		=MK_xCTL_CODE(TAU2_TEST_PATTERN,1),

	xir_CtlID_G_VIDEO_COLOR_MODE	=MK_xCTL_CODE(TAU2_VIDEO_COLOR_MODE,0),
	xir_CtlID_S_VIDEO_COLOR_MODE	=MK_xCTL_CODE(TAU2_VIDEO_COLOR_MODE,1),

	xir_CtlID_GET_SPOT_METER	=MK_xCTL_CODE(TAU2_GET_SPOT_METER,0),

	xir_CtlID_G_SPOT_DISPLAY		=MK_xCTL_CODE(TAU2_SPOT_DISPLAY,0),
	xir_CtlID_S_SPOT_DISPLAY		=MK_xCTL_CODE(TAU2_SPOT_DISPLAY,1),
	
	xir_CtlID_G_DDE_GAIN			=MK_xCTL_CODE(TAU2_DDE_GAIN,0),
	xir_CtlID_S_DDE_GAIN			=MK_xCTL_CODE(TAU2_DDE_GAIN,1),

	//xir_CtlID_S_SYMBOL_CONTROL	=MK_xCTL_CODE(TAU2_SYMBOL_CONTROL,0),
	
	xir_CtlID_G_SPLASH_CONTROL	=MK_xCTL_CODE(TAU2_SPLASH_CONTROL,0),
	xir_CtlID_S_SPLASH_CONTROL	=MK_xCTL_CODE(TAU2_SPLASH_CONTROL,1),

	xir_CtlID_G_EZOOM_CONTROL	=MK_xCTL_CODE(TAU2_EZOOM_CONTROL,0),
	xir_CtlID_S_EZOOM_CONTROL	=MK_xCTL_CODE(TAU2_EZOOM_CONTROL,1),

	xir_CtlID_G_FFC_WARN_TIME	=MK_xCTL_CODE(TAU2_FFC_WARN_TIME,0),
	xir_CtlID_S_FFC_WARN_TIME	=MK_xCTL_CODE(TAU2_FFC_WARN_TIME,1),

	xir_CtlID_G_AGC_FILTER		=MK_xCTL_CODE(TAU2_AGC_FILTER,0),
	xir_CtlID_S_AGC_FILTER		=MK_xCTL_CODE(TAU2_AGC_FILTER,1),

	xir_CtlID_G_PLATEAU_LEVEL	=MK_xCTL_CODE(TAU2_PLATEAU_LEVEL,0),
	xir_CtlID_S_PLATEAU_LEVEL	=MK_xCTL_CODE(TAU2_PLATEAU_LEVEL,1),

	xir_CtlID_G_GET_SPOT_METER_DATA	=MK_xCTL_CODE(TAU2_GET_SPOT_METER_DATA,0),
	xir_CtlID_G_GET_SPOT_METER_DATA_MINMAX	=MK_xCTL_CODE(TAU2_GET_SPOT_METER_DATA,1),
	
	xir_CtlID_G_GET_SPOT_METER_COORDINATES =MK_xCTL_CODE(TAU2_GET_SPOT_METER_COORDINATES,0),		//??
	xir_CtlID_S_SET_SPOT_METER_COORDINATES =MK_xCTL_CODE(TAU2_SET_SPOT_METER_COORDINATES,0),		//??
	
	
	xir_CtlID_G_AGC_ROI			=MK_xCTL_CODE(TAU2_AGC_ROI,0),
	xir_CtlID_S_AGC_ROI			=MK_xCTL_CODE(TAU2_AGC_ROI,1),
	
	xir_CtlID_G_SHUTTER_TEMP		=MK_xCTL_CODE(TAU2_SHUTTER_TEMP,0),
	xir_CtlID_S_SHUTTER_TEMP		=MK_xCTL_CODE(TAU2_SHUTTER_TEMP,1),

	xir_CtlID_G_AGC_MIDPOINT		=MK_xCTL_CODE(TAU2_AGC_MIDPOINT,0),
	xir_CtlID_S_AGC_MIDPOINT		=MK_xCTL_CODE(TAU2_AGC_MIDPOINT,1),

	xir_CtlID_G_CAMERA_PART		=MK_xCTL_CODE(TAU2_CAMERA_PART,0),

	xir_CtlID_G_READ_ARRAY_AVERAGE	=MK_xCTL_CODE(TAU2_READ_ARRAY_AVERAGE,0),

	xir_CtlID_G_MAX_AGC_GAIN		=MK_xCTL_CODE(TAU2_MAX_AGC_GAIN,0),
	xir_CtlID_S_MAX_AGC_GAIN		=MK_xCTL_CODE(TAU2_MAX_AGC_GAIN,1),

	xir_CtlID_G_PAN_AND_TILT		=MK_xCTL_CODE(TAU2_PAN_AND_TILT,0),
	xir_CtlID_S_PAN_AND_TILT		=MK_xCTL_CODE(TAU2_PAN_AND_TILT,1),

	xir_CtlID_G_VIDEO_STANDARD	=MK_xCTL_CODE(TAU2_VIDEO_STANDARD,0),
	xir_CtlID_S_VIDEO_STANDARD	=MK_xCTL_CODE(TAU2_VIDEO_STANDARD,1),

	xir_CtlID_G_SHUTTER_POSITION	=MK_xCTL_CODE(TAU2_SHUTTER_POSITION,0),
	xir_CtlID_S_SHUTTER_POSITION	=MK_xCTL_CODE(TAU2_SHUTTER_POSITION,1),

	xir_D_CtlID_TRANSFER_FRAME	=MK_xCTL_CODE(TAU2_TRANSFER_FRAME,0),

	xir_CtlID_G_TLIN_MODE	=MK_xCTL_CODE(TAU2_TLIN_COMMANDS,0x0010),
	xir_CtlID_S_TLIN_MODE	=MK_xCTL_CODE(TAU2_TLIN_COMMANDS,0x0010+1),
	xir_CtlID_G_TLIN_ENABLE	=MK_xCTL_CODE(TAU2_TLIN_COMMANDS,0x0040),
	xir_CtlID_S_TLIN_ENABLE	=MK_xCTL_CODE(TAU2_TLIN_COMMANDS,0x0040+1),

	xir_CtlID_G_CORRECTION_MASK	=MK_xCTL_CODE(TAU2_CORRECTION_MASK,0),
	xir_CtlID_S_CORRECTION_MASK	=MK_xCTL_CODE(TAU2_CORRECTION_MASK,1),
	
	xir_CtlID_G_MEMORY_STATUS		=MK_xCTL_CODE(TAU2_MEMORY_STATUS,0),

	xir_CtlID_D_WRITE_NVFFC_TABLE	=MK_xCTL_CODE(TAU2_WRITE_NVFFC_TABLE,0),

	xir_CtlID_D_READ_MEMORY			=MK_xCTL_CODE(TAU2_READ_MEMORY,0),

	xir_CtlID_D_ERASE_MEMORY_BLOCK	=MK_xCTL_CODE(TAU2_ERASE_MEMORY_BLOCK,0),

	xir_CtlID_G_GET_NV_MEMORY_SIZE	=MK_xCTL_CODE(TAU2_GET_NV_MEMORY_SIZE,0),

	xir_CtlID_G_GET_MEMORY_ADDRESS	=MK_xCTL_CODE(TAU2_GET_MEMORY_ADDRESS,0),

	xir_CtlID_G_GAIN_SWITCH_PARAMS	=MK_xCTL_CODE(TAU2_GAIN_SWITCH_PARAMS,0),
	xir_CtlID_S_GAIN_SWITCH_PARAMS	=MK_xCTL_CODE(TAU2_GAIN_SWITCH_PARAMS,1),

	xir_CtlID_G_DDE_THRESHOLD		=MK_xCTL_CODE(TAU2_DDE_THRESHOLD,0),
	xir_CtlID_S_DDE_THRESHOLD		=MK_xCTL_CODE(TAU2_DDE_THRESHOLD,1),

	xir_CtlID_G_SPATIAL_THRESHOLD	=MK_xCTL_CODE(TAU2_SPATIAL_THRESHOLD,0),
	xir_CtlID_S_SPATIAL_THRESHOLD	=MK_xCTL_CODE(TAU2_SPATIAL_THRESHOLD,1),

	xir_CtlID_G_LENS_RESPONSE_PARAMS	=MK_xCTL_CODE(TAU2_LENS_RESPONSE_PARAMS,0),
	xir_CtlID_S_LENS_RESPONSE_PARAMS	=MK_xCTL_CODE(TAU2_LENS_RESPONSE_PARAMS,0),
	xir_CtlID_MAX
};

#ifdef __cplusplus
}
#endif				


#endif  //#ifndef __Q_FLIR_Tau2_CtlID_DEF__
