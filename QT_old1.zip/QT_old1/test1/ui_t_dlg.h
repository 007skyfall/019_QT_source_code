/********************************************************************************
** Form generated from reading UI file 't_dlg.ui'
**
** Created by: Qt User Interface Compiler version 5.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_T_DLG_H
#define UI_T_DLG_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDialog>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_T_Dlg
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QLabel *label_4;
    QLineEdit *EDIT_RAD_EMISSIVITY;
    QLineEdit *EDIT_RAD_TBKG_X100;
    QLineEdit *EDIT_RAD_TRANSMISSION_WIN;
    QLineEdit *EDIT_RAD_TWIN_X100;
    QLabel *label_5;
    QLineEdit *EDIT_RAD_TREFL_X100;
    QLineEdit *EDIT_RAD_REFL_WIN;
    QLabel *label_6;
    QLabel *label_7;
    QLineEdit *EDIT_RAD_TAU_ATM;
    QLabel *label_8;
    QLineEdit *EDIT_RAD_TATM_X100;
    QPushButton *BTN_G_PARA;
    QPushButton *BTN_S_PARA;

    void setupUi(QDialog *T_Dlg)
    {
        if (T_Dlg->objectName().isEmpty())
            T_Dlg->setObjectName(QStringLiteral("T_Dlg"));
        T_Dlg->resize(583, 409);
        label = new QLabel(T_Dlg);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(50, 110, 81, 31));
        label->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        label_2 = new QLabel(T_Dlg);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(50, 150, 81, 31));
        label_2->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        label_3 = new QLabel(T_Dlg);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(50, 190, 81, 31));
        label_3->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        label_4 = new QLabel(T_Dlg);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(50, 230, 81, 31));
        label_4->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        EDIT_RAD_EMISSIVITY = new QLineEdit(T_Dlg);
        EDIT_RAD_EMISSIVITY->setObjectName(QStringLiteral("EDIT_RAD_EMISSIVITY"));
        EDIT_RAD_EMISSIVITY->setGeometry(QRect(140, 110, 113, 27));
        EDIT_RAD_TBKG_X100 = new QLineEdit(T_Dlg);
        EDIT_RAD_TBKG_X100->setObjectName(QStringLiteral("EDIT_RAD_TBKG_X100"));
        EDIT_RAD_TBKG_X100->setGeometry(QRect(140, 150, 113, 27));
        EDIT_RAD_TRANSMISSION_WIN = new QLineEdit(T_Dlg);
        EDIT_RAD_TRANSMISSION_WIN->setObjectName(QStringLiteral("EDIT_RAD_TRANSMISSION_WIN"));
        EDIT_RAD_TRANSMISSION_WIN->setGeometry(QRect(140, 190, 113, 27));
        EDIT_RAD_TWIN_X100 = new QLineEdit(T_Dlg);
        EDIT_RAD_TWIN_X100->setObjectName(QStringLiteral("EDIT_RAD_TWIN_X100"));
        EDIT_RAD_TWIN_X100->setGeometry(QRect(140, 230, 113, 27));
        label_5 = new QLabel(T_Dlg);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(310, 190, 81, 31));
        label_5->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        EDIT_RAD_TREFL_X100 = new QLineEdit(T_Dlg);
        EDIT_RAD_TREFL_X100->setObjectName(QStringLiteral("EDIT_RAD_TREFL_X100"));
        EDIT_RAD_TREFL_X100->setGeometry(QRect(400, 230, 113, 27));
        EDIT_RAD_REFL_WIN = new QLineEdit(T_Dlg);
        EDIT_RAD_REFL_WIN->setObjectName(QStringLiteral("EDIT_RAD_REFL_WIN"));
        EDIT_RAD_REFL_WIN->setGeometry(QRect(400, 190, 113, 27));
        label_6 = new QLabel(T_Dlg);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(310, 110, 81, 31));
        label_6->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        label_7 = new QLabel(T_Dlg);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(290, 230, 101, 31));
        label_7->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        EDIT_RAD_TAU_ATM = new QLineEdit(T_Dlg);
        EDIT_RAD_TAU_ATM->setObjectName(QStringLiteral("EDIT_RAD_TAU_ATM"));
        EDIT_RAD_TAU_ATM->setGeometry(QRect(400, 110, 113, 27));
        label_8 = new QLabel(T_Dlg);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(310, 150, 81, 31));
        label_8->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        EDIT_RAD_TATM_X100 = new QLineEdit(T_Dlg);
        EDIT_RAD_TATM_X100->setObjectName(QStringLiteral("EDIT_RAD_TATM_X100"));
        EDIT_RAD_TATM_X100->setGeometry(QRect(400, 150, 113, 27));
        BTN_G_PARA = new QPushButton(T_Dlg);
        BTN_G_PARA->setObjectName(QStringLiteral("BTN_G_PARA"));
        BTN_G_PARA->setGeometry(QRect(140, 50, 99, 31));
        BTN_S_PARA = new QPushButton(T_Dlg);
        BTN_S_PARA->setObjectName(QStringLiteral("BTN_S_PARA"));
        BTN_S_PARA->setGeometry(QRect(360, 50, 99, 31));

        retranslateUi(T_Dlg);

        QMetaObject::connectSlotsByName(T_Dlg);
    } // setupUi

    void retranslateUi(QDialog *T_Dlg)
    {
        T_Dlg->setWindowTitle(QApplication::translate("T_Dlg", "Dialog", 0));
        label->setText(QApplication::translate("T_Dlg", "\345\217\221\345\260\204\347\216\207", 0));
        label_2->setText(QApplication::translate("T_Dlg", "\350\203\214\346\231\257\346\270\251\345\272\246", 0));
        label_3->setText(QApplication::translate("T_Dlg", "\347\252\227\345\217\243\351\200\217\350\277\207\347\216\207", 0));
        label_4->setText(QApplication::translate("T_Dlg", "\347\252\227\345\217\243\346\270\251\345\272\246", 0));
        label_5->setText(QApplication::translate("T_Dlg", "\347\252\227\345\217\243\345\217\215\345\260\204\347\216\207", 0));
        label_6->setText(QApplication::translate("T_Dlg", "\345\244\247\346\260\224\351\200\217\350\277\207\347\216\207", 0));
        label_7->setText(QApplication::translate("T_Dlg", "\347\252\227\345\217\243\345\217\215\345\260\204\346\270\251\345\272\246", 0));
        label_8->setText(QApplication::translate("T_Dlg", "\345\244\247\346\260\224\346\270\251\345\272\246", 0));
        BTN_G_PARA->setText(QApplication::translate("T_Dlg", "\350\257\273\347\216\257\345\242\203\345\217\202\346\225\260", 0));
        BTN_S_PARA->setText(QApplication::translate("T_Dlg", "\350\256\276\347\216\257\345\242\203\345\217\202\346\225\260", 0));
    } // retranslateUi

};

namespace Ui {
    class T_Dlg: public Ui_T_Dlg {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_T_DLG_H
