#ifndef PALETTEDLG_H
#define PALETTEDLG_H

#include <QDialog>

namespace Ui {
class PaletteDlg;
}

class PaletteDlg : public QDialog
{
    Q_OBJECT

public:
    explicit PaletteDlg(QWidget *parent = 0);
    ~PaletteDlg();

    QString GetFileName();


    int m_nIndex;
    void setPalette(int nIndex);

private:
    Ui::PaletteDlg *ui;
};

#endif // PALETTEDLG_H
