#ifndef __Q_IMG_PROC__
#define __Q_IMG_PROC__
#include "../include/ir_types.h"
#include "../include/ir_errinfo.h"
#include "../include/ir_cam.h"


#ifndef max
#define max(a,b)            (((a) > (b)) ? (a) : (b))
#endif

#ifndef min
#define min(a,b)            (((a) < (b)) ? (a) : (b))
#endif
typedef unsigned short WORD;
typedef	int32_t			BOOL;


#define SAFE_Free(ptr)	{ if( (ptr) != NULL) { free( (ptr) );	(ptr) = NULL;	}	}
#define SAFE_Delete(ptr)	{ if( (ptr) != NULL) { delete( (ptr) );	(ptr) = NULL;	}	}


//ͼ��ṹ
typedef struct tagImgPara
{
    int32_t nWidth;		//ͼ�����
    int32_t nHeight;		//ͼ��߶�
    WORD wBpps;			//ÿ�����ص���ȣ���Чֵ��8��16��24��32
    WORD wChannel;		//����ͨ����
    void *pData;		//ͼ�����ݻ�����
}ImgPara;

BOOL PlatEqual_2( ImgPara *pInImg,  ImgPara *pOutImg,  int nPlatLevel, int nPlatGrayLevel,BOOL bAdjMinMax,BOOL bInvertIMG );

typedef struct tagMultiMinMaxPara
{
	int32_t nMostMaxV_Num;
	int32_t nMostMinV_Num;
	int32_t nMostSecondMaxV_Num;
	int32_t nMostSecondMinV_Num;
	double fSecondMaxV_ratio;
	double fSecondMinV_ratio;
}stMultiMinMaxPara;


typedef struct tagMultiMinMax
{
	int32_t nMaxV_Num;
	int32_t nMinV_Num;
	int32_t nMaxV;
	int32_t nMinV;

	ir_point_t *p_ptMaxV;
	ir_point_t *p_ptMinV;
}stMultiMinMax;

typedef struct _ir_ptv
{
	int32_t x;
	int32_t y;
	int32_t v;
}ir_ptv;
typedef struct tagSecondMinMax
{
	int32_t nSecondMaxV_Num;
	int32_t nSecondMinV_Num;

	ir_ptv *p_ptSecondMaxV;
	ir_ptv *p_ptSecondMinV;
}stSecondMinMax;


void init_FindMultiMinMax(stMultiMinMaxPara* pPara, stMultiMinMax* p_stMultiMinMax, stSecondMinMax* p_stSecondMinMax);
void end_FindMultiMinMax(stMultiMinMax* p_stMultiMinMax, stSecondMinMax* p_stSecondMinMax);
int FindMultiMinMax(WORD* pRaw16, int nIMG_WID, int nIMG_HEI, stMultiMinMax* pResult);
void FindSecondMinMax(WORD* pRaw16, int nIMG_WID, int nIMG_HEI, stMultiMinMaxPara* pPara, stMultiMinMax* pMinMax, stSecondMinMax* pResult);
#endif
