/**
	@file ir_errinfo.h
 
	@brief �������Ķ���
 
	Copyright (C) 2010, IR WORLD
 	@author:		FreeHorse
 	@date:			2010-04-08, 2010.11.9, 2010.10.14, 2014.2.26
 	@version:		1.0.1, 1.0.2, 1.0.3, 1.04
*/

#ifndef __IR_ERRINFO_H__
#define __IR_ERRINFO_H__


#include "ir_types.h"


#ifdef __cplusplus
extern "C"
{
#endif

#ifdef _WIN32
    #include <WINSOCK2.H>
#else
    #include <sys/types.h>
#endif


#ifdef _WIN32
		//windows �Ѿ�����
#else
	//#define _DEBUG		//Linux
#endif


#ifdef _WIN32

	#ifdef _DEBUG
		#define DBGOUT( x ) {OutputDebugString(x);}
	#else	//#ifdef _DEBUG
		#define DBGOUT( x )
	#endif	//#ifdef _DEBUG

#else	//#ifdef _WIN32

#ifdef _DEBUG
	//#define TRACE( x... ) {printf( "%s %s (L:%d) :", __FILE__, __FUNCTION__, __LINE__ ); printf( x );}
	#define TRACE( x  ) {printf( "%s %s (L:%d) :", __FILE__, __FUNCTION__, __LINE__ ); printf( x );}
	#define ASSERT( x ) {if(!x) { printf( "assertion failed: %s %s (L:%d)", __FILE__, __FUNCTION__, __LINE__ ); exit( -1 );} }
	//#define DBGOUT( x ) printf(x);
	#define DBGOUT( x ) \
		{\
			char lpDBGString[256];	\
			struct  timeval    atv;	\
			gettimeofday(&atv,NULL);\
			sprintf(lpDBGString,"%d.%d\t%s",atv.tv_sec,atv.tv_usec,x);\
			printf(lpDBGString);\
		}

#else
	#define TRACE( x )
	#define ASSERT( x )
	#define DBGOUT( x )
#endif

	#define ERR_INFO( x ) \
		{\
			char lpDBGString[256];	\
			struct  timeval    atv;	\
			gettimeofday(&atv,NULL);\
			sprintf(lpDBGString,"%d.%d\t%s",atv.tv_sec,atv.tv_usec,x);\
			printf(lpDBGString);\
		}	
	#define SHOW_INFO( x ) \
		{\
			char lpDBGString[256];	\
			struct  timeval    atv;	\
			gettimeofday(&atv,NULL);\
			sprintf(lpDBGString,"%d.%d\t%s",atv.tv_sec,atv.tv_usec,x);\
			printf(lpDBGString);\
		}	



#endif	//#ifdef _WIN32


/**
// �豸�ϵĴ������
*/
#define IR_E_OK								0

#define IR_E_FAILURE						-1
#define IR_E_NO_MEM  				  		-2
#define IR_E_PTR_NULL						-3		///< ָ��ΪNULL
#define IR_E_TIMEOUT  			  			-4
#define IR_E_CANCELED  			  			-5		///< canceled

#define IR_E_NO_DEVICE						-10
#define IR_E_INVALID_HANDLE  				-11
#define IR_E_INVALID_PARAMETER				-12
#define IR_E_HEAD_MARK						-13		///< ���Ʊ�ʶ��ƥ��


#define IR_E_OPEN_FAILED			  		-20		///< ��ʧ��
#define IR_E_CLOSE_FAILED					-21		///< �ر�ʧ��
#define IR_E_START_FAILED					-22		///< �ɼ�ʧ��
#define IR_E_STOP_FAILED					-23		///< ֹͣʧ��
#define IR_E_CTL_FAILED						-24		///< ����ʧ��
#define IR_E_CTL_PRIVILEGE					-25		///< û�п���Ȩ

#define IR_E_OPENED 						-30		///< �Ѿ���
#define IR_E_CLOSED		 					-31		///< �Ѿ��ر�
#define IR_E_STARTED 						-32		///< �Ѿ���ʼ�ɼ�
#define IR_E_STOPED 						-33		///< �Ѿ�ֹͣ�ɼ�

#define IR_E_NOT_OPENED						-34		///< ��û�д�
#define IR_E_NOT_CLOSED						-35		///< ��û�йر�
#define IR_E_NOT_STARTED					-36		///< û�п�ʼ�ɼ�
#define IR_E_NOT_STOPED 					-37		///< û��ֹͣ�ɼ�


#define IR_E_DEV_IDLE 						-40		///< û�вɼ�
#define IR_E_DEV_BUSY 						-41		///< ���ڲɼ�
#define IR_E_USER_BUSY 						-42		///< �û����ڴ�����
#define IR_E_USER_IDLE 						-43		///< �û�����
#define IR_E_USER_NOT_WANT_DATA 			-44		///< �û�����Ҫ����

#define IR_E_HEARBEAT_IDLE					-50		///< �����߳�û������

#define IR_E_VIDEO_MODE		  				-60

#define IR_E_NO_DETACHED_BUF				-70

#define IR_E_PTHREAD_FAILED					-80
#define IR_E_PERMISSION_DENIED 				-90 

/**
// �豸�ϵľ������
*/
#define IR_W_WARNING						-101
#define IR_W_CAPTURE_ALREADY_STARTED 	  	-102
#define IR_W_CAPTURE_ALREADY_STOPPED 	  	-103
#define IR_W_DEV_QUERY_FAIL				  	-104

/**
// �������������
*/
#define IR_E_INVALID_SOCKET					-200	///< invalid socket
#define IR_E_ENUM_DEV			   			-201	///< enum device error
#define IR_E_CONNECT 						-202	///< connecting to socket failed
#define IR_E_READ    						-203	///< error while reading from socket
#define IR_E_WRITE   						-204	///< failed to write to socket
#define IR_E_ADDRESS 						-205	///< could not get address from hostname
#define IR_E_SELECT  						-206	///< select failed
#define IR_E_SERVER  						-207	///< server close


/**
// �Ժ�������Ŀ��Ʒ���״̬���塣
*/
#define IRCAM_ERR_BASE						1000		//0x3E8

#define IRCAM_OK                         	0x0
#define IRCAM_BUSY                       	-(IRCAM_ERR_BASE +0x01)	///< (-1001)
#define IRCAM_NOT_READY                 	-(IRCAM_ERR_BASE +0x02)	///< (-1002)
#define IRCAM_RANGE_ERROR                	-(IRCAM_ERR_BASE +0x03)	///< (-1003)
#define IRCAM_CHECKSUM_ERROR             	-(IRCAM_ERR_BASE +0x04)	///< (-1004)
#define IRCAM_UNDEFINED_PROCESS_ERROR    	-(IRCAM_ERR_BASE +0x05)	///< (-1005)
#define IRCAM_UNDEFINED_FUNCTION_ERROR		-(IRCAM_ERR_BASE +0x06)	///< (-1006)
#define IRCAM_TIMEOUT_ERROR              	-(IRCAM_ERR_BASE +0x07)	///< (-1007)
#define IRCAM_BYTE_COUNT_ERROR           	-(IRCAM_ERR_BASE +0x08)	///< (-1008)
#define IRCAM_FEATURE_NOT_ENABLED        	-(IRCAM_ERR_BASE +0x09)	///< (-1009)
#define IRCAM_FEATURE_NOT_ENABLED_0A     	-(IRCAM_ERR_BASE +0x0A)	///< (-2010)

#define IRCAM_UNKNOWN_ERROR			  		-(IRCAM_ERR_BASE +0x0B)	///< (-1011)	
#define IRCAM_CANNOT_DO						-(IRCAM_ERR_BASE +0x0C)	///< (-1012)	
#define IRCAM_CANNOT_GET					-(IRCAM_ERR_BASE +0x0D)	///< (-1013)	
#define IRCAM_CANNOT_SET					-(IRCAM_ERR_BASE +0x0E)	///< (-1014)	

#ifdef __cplusplus
}
#endif	

#endif ///< __IR_ERRINFO_H__
