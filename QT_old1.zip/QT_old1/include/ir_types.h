/**
	@file ir_types.h
 
	@brief �������͵Ķ���
 
	Copyright (C) 2010, IR WORLD
 	@author:		FreeHorse
 	@date:			2010-04-08
 	@version:		1.0.1
 	@date:			2014-02-26
 	@version:		1.0.2

*/

#ifndef __IR_WORLD_DATA_TYPES__
#define __IR_WORLD_DATA_TYPES__

#ifdef __cplusplus
extern "C" {
#endif
#ifndef FALSE
#define FALSE               0
#endif

#ifndef TRUE
#define TRUE                1
#endif

#ifndef IN
#define IN
#endif

#ifndef OUT
#define OUT
#endif
#ifdef _WIN32		//Used by Windows
#include "win32/stdint.h"
#include "win32/inttypes.h"
#else

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sys/time.h>

#include <pthread.h> 
#include <stdint.h>



#ifndef min
#define min(a,b)            (((a) < (b)) ? (a) : (b))
#endif

#define OutputDebugString( x ) \
{\
	printf("%s",x); \
}
#endif

//(1)signed
typedef	char		int8;
typedef	short int	int16;
//typedef	long		int32;
typedef	int32_t	int32;

#ifdef _WIN32		//Used by Windows
	typedef __int64 int64;
#include "./win32/stdint.h"    //vs2008 ƽ̨�±��� ʹ��
#include "./win32/inttypes.h"
#else
	typedef long long int int64;
#endif


//(2) unsigned
typedef	unsigned char		u_int8;
typedef	unsigned short int	u_int16;
//typedef	unsigned long		u_int32;
typedef	 uint32_t		u_int32;

#ifdef _WIN32		//Used by Windows
	typedef unsigned __int64 u_int64;
#else
	typedef unsigned long long int u_int64;
typedef unsigned char BYTE;
typedef unsigned short WORD;
	typedef	int32_t			BOOL;

	typedef int32_t       DWORD;

#define TRUE	1
#define FALSE	0


typedef struct __CRect
{
	int32_t left;
	int32_t right;
	int32_t top;
	int32_t bottom;
}CRect;
#endif


#ifdef __cplusplus
}
#endif	


#endif	//__IR_WORLD_DATA_TYPES__
