#ifndef GLWIDGET7_H
#define GLWIDGET7_H

#endif // GLWIDGET7_H
