#include <QtGui>

#include "player.h"
#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
	: QMainWindow(parent)
{
	openFileButton = new QPushButton(QIcon(tr(":/images/openfile.png")), tr(""));
	connect(openFileButton, SIGNAL(clicked()), this, SLOT(slotOpenFile()));

	playButton = new QPushButton(QIcon(tr(":/images/play.png")), tr(""));
	connect(playButton, SIGNAL(clicked()), this, SLOT(slotPlay()));

	stopButton = new QPushButton(QIcon(tr(":/images/stop.png")), tr(""));
	connect(stopButton, SIGNAL(clicked()), this, SLOT(slotStop()));

	stepButton = new QPushButton(QIcon(tr(":/images/step.png")), tr(""));
	backwardButton = new QPushButton(QIcon(tr(":/images/backward.png")), tr(""));
	muteButton = new QPushButton(QIcon(tr(":/images/vocal.png")), tr(""));

	buttonLayout = new QHBoxLayout();
	buttonLayout->addWidget(openFileButton);
	buttonLayout->addStretch(1);
	buttonLayout->addWidget(backwardButton);
	buttonLayout->addWidget(playButton);
	buttonLayout->addWidget(stopButton);
	buttonLayout->addWidget(stepButton);
	buttonLayout->addWidget(muteButton);

	player = new Player();
	player->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
	connect(player, SIGNAL(started()), this, SLOT(slotStarted()));
	connect(player, SIGNAL(error(QProcess::ProcessError)), this, SLOT(slotError(QProcess::ProcessError)));
	connect(player, SIGNAL(finished(int, QProcess::ExitStatus)), this, SLOT(slotFinished(int, QProcess::ExitStatus)));
	connect(player, SIGNAL(readyReadStandardOutput()), this, SLOT(slotBackMessage()));

	QVBoxLayout *mainLayout = new QVBoxLayout();
	mainLayout->addWidget(player);
	mainLayout->addLayout(buttonLayout);

	QWidget *centralWidget = new QWidget;
	centralWidget->setLayout(mainLayout);

	resize(600, 400);
	setCentralWidget(centralWidget);
}

MainWindow::~MainWindow()
{
}

void MainWindow::slotOpenFile()
{
	currentFileName = QFileDialog::getOpenFileName(this, tr("打开媒体文件"), tr(""), 
					tr("Video files(*.rmvb *.rm *.avi *.wmv *.mkv *.asf *.3gp *.mov *.mp4 *.ogv)"));
	if( !currentFileName.isEmpty() )
	{
		player->play(currentFileName);
//		this->showFullScreen();
	}
}

void MainWindow::slotPlay()
{
	if( currentFileName.isEmpty() )
	{
		slotOpenFile();
		playButton->setIcon(QIcon(":/images/pause.png"));
	}
	else
	{
		player->controlCmd("pause\n");	
	}
}

void MainWindow::slotStop()
{
	player->controlCmd("quit\n");
	currentFileName = "";
}

void MainWindow::slotStep()
{

}
	
void MainWindow::slotBackward()
{

}

void MainWindow::slotMute(bool /*status*/)
{

}

void MainWindow::slotStarted()
{
	qDebug() << "lplayer started...";
}

void MainWindow::slotError(QProcess::ProcessError /*error*/)
{

}

void MainWindow::slotFinished(int /*exitCode*/, QProcess::ExitStatus /*exitStatus*/)
{
	//this->showNormal();
	qDebug() << tr("视频播放完毕，循环播放！");
	player->play(currentFileName);
}

void MainWindow::slotBackMessage()
{
}
