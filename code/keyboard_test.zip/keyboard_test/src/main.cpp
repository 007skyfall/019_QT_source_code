#include <QApplication>
#include "keyboard_test.h"
//
int main(int argc, char ** argv)
{
	QApplication app( argc, argv );
	Keyboard_test win;
	win.show(); 
	app.connect( &app, SIGNAL( lastWindowClosed() ), &app, SLOT( quit() ) );
	return app.exec();
}
