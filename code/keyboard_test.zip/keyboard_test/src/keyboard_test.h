#ifndef KEYBOARD_TEST_H
#define KEYBOARD_TEST_H
//
#include <QDialog>
#include "ui_keyboard_test.h"
#include "keypad.h"
//
class Keyboard_test : public QDialog, public Ui::Keyboard_test
{
Q_OBJECT
public:
	Keyboard_test( QWidget * parent = 0, Qt::WFlags f = 0 );
private slots:
	void display_keypad();
	void display_keypad2();
};
#endif




