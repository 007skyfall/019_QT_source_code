#ifndef KEYPAD_H
#define KEYPAD_H
//
#include <QDialog>
#include "ui_keypad.h"

//
class Keypad : public QDialog, public Ui::Keypad
{
Q_OBJECT
public:
	Keypad( QWidget * parent = 0, Qt::WFlags f = 0 );
private slots:
	void digit0Clicked();
	void digit1Clicked();
	void digit2Clicked();
	void digit3Clicked();
	void digit4Clicked();
	void digit5Clicked();
	void digit6Clicked();
	void digit7Clicked();
	void digit8Clicked();
	void digit9Clicked();
	void enterClicked();
	void pointClicked();
	void changeSignClicked();
	void backspaceClicked();
	void clear();
signals:
	void setvalue(const QString &);
private:
	bool waitingForOperand;
};
#endif




