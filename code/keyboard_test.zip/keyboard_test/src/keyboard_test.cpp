#include "keyboard_test.h"
//
Keyboard_test::Keyboard_test( QWidget * parent, Qt::WFlags f) 
	: QDialog(parent, f)
{
	setupUi(this);
}
//
void Keyboard_test::display_keypad()
{
	Keypad *vk=new Keypad(this);
	connect(vk, SIGNAL(setvalue(const QString &)), lineEdit, SLOT(setText(const QString &)));
	vk->show();
	vk->raise();
	vk->activateWindow();
}

void Keyboard_test::display_keypad2()
{
	Keypad *vk=new Keypad(this);
	connect(vk, SIGNAL(setvalue(const QString &)), lineEdit_2, SLOT(setText(const QString &)));
	vk->show();
	vk->raise();
	vk->activateWindow();
}