<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="en_US">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../aboutdialog.cpp" line="34"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="76"/>
        <location filename="../aboutdialog.ui" line="151"/>
        <source>Authors</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutdialog.cpp" line="81"/>
        <location filename="../aboutdialog.ui" line="158"/>
        <source>License</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutdialog.ui" line="84"/>
        <source>Lightweight WebKit-based web browser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutdialog.ui" line="100"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot;font-size:9pt;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Copyright © 2007-2008 Benjamin C. Meyer &amp;lt;&lt;a href=&quot;mailto:ben@meyerhome.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;ben@meyerhome.net&lt;/span&gt;&lt;/a&gt;&amp;gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutdialog.ui" line="123"/>
        <source>&lt;a href=&quot;http://arora-browser.org&quot;&gt;http://arora-browser.org&lt;/a&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../aboutdialog.ui" line="165"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AddBookmarkDialog</name>
    <message>
        <location filename="../addbookmarkdialog.ui" line="14"/>
        <source>Add Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../addbookmarkdialog.ui" line="20"/>
        <source>Type a name for the bookmark, and choose where to keep it.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BookmarksDialog</name>
    <message>
        <location filename="../bookmarks.cpp" line="911"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bookmarks.cpp" line="922"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bookmarks.cpp" line="981"/>
        <source>New Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bookmarks.ui" line="13"/>
        <source>Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bookmarks.ui" line="40"/>
        <source>&amp;Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bookmarks.ui" line="47"/>
        <source>Add Folder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bookmarks.cpp" line="912"/>
        <source>Open in New Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bookmarks.cpp" line="916"/>
        <source>Edit Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bookmarks.cpp" line="919"/>
        <source>Edit Address</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BookmarksManager</name>
    <message>
        <location filename="../bookmarks.cpp" line="130"/>
        <location filename="../bookmarks.cpp" line="286"/>
        <source>Error when loading bookmarks on line %1, column %2:
%3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bookmarks.cpp" line="85"/>
        <source>Bookmarks Bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bookmarks.cpp" line="86"/>
        <source>Bookmarks Menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bookmarks.cpp" line="139"/>
        <source>Toolbar Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bookmarks.cpp" line="147"/>
        <source>Menu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bookmarks.cpp" line="276"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bookmarks.cpp" line="278"/>
        <location filename="../bookmarks.cpp" line="299"/>
        <source>XBEL (*.xbel *.xml)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bookmarks.cpp" line="291"/>
        <source>Imported %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bookmarks.cpp" line="297"/>
        <source>Save File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bookmarks.cpp" line="298"/>
        <source>%1 Bookmarks.xbel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bookmarks.cpp" line="305"/>
        <source>Export error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bookmarks.cpp" line="305"/>
        <source>error saving bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bookmarks.cpp" line="309"/>
        <source>Remove Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bookmarks.cpp" line="343"/>
        <source>Insert Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bookmarks.cpp" line="357"/>
        <source>Name Change</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bookmarks.cpp" line="360"/>
        <source>Address Change</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BookmarksModel</name>
    <message>
        <location filename="../bookmarks.cpp" line="455"/>
        <source>Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bookmarks.cpp" line="456"/>
        <source>Address</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BookmarksToolBar</name>
    <message>
        <location filename="../bookmarks.cpp" line="1018"/>
        <source>Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bookmarks.cpp" line="1054"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bookmarks.cpp" line="1057"/>
        <source>Open in New &amp;Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bookmarks.cpp" line="1064"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bookmarks.cpp" line="1071"/>
        <source>Add Bookmark...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BrowserApplication</name>
    <message>
        <location filename="../browserapplication.cpp" line="100"/>
        <source> (Change: %1 %2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browserapplication.cpp" line="199"/>
        <source>There are %1 windows and %2 tabs open
Do you want to quit anyway?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browserapplication.cpp" line="359"/>
        <source>Restore failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browserapplication.cpp" line="360"/>
        <source>The saved session will not be restored because Arora crashed while trying to restore this session.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BrowserMainWindow</name>
    <message>
        <location filename="../browsermainwindow.cpp" line="381"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="383"/>
        <source>&amp;New Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="385"/>
        <source>&amp;Open File...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="386"/>
        <source>Open &amp;Location...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="391"/>
        <source>&amp;Save As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="395"/>
        <source>&amp;Import Bookmarks...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="396"/>
        <source>&amp;Export Bookmarks...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="398"/>
        <source>P&amp;rint Preview...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="399"/>
        <source>&amp;Print...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="401"/>
        <source>Private &amp;Browsing...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="406"/>
        <location filename="../browsermainwindow.cpp" line="408"/>
        <source>&amp;Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="412"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="413"/>
        <source>&amp;Undo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="416"/>
        <source>&amp;Redo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="420"/>
        <source>Cu&amp;t</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="423"/>
        <source>&amp;Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="426"/>
        <source>&amp;Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="431"/>
        <source>&amp;Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="445"/>
        <source>Ctrl+,</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="448"/>
        <source>&amp;View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="462"/>
        <source>Shift+Ctrl+B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="456"/>
        <source>Ctrl+|</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="436"/>
        <source>Find Nex&amp;t</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="445"/>
        <source>Prefere&amp;nces...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="449"/>
        <source>Show Menu Bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="473"/>
        <source>Ctrl+/</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="479"/>
        <source>&amp;Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="497"/>
        <source>Page S&amp;ource</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="497"/>
        <source>Ctrl+Alt+U</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="498"/>
        <source>&amp;Full Screen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="505"/>
        <source>Hi&amp;story</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="509"/>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="514"/>
        <source>Forward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="519"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="523"/>
        <source>Restore Last Session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="538"/>
        <source>&amp;Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="543"/>
        <source>Manage Bookmarks...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="546"/>
        <source>Add Bookmark...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="557"/>
        <source>&amp;Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="562"/>
        <source>&amp;Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="563"/>
        <source>Web &amp;Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="564"/>
        <source>Ctrl+K</source>
        <comment>Web Search</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="567"/>
        <source>Show &amp;Network Monitor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="570"/>
        <source>Enable Web &amp;Inspector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="578"/>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="579"/>
        <source>Switch application language </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="581"/>
        <source>About &amp;Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="582"/>
        <source>About &amp;Arora</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="588"/>
        <location filename="../browsermainwindow.cpp" line="1018"/>
        <source>Navigation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="688"/>
        <source>Show Status Bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="688"/>
        <source>Hide Status Bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="693"/>
        <source>Show Toolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="693"/>
        <source>Hide Toolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="804"/>
        <source>Arora</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="809"/>
        <source>%1 - Arora</source>
        <comment>Page title and Browser name</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="829"/>
        <source>Open Web Resource</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="830"/>
        <source>Web Resources (*.html *.htm *.svg *.png *.gif *.svgz);;All files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="859"/>
        <source>Print Document</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="868"/>
        <source>Are you sure you want to turn on private browsing?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="907"/>
        <source>Are you sure you want to close the window?  There are %1 tabs open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="1037"/>
        <source>Web Inspector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="1038"/>
        <source>The web inspector will only work correctly for pages that were loaded after enabling.
Do you want to reload all pages?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="1093"/>
        <source>Stop loading the current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="1098"/>
        <source>Reload the current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="1144"/>
        <source>Downloads</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="1144"/>
        <source>Alt+Ctrl+L</source>
        <comment>Download Manager</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="565"/>
        <source>&amp;Clear Private Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="566"/>
        <source>Ctrl+Shift+Delete</source>
        <comment>Clear Private Data</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="698"/>
        <source>Show Bookmarks Bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="698"/>
        <source>Hide Bookmarks Bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="869"/>
        <source>&lt;b&gt;%1&lt;/b&gt;&lt;br&gt;&lt;br&gt;When private browsing is turned on, some actions concerning your privacy will be disabled:&lt;ul&gt;&lt;li&gt; Webpages are not added to the history.&lt;/li&gt;&lt;li&gt; Items are automatically removed from the Downloads window.&lt;/li&gt;&lt;li&gt; New cookies are not stored, current cookies can&apos;t be accessed.&lt;/li&gt;&lt;li&gt; Site icons won&apos;t be stored, session won&apos;t be saved.&lt;/li&gt;&lt;li&gt; Searches are not addded to the pop-up menu in the search box.&lt;/li&gt;&lt;/ul&gt;Until you close the window, you can still click the Back and Forward buttons to return to the webpages you have opened.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="440"/>
        <source>Find P&amp;revious</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="488"/>
        <source>&amp;Reload Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="492"/>
        <source>Make Text &amp;Bigger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="493"/>
        <source>Make Text &amp;Normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../browsermainwindow.cpp" line="494"/>
        <source>Make Text &amp;Smaller</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ClearButton</name>
    <message>
        <location filename="../searchlineedit.cpp" line="77"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ClearPrivateData</name>
    <message>
        <location filename="../clearprivatedata.cpp" line="41"/>
        <source>Clear Private Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clearprivatedata.cpp" line="44"/>
        <source>Clear the following items:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clearprivatedata.cpp" line="46"/>
        <source>&amp;Browsing History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clearprivatedata.cpp" line="50"/>
        <source>&amp;Download History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clearprivatedata.cpp" line="54"/>
        <source>&amp;Search History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clearprivatedata.cpp" line="58"/>
        <source>&amp;Cookies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clearprivatedata.cpp" line="62"/>
        <source>C&amp;ached Web Pages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clearprivatedata.cpp" line="69"/>
        <source>Website &amp;Icons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clearprivatedata.cpp" line="73"/>
        <source>Clear &amp;Private Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clearprivatedata.cpp" line="75"/>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CookieExceptionsModel</name>
    <message>
        <location filename="../cookiejar/cookieexceptionsmodel.cpp" line="93"/>
        <source>Website</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cookiejar/cookieexceptionsmodel.cpp" line="95"/>
        <source>Rule</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cookiejar/cookieexceptionsmodel.cpp" line="115"/>
        <source>Allow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cookiejar/cookieexceptionsmodel.cpp" line="124"/>
        <source>Block</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cookiejar/cookieexceptionsmodel.cpp" line="133"/>
        <source>Allow For Session</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CookieModel</name>
    <message>
        <location filename="../cookiejar/cookiemodel.cpp" line="95"/>
        <source>Website</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cookiejar/cookiemodel.cpp" line="97"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cookiejar/cookiemodel.cpp" line="99"/>
        <source>Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cookiejar/cookiemodel.cpp" line="101"/>
        <source>Secure</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cookiejar/cookiemodel.cpp" line="103"/>
        <source>Expires</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cookiejar/cookiemodel.cpp" line="105"/>
        <source>Contents</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cookiejar/cookiemodel.cpp" line="133"/>
        <source>true</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cookiejar/cookiemodel.cpp" line="133"/>
        <source>false</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CookiesDialog</name>
    <message>
        <location filename="../cookiejar/cookies.ui" line="13"/>
        <source>Cookies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cookiejar/cookies.ui" line="40"/>
        <source>&amp;Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cookiejar/cookies.ui" line="47"/>
        <source>Remove &amp;All Cookies</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CookiesExceptionsDialog</name>
    <message>
        <location filename="../cookiejar/cookiesexceptions.ui" line="13"/>
        <source>Cookie Exceptions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cookiejar/cookiesexceptions.ui" line="19"/>
        <source>New Exception</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cookiejar/cookiesexceptions.ui" line="27"/>
        <source>Domain:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cookiejar/cookiesexceptions.ui" line="57"/>
        <source>Block</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cookiejar/cookiesexceptions.ui" line="67"/>
        <source>Allow For Session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cookiejar/cookiesexceptions.ui" line="77"/>
        <source>Allow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cookiejar/cookiesexceptions.ui" line="89"/>
        <source>Exceptions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cookiejar/cookiesexceptions.ui" line="114"/>
        <source>&amp;Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../cookiejar/cookiesexceptions.ui" line="121"/>
        <source>Remove &amp;All</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DownloadDialog</name>
    <message>
        <location filename="../downloads.ui" line="13"/>
        <source>Downloads</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloads.ui" line="37"/>
        <source>Clean up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloads.ui" line="59"/>
        <source>0 Items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloads.ui" line="81"/>
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DownloadItem</name>
    <message>
        <location filename="../downloadmanager.cpp" line="167"/>
        <source>Save File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadmanager.cpp" line="172"/>
        <source>Download canceled: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadmanager.cpp" line="266"/>
        <source>Error opening output file: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadmanager.cpp" line="275"/>
        <source>Error saving: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadmanager.cpp" line="288"/>
        <source>Network Error: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadmanager.cpp" line="330"/>
        <source>seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadmanager.cpp" line="352"/>
        <source>%1 of %2 (%3/sec) %4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadmanager.cpp" line="354"/>
        <source>?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadmanager.cpp" line="361"/>
        <source>%1 of %2 - Stopped</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadmanager.cpp" line="375"/>
        <source>bytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadmanager.cpp" line="378"/>
        <source>kB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloadmanager.cpp" line="381"/>
        <source>MB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloaditem.ui" line="13"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloaditem.ui" line="28"/>
        <source>Ico</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloaditem.ui" line="43"/>
        <source>Filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloaditem.ui" line="90"/>
        <source>Try Again</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloaditem.ui" line="97"/>
        <source>Stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../downloaditem.ui" line="104"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../downloadmanager.cpp" line="345"/>
        <source>- %n minutes remaining</source>
        <translation>
            <numerusform>- %n minute remaining</numerusform>
            <numerusform>- %n minutes remaining</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../downloadmanager.cpp" line="349"/>
        <source>- %n seconds remaining</source>
        <translation>
            <numerusform>- %n second remaining</numerusform>
            <numerusform>- %n seconds remaining</numerusform>
        </translation>
    </message>
</context>
<context>
    <name>DownloadManager</name>
    <message numerus="yes">
        <location filename="../downloadmanager.cpp" line="621"/>
        <source>%n Download(s)</source>
        <translation>
            <numerusform>%n Download</numerusform>
            <numerusform>%n Downloads</numerusform>
        </translation>
    </message>
</context>
<context>
    <name>HistoryDialog</name>
    <message>
        <location filename="../history.cpp" line="753"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../history.cpp" line="755"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../history.cpp" line="757"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../history.ui" line="13"/>
        <source>History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../history.ui" line="40"/>
        <source>&amp;Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../history.ui" line="47"/>
        <source>Remove &amp;All</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HistoryMenu</name>
    <message>
        <location filename="../history.cpp" line="667"/>
        <source>Show All History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../history.cpp" line="689"/>
        <source>Clear History</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../history.cpp" line="674"/>
        <source>Clear History...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../history.cpp" line="689"/>
        <source>Do you want to clear the history?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HistoryModel</name>
    <message>
        <location filename="../history.cpp" line="427"/>
        <source>Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../history.cpp" line="428"/>
        <source>Address</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HistoryTreeModel</name>
    <message>
        <location filename="../history.cpp" line="1089"/>
        <source>Earlier Today</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../history.cpp" line="1093"/>
        <source>%n item(s)</source>
        <translation>
            <numerusform>%n item</numerusform>
            <numerusform>%n items</numerusform>
        </translation>
    </message>
</context>
<context>
    <name>LanguageManager</name>
    <message>
        <location filename="../languagemanager.cpp" line="154"/>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languagemanager.cpp" line="159"/>
        <source>Choose language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../languagemanager.cpp" line="160"/>
        <source>&lt;p&gt;You can run with a different language than&lt;br&gt;the operating system default.&lt;/p&gt;&lt;p&gt;Please choose the language which should be used&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NetworkAccessManager</name>
    <message>
        <location filename="../networkaccessmanager.cpp" line="151"/>
        <source>&lt;qt&gt;Enter username and password for &quot;%1&quot; at %2&lt;/qt&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../networkaccessmanager.cpp" line="175"/>
        <source>&lt;qt&gt;Connect to proxy &quot;%1&quot; using:&lt;/qt&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../networkaccessmanager.cpp" line="211"/>
        <source>SSL Errors:

%1

%2

Do you want to ignore these errors?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../networkaccessmanager.cpp" line="219"/>
        <source>Do you want to accept all these certificates?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NetworkMonitor</name>
    <message>
        <location filename="../networkmonitor/networkmonitor.cpp" line="47"/>
        <location filename="../networkmonitor/networkmonitor.cpp" line="50"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../networkmonitor/networkmonitor.cpp" line="47"/>
        <location filename="../networkmonitor/networkmonitor.cpp" line="50"/>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NetworkMonitorDialog</name>
    <message>
        <location filename="../networkmonitor/networkmonitor.ui" line="14"/>
        <source>Network Monitor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../networkmonitor/networkmonitor.ui" line="26"/>
        <source>Network Requests</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../networkmonitor/networkmonitor.ui" line="50"/>
        <source>Request Headers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../networkmonitor/networkmonitor.ui" line="68"/>
        <source>Response Headers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../networkmonitor/networkmonitor.ui" line="88"/>
        <source>&amp;Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../networkmonitor/networkmonitor.ui" line="95"/>
        <source>Remove &amp;All Requests</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PasswordDialog</name>
    <message>
        <location filename="../passworddialog.ui" line="13"/>
        <source>Authentication Required</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../passworddialog.ui" line="21"/>
        <source>DUMMY ICON</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../passworddialog.ui" line="34"/>
        <source>INTRO TEXT DUMMY</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../passworddialog.ui" line="43"/>
        <source>Username:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../passworddialog.ui" line="53"/>
        <source>Password:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PlainTextEditSearch</name>
    <message>
        <location filename="../plaintexteditsearch.cpp" line="63"/>
        <source>Not Found</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProxyDialog</name>
    <message>
        <location filename="../proxy.ui" line="13"/>
        <source>Proxy Authentication</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../proxy.ui" line="19"/>
        <source>ICON</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../proxy.ui" line="26"/>
        <source>Connect to proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../proxy.ui" line="36"/>
        <source>Username:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../proxy.ui" line="46"/>
        <source>Password:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../xbel.cpp" line="165"/>
        <source>The file is not an XBEL version 1.0 file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../xbel.cpp" line="263"/>
        <source>Unknown title</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RequestModel</name>
    <message>
        <location filename="../networkmonitor/networkmonitor.cpp" line="176"/>
        <source>Redirect: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../networkmonitor/networkmonitor.cpp" line="184"/>
        <source>Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../networkmonitor/networkmonitor.cpp" line="185"/>
        <source>Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../networkmonitor/networkmonitor.cpp" line="186"/>
        <source>Response</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../networkmonitor/networkmonitor.cpp" line="187"/>
        <source>Length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../networkmonitor/networkmonitor.cpp" line="188"/>
        <source>Content Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../networkmonitor/networkmonitor.cpp" line="189"/>
        <source>Info</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchBanner</name>
    <message>
        <location filename="../searchbanner.ui" line="19"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchbanner.ui" line="50"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchbanner.ui" line="57"/>
        <source>&lt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchbanner.ui" line="64"/>
        <source>&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../searchbanner.ui" line="74"/>
        <source>Done</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchLineEdit</name>
    <message>
        <location filename="../searchlineedit.cpp" line="198"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Settings</name>
    <message>
        <location filename="../settings.ui" line="33"/>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="85"/>
        <source>Set to current page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="105"/>
        <source>Remove history items:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="116"/>
        <source>After one day</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="121"/>
        <source>After one week</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="126"/>
        <source>After two weeks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="131"/>
        <source>After one month</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="136"/>
        <source>After one year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="141"/>
        <source>Manually</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="154"/>
        <source>Open links from applications:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="165"/>
        <source>In a tab in the current window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="170"/>
        <source>In a new window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="229"/>
        <source>Appearance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="271"/>
        <source>Fixed-width font:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="315"/>
        <source>Privacy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="321"/>
        <source>Web Content</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="327"/>
        <source>Enable Plugins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="337"/>
        <source>Enable Javascript</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="347"/>
        <source>View Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="360"/>
        <source>Cookies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="366"/>
        <source>Accept Cookies:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="377"/>
        <source>Always</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="382"/>
        <source>Never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="387"/>
        <source>Only from sites you navigate to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="395"/>
        <source>Exceptions...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="402"/>
        <source>Keep Cookies Until:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="508"/>
        <source>Use proxy server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="541"/>
        <source>Host name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="413"/>
        <source>They expire</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="418"/>
        <source>I exit the application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="423"/>
        <source>At most 90 days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="431"/>
        <source>Cookies...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="478"/>
        <source>Show only one close button instead of one for each tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="502"/>
        <source>Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="517"/>
        <source>Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="528"/>
        <source>Socks5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="533"/>
        <source>Http</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="558"/>
        <source>Port:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="591"/>
        <source>User Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="608"/>
        <source>Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="645"/>
        <source>Advanced</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="651"/>
        <source>Style Sheet:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="178"/>
        <source>Downloads</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="13"/>
        <source>Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="68"/>
        <source>Home Page:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="184"/>
        <source>Ask for a destination each time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="193"/>
        <source>Use this destination:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="235"/>
        <source>Standard font:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="254"/>
        <source>Times 16</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="264"/>
        <location filename="../settings.ui" line="294"/>
        <source>Select...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="284"/>
        <source>Courier 13</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="146"/>
        <source>On application exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="455"/>
        <source>Tabs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="461"/>
        <source>Select tabs and windows as they are created</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="468"/>
        <source>Confirm when closing multiple tabs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="39"/>
        <source>On startup:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="50"/>
        <source>Show my home page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="55"/>
        <source>Show a blank page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../settings.ui" line="60"/>
        <source>Restore windows and tabs from last time</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SourceViewer</name>
    <message>
        <location filename="../sourceviewer.cpp" line="40"/>
        <source>Loading...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sourceviewer.cpp" line="45"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sourceviewer.cpp" line="46"/>
        <source>&amp;Find</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sourceviewer.cpp" line="47"/>
        <source>&amp;View</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sourceviewer.cpp" line="48"/>
        <source>&amp;Wrap lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../sourceviewer.cpp" line="50"/>
        <source>Source of Page </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TabBar</name>
    <message>
        <location filename="../tabbar.cpp" line="162"/>
        <source>New &amp;Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tabbar.cpp" line="165"/>
        <source>Duplicate Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tabbar.cpp" line="171"/>
        <source>&amp;Close Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tabbar.cpp" line="175"/>
        <source>Close &amp;Other Tabs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tabbar.cpp" line="181"/>
        <source>Reload Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tabbar.cpp" line="187"/>
        <source>Reload All Tabs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tabbar.cpp" line="144"/>
        <source>Show Tab Bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tabbar.cpp" line="144"/>
        <source>Hide Tab Bar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TabWidget</name>
    <message>
        <location filename="../tabwidget.cpp" line="123"/>
        <source>New &amp;Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tabwidget.cpp" line="127"/>
        <source>&amp;Close Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tabwidget.cpp" line="147"/>
        <source>Show Next Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tabwidget.cpp" line="151"/>
        <source>Ctrl-]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tabwidget.cpp" line="157"/>
        <source>Show Previous Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tabwidget.cpp" line="161"/>
        <source>Ctrl-[</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tabwidget.cpp" line="172"/>
        <source>Recently Closed Tabs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tabwidget.cpp" line="471"/>
        <location filename="../tabwidget.cpp" line="504"/>
        <source>Untitled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tabwidget.cpp" line="611"/>
        <source>Do you really want to close this page?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../tabwidget.cpp" line="612"/>
        <source>You have modified this page and when closing it you would lose the modification.
Do you really want to close this page?
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ToolbarSearch</name>
    <message>
        <location filename="../toolbarsearch.cpp" line="153"/>
        <source>No Recent Searches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolbarsearch.cpp" line="157"/>
        <source>Recent Searches</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../toolbarsearch.cpp" line="164"/>
        <source>Clear Recent Searches</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WebPage</name>
    <message>
        <location filename="../webview.cpp" line="198"/>
        <source>Error loading page: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webview.cpp" line="202"/>
        <source>When connecting to: %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webview.cpp" line="203"/>
        <source>Check the address for errors such as &lt;b&gt;ww&lt;/b&gt;.arora-browser.org instead of &lt;b&gt;www&lt;/b&gt;.arora-browser.org</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webview.cpp" line="204"/>
        <source>If the address is correct, try to check the network connection.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webview.cpp" line="205"/>
        <source>If your computer or network is protected by a firewall or proxy, make sure that the browser is permitted to access the network.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WebView</name>
    <message>
        <location filename="../webview.cpp" line="267"/>
        <source>Open in New &amp;Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webview.cpp" line="268"/>
        <source>Open in New &amp;Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webview.cpp" line="270"/>
        <source>Save Lin&amp;k</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webview.cpp" line="271"/>
        <source>&amp;Bookmark This Link</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webview.cpp" line="275"/>
        <source>&amp;Copy Link Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webview.cpp" line="283"/>
        <source>Open Image in New &amp;Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webview.cpp" line="284"/>
        <source>Open Image in New &amp;Tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webview.cpp" line="286"/>
        <source>&amp;Save Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webview.cpp" line="287"/>
        <source>&amp;Copy Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webview.cpp" line="288"/>
        <source>C&amp;opy Image Location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../webview.cpp" line="448"/>
        <location filename="../webview.cpp" line="457"/>
        <source>Loading...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WebViewSearch</name>
    <message>
        <location filename="../webviewsearch.cpp" line="54"/>
        <source>Not Found</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
