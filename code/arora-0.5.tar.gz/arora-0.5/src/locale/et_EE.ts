<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="et_EE">
<context>
    <name>AboutDialog</name>
    <message>
        <source>About</source>
        <translation>Info</translation>
    </message>
    <message>
        <source>Authors</source>
        <translation>Autorid</translation>
    </message>
    <message>
        <source>License</source>
        <translation>Litsents</translation>
    </message>
    <message>
        <source>Lightweight WebKit-based web browser</source>
        <translation>Lihtne WebKit-põhine veebilehitseja</translation>
    </message>
    <message utf8="true">
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Copyright © 2007-2008 Benjamin C. Meyer &amp;lt;&lt;a href=&quot;mailto:ben@meyerhome.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;ben@meyerhome.net&lt;/span&gt;&lt;/a&gt;&amp;gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;DejaVu Sans&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Copyright © 2007-2008 Benjamin C. Meyer &amp;lt;&lt;a href=&quot;mailto:ben@meyerhome.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;ben@meyerhome.net&lt;/span&gt;&lt;/a&gt;&amp;gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;a href=&quot;http://arora-browser.org&quot;&gt;http://arora-browser.org&lt;/a&gt;</source>
        <translation>&lt;a href=&quot;http://arora-browser.org&quot;&gt;http://arora-browser.org&lt;/a&gt;</translation>
    </message>
    <message>
        <source>Close</source>
        <translation>Sulge</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot;font-size:9pt;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Copyright © 2007-2008 Benjamin C. Meyer &amp;lt;&lt;a href=&quot;mailto:ben@meyerhome.net&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0057ae;&quot;&gt;ben@meyerhome.net&lt;/span&gt;&lt;/a&gt;&amp;gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AddBookmarkDialog</name>
    <message>
        <source>Add Bookmark</source>
        <translation>Lisa järjehoidja</translation>
    </message>
    <message>
        <source>Type a name for the bookmark, and choose where to keep it.</source>
        <translation>Sisestage järjehoidjale nimi ja valige, kus seda hoida.</translation>
    </message>
</context>
<context>
    <name>BookmarksDialog</name>
    <message>
        <source>Open</source>
        <translation>&amp;Ava</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>&amp;Kustuta</translation>
    </message>
    <message>
        <source>New Folder</source>
        <translation>Uus kaust</translation>
    </message>
    <message>
        <source>Bookmarks</source>
        <translation>Järjehoidjad</translation>
    </message>
    <message>
        <source>&amp;Remove</source>
        <translation>&amp;Eemalda</translation>
    </message>
    <message>
        <source>Add Folder</source>
        <translation>Lisa kaust</translation>
    </message>
    <message>
        <source>Open in New Tab</source>
        <translation>Ava uues &amp;sakis</translation>
    </message>
    <message>
        <source>Edit Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Edit Address</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BookmarksManager</name>
    <message>
        <source>Error when loading bookmarks on line %1, column %2:
%3</source>
        <translation>Viga järjehoidjate laadimisel real %1, veerus %2: %3</translation>
    </message>
    <message>
        <source>Toolbar Bookmarks</source>
        <translation>Tööriistariba järjehoidjad</translation>
    </message>
    <message>
        <source>Menu</source>
        <translation>Menüü</translation>
    </message>
    <message>
        <source>Open File</source>
        <translation>Ava fail</translation>
    </message>
    <message>
        <source>XBEL (*.xbel *.xml)</source>
        <translation>XBEL (*.xbel *.xml)</translation>
    </message>
    <message>
        <source>Imported %1</source>
        <translation>%1 imporditud</translation>
    </message>
    <message>
        <source>Save File</source>
        <translation>Salvesta fail</translation>
    </message>
    <message>
        <source>%1 Bookmarks.xbel</source>
        <translation>%1 järjehoidjad.xbel</translation>
    </message>
    <message>
        <source>Export error</source>
        <translation>Viga eksportimisel</translation>
    </message>
    <message>
        <source>error saving bookmarks</source>
        <translation>viga järjehoidjate salvestamisel</translation>
    </message>
    <message>
        <source>Remove Bookmark</source>
        <translation>Eemalda järjehoidja</translation>
    </message>
    <message>
        <source>Insert Bookmark</source>
        <translation>Sisesta järjehoidja</translation>
    </message>
    <message>
        <source>Name Change</source>
        <translation>Nime muutus</translation>
    </message>
    <message>
        <source>Address Change</source>
        <translation>Aadressi muutus</translation>
    </message>
    <message>
        <source>Bookmarks Bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bookmarks Menu</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BookmarksModel</name>
    <message>
        <source>Title</source>
        <translation>Pealkiri</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Aadress</translation>
    </message>
</context>
<context>
    <name>BookmarksToolBar</name>
    <message>
        <source>Bookmark</source>
        <translation>Järjehoidja</translation>
    </message>
    <message>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open in New &amp;Tab</source>
        <translation type="unfinished">Ava uues &amp;sakis</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add Bookmark...</source>
        <translation type="unfinished">&amp;Lisa järjehoidja...</translation>
    </message>
</context>
<context>
    <name>BrowserApplication</name>
    <message>
        <source>There are %1 windows and %2 tabs open
Do you want to quit anyway?</source>
        <translation>Lahti on %1 akent ja %2 sakki.Kas Te soovite siiski väljuda?</translation>
    </message>
    <message>
        <source>Restore failed</source>
        <translation>Taastamine ebaõnnestus</translation>
    </message>
    <message>
        <source>The saved session will not being restored because last time it was restored Arora crashed.</source>
        <translation type="obsolete">Salvestatud sessiooni ei taastata, sest viimane kord kui Arora seda üritas, jooksis ta kokku.</translation>
    </message>
    <message>
        <source> (Change: %1 %2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The saved session will not be restored because Arora crashed while trying to restore this session.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BrowserMainWindow</name>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Fail</translation>
    </message>
    <message>
        <source>&amp;New Window</source>
        <translation>Uus ake&amp;n</translation>
    </message>
    <message>
        <source>&amp;Open File...</source>
        <translation>&amp;Ava fail...</translation>
    </message>
    <message>
        <source>Open &amp;Location...</source>
        <translation>Ava as&amp;ukoht...</translation>
    </message>
    <message>
        <source>&amp;Save As...</source>
        <translation>&amp;Salvesta failina...</translation>
    </message>
    <message>
        <source>&amp;Import Bookmarks...</source>
        <translation>&amp;Impordi järjehoidjaid...</translation>
    </message>
    <message>
        <source>&amp;Export Bookmarks...</source>
        <translation>&amp;Ekspordi järjehoidjad...</translation>
    </message>
    <message>
        <source>P&amp;rint Preview...</source>
        <translation>P&amp;rintimise eelvaade...</translation>
    </message>
    <message>
        <source>&amp;Print...</source>
        <translation>&amp;Prindi...</translation>
    </message>
    <message>
        <source>Private &amp;Browsing...</source>
        <translation>Privaatne veebi&amp;lehitsemine...</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>&amp;Välju</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation>&amp;Redigeeri</translation>
    </message>
    <message>
        <source>&amp;Undo</source>
        <translation>&amp;Tühista</translation>
    </message>
    <message>
        <source>&amp;Redo</source>
        <translation>Tee &amp;uuesti</translation>
    </message>
    <message>
        <source>Cu&amp;t</source>
        <translation>&amp;Lõika</translation>
    </message>
    <message>
        <source>&amp;Copy</source>
        <translation>&amp;Kopeeri</translation>
    </message>
    <message>
        <source>&amp;Paste</source>
        <translation>Klee&amp;bi</translation>
    </message>
    <message>
        <source>&amp;Find</source>
        <translation>&amp;Otsi</translation>
    </message>
    <message>
        <source>&amp;Find Next</source>
        <translation type="obsolete">Otsi &amp;järgmist</translation>
    </message>
    <message>
        <source>&amp;Find Previous</source>
        <translation type="obsolete">Otsi eel&amp;mist</translation>
    </message>
    <message>
        <source>&amp;Preferences</source>
        <translation type="obsolete">&amp;Eelistused</translation>
    </message>
    <message>
        <source>Ctrl+,</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation>&amp;Vaade</translation>
    </message>
    <message>
        <source>Shift+Ctrl+B</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+|</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl+/</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Stop</source>
        <translation>&amp;Katkesta lehekülje laadimine</translation>
    </message>
    <message>
        <source>Reload Page</source>
        <translation type="obsolete">Lae lehekülg &amp;uuesti</translation>
    </message>
    <message>
        <source>&amp;Make Text Bigger</source>
        <translation type="obsolete">Tee tekst &amp;suuremaks</translation>
    </message>
    <message>
        <source>&amp;Make Text Normal</source>
        <translation type="obsolete">T&amp;aasta teksti suurus</translation>
    </message>
    <message>
        <source>&amp;Make Text Smaller</source>
        <translation type="obsolete">Tee tekst &amp;väiksemaks</translation>
    </message>
    <message>
        <source>Page S&amp;ource</source>
        <translation>Veebilehe &amp;lähtekood</translation>
    </message>
    <message>
        <source>Ctrl+Alt+U</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Full Screen</source>
        <translation>&amp;Täisekraanvaade</translation>
    </message>
    <message>
        <source>Hi&amp;story</source>
        <translation>A&amp;jalugu</translation>
    </message>
    <message>
        <source>Back</source>
        <translation>&amp;Tagasi</translation>
    </message>
    <message>
        <source>Forward</source>
        <translation>&amp;Edasi</translation>
    </message>
    <message>
        <source>Home</source>
        <translation>&amp;Koduleht</translation>
    </message>
    <message>
        <source>Restore Last Session</source>
        <translation>Taasta eelmine &amp;sessioon</translation>
    </message>
    <message>
        <source>&amp;Bookmarks</source>
        <translation>&amp;Järjehoidjad</translation>
    </message>
    <message>
        <source>Manage Bookmarks...</source>
        <translation>&amp;Halda järjehoidjaid...</translation>
    </message>
    <message>
        <source>Add Bookmark...</source>
        <translation>&amp;Lisa järjehoidja...</translation>
    </message>
    <message>
        <source>&amp;Window</source>
        <translation>A&amp;ken</translation>
    </message>
    <message>
        <source>&amp;Tools</source>
        <translation>&amp;Tööriistad</translation>
    </message>
    <message>
        <source>Web &amp;Search</source>
        <translation>Veebi&amp;otsing</translation>
    </message>
    <message>
        <source>Ctrl+K</source>
        <comment>Web Search</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Enable Web &amp;Inspector</source>
        <translation>Aktiveeri &amp;Veebiinspektor</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Abi</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>Lähemalt &amp;Qt kohta</translation>
    </message>
    <message>
        <source>About &amp;Arora</source>
        <translation>Lähemalt &amp;Arora kohta</translation>
    </message>
    <message>
        <source>Navigation</source>
        <translation>Navigeerimine</translation>
    </message>
    <message>
        <source>Show Status Bar</source>
        <translation>Näita olekuriba</translation>
    </message>
    <message>
        <source>Hide Status Bar</source>
        <translation>Peida olekuriba</translation>
    </message>
    <message>
        <source>Show Toolbar</source>
        <translation>Näita tööriistariba</translation>
    </message>
    <message>
        <source>Hide Toolbar</source>
        <translation>Peida tööriistariba</translation>
    </message>
    <message>
        <source>Arora</source>
        <translation>Arora</translation>
    </message>
    <message>
        <source>%1 - Arora</source>
        <comment>Page title and Browser name</comment>
        <translation>%1 - Arora</translation>
    </message>
    <message>
        <source>Open Web Resource</source>
        <translation>Ava veebiressurss</translation>
    </message>
    <message>
        <source>Web Resources (*.html *.htm *.svg *.png *.gif *.svgz);;All files (*.*)</source>
        <translation>Veebiressursid (*.html *.htm *.svg *.png *.gif *.svgz);;Kõik failid (*.*)</translation>
    </message>
    <message>
        <source>Print Document</source>
        <translation>Prindi dokument</translation>
    </message>
    <message>
        <source>Are you sure you want to turn on private browsing?</source>
        <translation>Kas Te olete kindel, et soovite sisse lülitada privaatse lehitsemise?</translation>
    </message>
    <message>
        <source>Are you sure you want to close the window?  There are %1 tabs open</source>
        <translation>Kas Te olete kindel, et soovite akent sulgeda? Avatud on %1 sakki</translation>
    </message>
    <message>
        <source>Page Source of %1</source>
        <translation type="obsolete">Lehekülje %1 lähtekood</translation>
    </message>
    <message>
        <source>Web Inspector</source>
        <translation>Veebiinspektor</translation>
    </message>
    <message>
        <source>The web inspector will only work correctly for pages that were loaded after enabling.
Do you want to reload all pages?</source>
        <translation>Veebiinspektor töötab korrektselt ainult lehekülgede puhul, mis laetakse pärast Veebiinspektori aktiveerimist.
Kas Te soovite kõik leheküljed uuesti laadida?</translation>
    </message>
    <message>
        <source>Stop loading the current page</source>
        <translation>Peata käesoleva lehekülje laadimine</translation>
    </message>
    <message>
        <source>Reload the current page</source>
        <translation>Lae käesolev lehekülg uuesti</translation>
    </message>
    <message>
        <source>Downloads</source>
        <translation>&amp;Allalaadimised</translation>
    </message>
    <message>
        <source>Alt+Ctrl+L</source>
        <comment>Download Manager</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Clear Private Data</source>
        <translation>Kustuta &amp;privaatseid andmeid</translation>
    </message>
    <message>
        <source>Ctrl+Shift+Delete</source>
        <comment>Clear Private Data</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Bookmarks Bar</source>
        <translation>Näita järjehoidjate riba</translation>
    </message>
    <message>
        <source>Hide Bookmarks Bar</source>
        <translation>Peida järjehoidjate riba</translation>
    </message>
    <message>
        <source>&lt;b&gt;%1&lt;/b&gt;&lt;br&gt;&lt;br&gt;When private browsing is turned on, some actions concerning your privacy will be disabled:&lt;ul&gt;&lt;li&gt; Webpages are not added to the history.&lt;/li&gt;&lt;li&gt; Items are automatically removed from the Downloads window.&lt;/li&gt;&lt;li&gt; New cookies are not stored, current cookies can&apos;t be accessed.&lt;/li&gt;&lt;li&gt; Site icons won&apos;t be stored, session won&apos;t be saved.&lt;/li&gt;&lt;li&gt; Searches are not addded to the pop-up menu in the search box.&lt;/li&gt;&lt;/ul&gt;Until you close the window, you can still click the Back and Forward buttons to return to the webpages you have opened.</source>
        <translation>&lt;b&gt;%1&lt;/b&gt;&lt;br&gt;&lt;br&gt;Kui privaatne lehitsemine on sisse lülitatud, ei viida läbi teatud Teie privaatsust puudutavaid toiminguid:&lt;ul&gt;&lt;li&gt; Veebilehti ei sisestata ajalukku.&lt;/li&gt;&lt;li&gt; Allalaadimisakent puhastatakse automaatselt.&lt;/li&gt;&lt;li&gt; Uusi küpsiseid ei salvestata, olemasolevatele küpsistele keelatakse veebilehtedel ligipääs.&lt;/li&gt;&lt;li&gt; Veebilehtede ikoone ei salvestata.&lt;/li&gt;&lt;li&gt; Sessioone ei salvestata.&lt;/li&gt;&lt;li&gt; Tehtud otsinguid ei lisata otsingukasti rippmenüüsse.&lt;/li&gt;&lt;/ul&gt;Akna sulgemiseni võite siiski kasutada Edasi- ja Tagasi-nuppe avatud veebilehtedele tagasi pöördumiseks.</translation>
    </message>
    <message>
        <source>Find &amp;Next</source>
        <translation type="obsolete">Otsi &amp;järgmist</translation>
    </message>
    <message>
        <source>Find P&amp;revious</source>
        <translation>Otsi eel&amp;mist</translation>
    </message>
    <message>
        <source>Prefe&amp;rences</source>
        <translation type="obsolete">&amp;Eelistused</translation>
    </message>
    <message>
        <source>&amp;Reload Page</source>
        <translation>Lae lehekülg &amp;uuesti</translation>
    </message>
    <message>
        <source>Make Text &amp;Bigger</source>
        <translation>Tee tekst &amp;suuremaks</translation>
    </message>
    <message>
        <source>Make Text &amp;Normal</source>
        <translation>T&amp;aasta teksti suurus</translation>
    </message>
    <message>
        <source>Make Text &amp;Smaller</source>
        <translation>Tee tekst &amp;väiksemaks</translation>
    </message>
    <message>
        <source>Find Nex&amp;t</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Prefere&amp;nces...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show Menu Bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show &amp;Network Monitor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Switch application language </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ClearButton</name>
    <message>
        <source>Clear</source>
        <translation>Tühjenda</translation>
    </message>
</context>
<context>
    <name>ClearPrivateData</name>
    <message>
        <source>Clear Private Data</source>
        <translation>Privaatsete andmete kustutamine</translation>
    </message>
    <message>
        <source>Clear the following items:</source>
        <translation>Kustuta järgmised andmed:</translation>
    </message>
    <message>
        <source>&amp;Browsing History</source>
        <translation>&amp;Veebi lehitsemise ajalugu</translation>
    </message>
    <message>
        <source>&amp;Download History</source>
        <translation>&amp;Allalaadimise ajalugu</translation>
    </message>
    <message>
        <source>&amp;Search History</source>
        <translation>&amp;Otsingute ajalugu</translation>
    </message>
    <message>
        <source>&amp;Cookies</source>
        <translation>&amp;Küpsised</translation>
    </message>
    <message>
        <source>C&amp;ache</source>
        <translation type="obsolete">&amp;Puhverdatud veebileheküljed</translation>
    </message>
    <message>
        <source>Website &amp;Icons</source>
        <translation>Veebilehekülgede &amp;ikoonid</translation>
    </message>
    <message>
        <source>Clear &amp;Private Data</source>
        <translation>Kustuta &amp;privaatsed andmed</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>&amp;Loobu</translation>
    </message>
    <message>
        <source>C&amp;ached Web Pages</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CookieExceptionsModel</name>
    <message>
        <source>Website</source>
        <translation>Veebileht</translation>
    </message>
    <message>
        <source>Status</source>
        <translation type="obsolete">Reegel</translation>
    </message>
    <message>
        <source>Allow</source>
        <translation>Luba</translation>
    </message>
    <message>
        <source>Block</source>
        <translation>Keela</translation>
    </message>
    <message>
        <source>Allow For Session</source>
        <translation>Luba sessiooniks</translation>
    </message>
    <message>
        <source>Rule</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CookieModel</name>
    <message>
        <source>Website</source>
        <translation>Veebileht</translation>
    </message>
    <message>
        <source>Name</source>
        <translation>Nimi</translation>
    </message>
    <message>
        <source>Path</source>
        <translation>Asukoht</translation>
    </message>
    <message>
        <source>Secure</source>
        <translation>Turvaline</translation>
    </message>
    <message>
        <source>Expires</source>
        <translation>Aegub</translation>
    </message>
    <message>
        <source>Contents</source>
        <translation>Sisu</translation>
    </message>
    <message>
        <source>true</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>false</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CookiesDialog</name>
    <message>
        <source>Cookies</source>
        <translation>Küpsised</translation>
    </message>
    <message>
        <source>&amp;Remove</source>
        <translation>&amp;Eemalda</translation>
    </message>
    <message>
        <source>Remove &amp;All Cookies</source>
        <translation>Eemalda &amp;kõik küpsised</translation>
    </message>
</context>
<context>
    <name>CookiesExceptionsDialog</name>
    <message>
        <source>Cookie Exceptions</source>
        <translation>Küpsiste erandid</translation>
    </message>
    <message>
        <source>New Exception</source>
        <translation>Uus erand</translation>
    </message>
    <message>
        <source>Domain:</source>
        <translation>Domeen:</translation>
    </message>
    <message>
        <source>Block</source>
        <translation>Keela</translation>
    </message>
    <message>
        <source>Allow For Session</source>
        <translation>Luba sessiooniks</translation>
    </message>
    <message>
        <source>Allow</source>
        <translation>Luba</translation>
    </message>
    <message>
        <source>Exceptions</source>
        <translation>Erandid</translation>
    </message>
    <message>
        <source>&amp;Remove</source>
        <translation>&amp;Eemalda</translation>
    </message>
    <message>
        <source>Remove &amp;All</source>
        <translation>Eemalda &amp;kõik</translation>
    </message>
</context>
<context>
    <name>DownloadDialog</name>
    <message>
        <source>Downloads</source>
        <translation>Allalaadimised</translation>
    </message>
    <message>
        <source>Clean up</source>
        <translation>Puhasta</translation>
    </message>
    <message>
        <source>0 Items</source>
        <translation>0 elementi</translation>
    </message>
    <message>
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DownloadItem</name>
    <message>
        <source>Save File</source>
        <translation>Salvesta fail</translation>
    </message>
    <message>
        <source>Download canceled: %1</source>
        <translation>Allalaadimine katkestatud: %1</translation>
    </message>
    <message>
        <source>Error opening save file: %1</source>
        <translation type="obsolete">Viga väljundfaili avamisel: %1</translation>
    </message>
    <message>
        <source>Error saving: %1</source>
        <translation>Viga salvestamisel: %1</translation>
    </message>
    <message>
        <source>Network Error: %1</source>
        <translation>Võrgu viga: %1</translation>
    </message>
    <message>
        <source>seconds</source>
        <translation>sekundit</translation>
    </message>
    <message>
        <source>%1 of %2 (%3/sec) %4</source>
        <translation>%1 / %2 (%3/s) %4</translation>
    </message>
    <message>
        <source>?</source>
        <translation>?</translation>
    </message>
    <message>
        <source>%1 of %2 - Stopped</source>
        <translation>%1 / %2 - Katkestatud</translation>
    </message>
    <message>
        <source>bytes</source>
        <translation>baiti</translation>
    </message>
    <message>
        <source>kB</source>
        <translation>kiB</translation>
    </message>
    <message>
        <source>MB</source>
        <translation>MiB</translation>
    </message>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ico</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Filename</source>
        <translation>Faili nimi</translation>
    </message>
    <message>
        <source>Try Again</source>
        <translation>Proovi uuesti</translation>
    </message>
    <message>
        <source>Stop</source>
        <translation>Katkesta</translation>
    </message>
    <message>
        <source>Open</source>
        <translation>Ava</translation>
    </message>
    <message numerus="yes">
        <source>- %n minutes remaining</source>
        <translation>
            <numerusform>- %n minut jäänud</numerusform>
            <numerusform>- %n minutit jäänud</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <source>- %n seconds remaining</source>
        <translation>
            <numerusform>- %n sekund jäänud</numerusform>
            <numerusform>- %n sekundit jäänud</numerusform>
        </translation>
    </message>
    <message>
        <source>Error opening output file: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DownloadManager</name>
    <message numerus="yes">
        <source>%n Download(s)</source>
        <translation>
            <numerusform>%n Download</numerusform>
            <numerusform>%n Downloads</numerusform>
        </translation>
    </message>
</context>
<context>
    <name>HistoryDialog</name>
    <message>
        <source>Open</source>
        <translation>&amp;Ava</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>&amp;Kopeeri</translation>
    </message>
    <message>
        <source>Delete</source>
        <translation>K&amp;ustuta</translation>
    </message>
    <message>
        <source>History</source>
        <translation>Ajalugu</translation>
    </message>
    <message>
        <source>&amp;Remove</source>
        <translation>&amp;Eemalda</translation>
    </message>
    <message>
        <source>Remove &amp;All</source>
        <translation>Eemalda &amp;kõik</translation>
    </message>
</context>
<context>
    <name>HistoryMenu</name>
    <message>
        <source>Show All History</source>
        <translation>&amp;Näita tervet ajalugu</translation>
    </message>
    <message>
        <source>Clear History</source>
        <translation>&amp;Unusta ajalugu</translation>
    </message>
    <message>
        <source>Clear History...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to clear the history?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HistoryModel</name>
    <message>
        <source>Title</source>
        <translation>Pealkiri</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Aadress</translation>
    </message>
</context>
<context>
    <name>HistoryTreeModel</name>
    <message>
        <source>Earlier Today</source>
        <translation>Varem täna</translation>
    </message>
    <message numerus="yes">
        <source>%n item(s)</source>
        <translation>
            <numerusform>%n item</numerusform>
            <numerusform>%n items</numerusform>
        </translation>
    </message>
</context>
<context>
    <name>LanguageManager</name>
    <message>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Choose language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;You can run with a different language than&lt;br&gt;the operating system default.&lt;/p&gt;&lt;p&gt;Please choose the language which should be used&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NetworkAccessManager</name>
    <message>
        <source>&lt;qt&gt;Enter username and password for &quot;%1&quot; at %2&lt;/qt&gt;</source>
        <translation>&lt;qt&gt;Palun sisestage kasutajanimi ja salasõna &quot;%1&quot; jaoks aadressilt %2&lt;/qt&gt;</translation>
    </message>
    <message>
        <source>&lt;qt&gt;Connect to proxy &quot;%1&quot; using:&lt;/qt&gt;</source>
        <translation>&lt;qt&gt;Ühendu puhverserveriga &quot;%1&quot; kasutades:&lt;/qt&gt;</translation>
    </message>
    <message>
        <source>SSL Errors:

%1

%2

Do you want to ignore these errors?</source>
        <translation>SSL vead:

%1

%2

Kas Te soovite neid vigu ignoreerida?</translation>
    </message>
    <message>
        <source>Do you want to accept all these certificates?</source>
        <translation>Kas Te soovite kõik need sertifikaadid aksepteerida?</translation>
    </message>
</context>
<context>
    <name>NetworkMonitor</name>
    <message>
        <source>Name</source>
        <translation type="unfinished">Nimi</translation>
    </message>
    <message>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>NetworkMonitorDialog</name>
    <message>
        <source>Network Monitor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Network Requests</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Request Headers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Response Headers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&amp;Remove</source>
        <translation type="unfinished">&amp;Eemalda</translation>
    </message>
    <message>
        <source>Remove &amp;All Requests</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PasswordDialog</name>
    <message>
        <source>Authentication Required</source>
        <translation>Nõutud audentimine</translation>
    </message>
    <message>
        <source>DUMMY ICON</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>INTRO TEXT DUMMY</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Kasutajanimi:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Salasõna:</translation>
    </message>
</context>
<context>
    <name>PlainTextEditSearch</name>
    <message>
        <source>Not Found</source>
        <translation type="unfinished">Ei leitud</translation>
    </message>
</context>
<context>
    <name>ProxyDialog</name>
    <message>
        <source>Proxy Authentication</source>
        <translation>Audentimine puhverserveriga</translation>
    </message>
    <message>
        <source>ICON</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Connect to proxy</source>
        <translation>Ühendu puhverserveriga</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Kasutajanimi:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Salasõna:</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>The file is not an XBEL version 1.0 file.</source>
        <translation>See fail ei ole XBEL versioon 1.0 vormingus.</translation>
    </message>
    <message>
        <source>Unknown title</source>
        <translation>Tundmatu pealkiri</translation>
    </message>
</context>
<context>
    <name>RequestModel</name>
    <message>
        <source>Redirect: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="unfinished">Aadress</translation>
    </message>
    <message>
        <source>Response</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Content Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Info</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchBanner</name>
    <message>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;</source>
        <translation>&lt;</translation>
    </message>
    <message>
        <source>&gt;</source>
        <translation>&gt;</translation>
    </message>
    <message>
        <source>Done</source>
        <translation>Valmis</translation>
    </message>
</context>
<context>
    <name>SearchLineEdit</name>
    <message>
        <source>Search</source>
        <translation>Otsi</translation>
    </message>
</context>
<context>
    <name>Settings</name>
    <message>
        <source>Settings</source>
        <translation type="obsolete">Eelistused</translation>
    </message>
    <message>
        <source>General</source>
        <translation>Üldine</translation>
    </message>
    <message>
        <source>Home:</source>
        <translation type="obsolete">Koduleht:</translation>
    </message>
    <message>
        <source>Set to current page</source>
        <translation>Muuda hetkel avatud leheks</translation>
    </message>
    <message>
        <source>Remove history items:</source>
        <translation>Eemalda ajaloo elemendid:</translation>
    </message>
    <message>
        <source>After one day</source>
        <translation>Pärast ühte päeva</translation>
    </message>
    <message>
        <source>After one week</source>
        <translation>Pärast ühte nädalat</translation>
    </message>
    <message>
        <source>After two weeks</source>
        <translation>Pärast kahte nädalat</translation>
    </message>
    <message>
        <source>After one month</source>
        <translation>Pärast ühte kuud</translation>
    </message>
    <message>
        <source>After one year</source>
        <translation>Pärast ühte aastat</translation>
    </message>
    <message>
        <source>Manually</source>
        <translation>Käsitsi</translation>
    </message>
    <message>
        <source>Open links from applications:</source>
        <translation>Ava viitasid teistest rakendustest:</translation>
    </message>
    <message>
        <source>In a tab in the current window</source>
        <translation>Aktiivse akna uues sakis</translation>
    </message>
    <message>
        <source>In a new window</source>
        <translation>Uues aknas</translation>
    </message>
    <message>
        <source>Appearance</source>
        <translation>Välimus</translation>
    </message>
    <message>
        <source>Fixed-width font:</source>
        <translation>Fikseeritud laiusega kirjatüüp:</translation>
    </message>
    <message>
        <source>Privacy</source>
        <translation>Privaatsus</translation>
    </message>
    <message>
        <source>Web Content</source>
        <translation>Veebilehtede sisu</translation>
    </message>
    <message>
        <source>Enable Plugins</source>
        <translation>Luba pistikprogrammid</translation>
    </message>
    <message>
        <source>Enable Javascript</source>
        <translation>Luba Javascript</translation>
    </message>
    <message>
        <source>Cookies</source>
        <translation>Küpsised</translation>
    </message>
    <message>
        <source>Accept Cookies:</source>
        <translation>Luba küpsiseid:</translation>
    </message>
    <message>
        <source>Always</source>
        <translation>Alati</translation>
    </message>
    <message>
        <source>Never</source>
        <translation>Mitte kunagi</translation>
    </message>
    <message>
        <source>Only from sites you navigate to</source>
        <translation>Ainult veebilehtedelt, mida külastan</translation>
    </message>
    <message>
        <source>Exceptions...</source>
        <translation>Erandid...</translation>
    </message>
    <message>
        <source>Keep until:</source>
        <translation type="obsolete">Hoia küpsiseid kuni:</translation>
    </message>
    <message>
        <source>They expire</source>
        <translation>Nad aeguvad</translation>
    </message>
    <message>
        <source>I exit the application</source>
        <translation>Rakendus suletakse</translation>
    </message>
    <message>
        <source>At most 90 days</source>
        <translation>Ülimalt 90 päeva</translation>
    </message>
    <message>
        <source>Cookies...</source>
        <translation>Küpsised...</translation>
    </message>
    <message>
        <source>Proxy</source>
        <translation>Puhverserver</translation>
    </message>
    <message>
        <source>Enable proxy</source>
        <translation type="obsolete">Kasuta puhverserverit</translation>
    </message>
    <message>
        <source>Type:</source>
        <translation>Tüüp:</translation>
    </message>
    <message>
        <source>Socks5</source>
        <translation>Socks5</translation>
    </message>
    <message>
        <source>Http</source>
        <translation>HTTP</translation>
    </message>
    <message>
        <source>Host:</source>
        <translation type="obsolete">Hostinimi:</translation>
    </message>
    <message>
        <source>Port:</source>
        <translation>Port:</translation>
    </message>
    <message>
        <source>User Name:</source>
        <translation>Kasutajanimi:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Salasõna:</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation>Muud</translation>
    </message>
    <message>
        <source>Style Sheet:</source>
        <translation>Stiilileht:</translation>
    </message>
    <message>
        <source>Downloads</source>
        <translation>Allalaadimised</translation>
    </message>
    <message>
        <source>Ask for a destination each time</source>
        <translation>Küsi sihtkataloogi iga allalaadimise puhul</translation>
    </message>
    <message>
        <source>Use this destination:</source>
        <translation>Kasuta seda kataloogi:</translation>
    </message>
    <message>
        <source>Standard font:</source>
        <translation>Vaikimisi kirjatüüp:</translation>
    </message>
    <message>
        <source>Times 16</source>
        <translation>Times 16</translation>
    </message>
    <message>
        <source>Select...</source>
        <translation>Vali...</translation>
    </message>
    <message>
        <source>Courier 13</source>
        <translation>Courier 13</translation>
    </message>
    <message>
        <source>On application exit</source>
        <translation>Rakenduse sulgemisel</translation>
    </message>
    <message>
        <source>Enable Images</source>
        <translation type="obsolete">Näita pilte</translation>
    </message>
    <message>
        <source>Tabs</source>
        <translation>Sakid</translation>
    </message>
    <message>
        <source>Select tabs and windows as they are created</source>
        <translation>Vali sakid ja aknad kui nad luuakse</translation>
    </message>
    <message>
        <source>Confirm when closing multiple tabs</source>
        <translation>Küsi kinnitust mitme saki sulgemisel</translation>
    </message>
    <message>
        <source>On startup:</source>
        <translation>Programmi käivitamisel:</translation>
    </message>
    <message>
        <source>Show my home page</source>
        <translation>Näita kodulehte</translation>
    </message>
    <message>
        <source>Show a blank page</source>
        <translation>Näita tühja lehte</translation>
    </message>
    <message>
        <source>Restore windows and tabs from last time</source>
        <translation>Taasta aknad ja sakid eelmisest korrast</translation>
    </message>
    <message>
        <source>Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Home Page:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>View Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Keep Cookies Until:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Show only one close button instead of one for each tab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Use proxy server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Host name:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SourceViewer</name>
    <message>
        <source>Loading...</source>
        <translation type="unfinished">Laadimine...</translation>
    </message>
    <message>
        <source>&amp;Edit</source>
        <translation type="unfinished">&amp;Redigeeri</translation>
    </message>
    <message>
        <source>&amp;Find</source>
        <translation type="unfinished">&amp;Otsi</translation>
    </message>
    <message>
        <source>&amp;View</source>
        <translation type="unfinished">&amp;Vaade</translation>
    </message>
    <message>
        <source>&amp;Wrap lines</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Source of Page </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TabBar</name>
    <message>
        <source>New &amp;Tab</source>
        <translation>Uus &amp;sakk</translation>
    </message>
    <message>
        <source>Duplicate Tab</source>
        <translation>&amp;Duplikeeri sakk</translation>
    </message>
    <message>
        <source>&amp;Close Tab</source>
        <translation>S&amp;ulge sakk</translation>
    </message>
    <message>
        <source>Close &amp;Other Tabs</source>
        <translation>Sulge &amp;teised sakid</translation>
    </message>
    <message>
        <source>Reload Tab</source>
        <translation>Lae sakk uuesti</translation>
    </message>
    <message>
        <source>Reload All Tabs</source>
        <translation>Lea kõik sakid uuesti</translation>
    </message>
    <message>
        <source>Show Tab Bar</source>
        <translation>Näita sakkide riba</translation>
    </message>
    <message>
        <source>Hide Tab Bar</source>
        <translation>Peida sakkide riba</translation>
    </message>
</context>
<context>
    <name>TabWidget</name>
    <message>
        <source>New &amp;Tab</source>
        <translation>Uus sa&amp;kk</translation>
    </message>
    <message>
        <source>&amp;Close Tab</source>
        <translation>Sul&amp;ge sakk</translation>
    </message>
    <message>
        <source>Show Next Tab</source>
        <translation>Näita &amp;järgmist sakki</translation>
    </message>
    <message>
        <source>Show Previous Tab</source>
        <translation>Näita &amp;eelmist sakki</translation>
    </message>
    <message>
        <source>Recently Closed Tabs</source>
        <translation>&amp;Viimati suletud sakid</translation>
    </message>
    <message>
        <source>(Untitled)</source>
        <translation type="obsolete">(nimetu)</translation>
    </message>
    <message>
        <source>Do you really want to close this page?</source>
        <translation>Kas Te tõesti soovite selle lehekülje sulgeda?</translation>
    </message>
    <message>
        <source>You have modified this page and when closing it you would lose the modification.
Do you really want to close this page?
</source>
        <translation>Te olete seda lehekülge muutnud. Lehekülje sulgemisel muutused kaotatakse.Kas Te tõesti soovite selle lehekülje sulgeda?</translation>
    </message>
    <message>
        <source>Ctrl-]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Ctrl-[</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Untitled</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ToolbarSearch</name>
    <message>
        <source>No Recent Searches</source>
        <translation>Hiljutisi otsinguid pole</translation>
    </message>
    <message>
        <source>Recent Searches</source>
        <translation>Hiljuti tehtud otsingud</translation>
    </message>
    <message>
        <source>Clear Recent Searches</source>
        <translation>Unusta hiljuti tehtud otsingud</translation>
    </message>
</context>
<context>
    <name>WebPage</name>
    <message>
        <source>Error loading page: %1</source>
        <translation>Viga lehekülje laadimisel: %1</translation>
    </message>
    <message>
        <source>When connecting to: %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Check the address for errors such as &lt;b&gt;ww&lt;/b&gt;.arora-browser.org instead of &lt;b&gt;www&lt;/b&gt;.arora-browser.org</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If the address is correct, try to check the network connection.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>If your computer or network is protected by a firewall or proxy, make sure that the browser is permitted to access the network.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>WebView</name>
    <message>
        <source>Open in New &amp;Window</source>
        <translation>Ava uues &amp;aknas</translation>
    </message>
    <message>
        <source>Open in New &amp;Tab</source>
        <translation>Ava uues &amp;sakis</translation>
    </message>
    <message>
        <source>Save Lin&amp;k</source>
        <translation>Salvesta &amp;viit</translation>
    </message>
    <message>
        <source>&amp;Bookmark This Link</source>
        <translation>Lisa viit &amp;järjehoidjaks</translation>
    </message>
    <message>
        <source>&amp;Copy Link Location</source>
        <translation>&amp;Kopeeri viidatav aadress</translation>
    </message>
    <message>
        <source>Open Image in New &amp;Window</source>
        <translation>Ava pilt uues &amp;aknas</translation>
    </message>
    <message>
        <source>Open Image in New &amp;Tab</source>
        <translation>Ava pilt uues &amp;sakis</translation>
    </message>
    <message>
        <source>&amp;Save Image</source>
        <translation>Salvesta &amp;pilt</translation>
    </message>
    <message>
        <source>&amp;Copy Image</source>
        <translation>&amp;Kopeeri pilt</translation>
    </message>
    <message>
        <source>C&amp;opy Image Location</source>
        <translation>K&amp;opeeri pildi aadress</translation>
    </message>
    <message>
        <source>Loading...</source>
        <translation>Laadimine...</translation>
    </message>
</context>
<context>
    <name>WebViewSearch</name>
    <message>
        <source>Not Found</source>
        <translation>Ei leitud</translation>
    </message>
</context>
</TS>
