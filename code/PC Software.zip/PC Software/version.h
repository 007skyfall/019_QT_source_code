
#define APPLICATION "AN1310"
#define VERSION     "1.05r"
