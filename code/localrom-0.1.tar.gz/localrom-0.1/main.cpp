 
#include <QApplication>
#include "mywindow.h"

int main( int argc, char *argv[])
{
	Q_INIT_RESOURCE(resource);

	QApplication app( argc, argv);

	//���ط����ļ�
	QTranslator translator;
	translator.load(":/data/zh_CN");
	app.installTranslator(&translator);
	
	MyWindow mywindow;
	mywindow.show();

	return app.exec();
}
