<!DOCTYPE TS><TS>
<context>
    <name>MyWindow</name>
    <message>
        <source>Please input your nickname</source>
        <translation>请输入您在聊天室的昵称：</translation>
    </message>
    <message>
        <source>&amp;Log on</source>
        <translation>登录(&amp;L)</translation>
    </message>
    <message>
        <source>&amp;Exit</source>
        <translation>退出(&amp;E)</translation>
    </message>
    <message>
        <source>About</source>
        <translation>关于局域网聊天室 0.1 版</translation>
    </message>
    <message>
        <source>About application</source>
        <translation>局域网聊天室 0.1 版
    献给我亲爱的老婆
<byte value="x9"/>莫非 倾情制作
<byte value="x9"/>06年4月20日</translation>
    </message>
    <message>
        <source>yyyy-MM-dd  hh:mm:ss</source>
        <translation>  yyyy-MM-dd hh:mm:ss</translation>
    </message>
    <message>
        <source>  say:
<byte value="x9"/></source>
        <translation>  说道:
<byte value="x9"/></translation>
    </message>
    <message>
        <source> ]  System information 
<byte value="x9"/></source>
        <translation>    ] 系统温馨提示
<byte value="x9"/></translation>
    </message>
    <message>
        <source>localqq</source>
        <translation>局域网聊天室 0.1版</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation>发送(&amp;S)</translation>
    </message>
    <message>
        <source>&amp;About</source>
        <translation>关于(&amp;A)</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>退出(&amp;Q)</translation>
    </message>
    <message>
        <source>come1</source>
        <translation> 说道：给诸位爷请安了，小的人称永兴一中之玉面小白龙，初来乍到，还望诸位多关照关照！</translation>
    </message>
    <message>
        <source>come2</source>
        <translation> 说道：大伯大婶们，大哥大姐们，小弟小妹们，俺是玉面小狗剩啊，还记得俺不？</translation>
    </message>
    <message>
        <source>come3</source>
        <translation> 说道：小生 玉面小青虫 这厢有礼了，见过各位粗男俏女：）</translation>
    </message>
    <message>
        <source>come4</source>
        <translation> 说道：我是玉面小蛤蟆，人称永兴奇侠一直霉，有谁不服的今夜子时来操场单挑，不见不散，不死不休！</translation>
    </message>
    <message>
        <source>come5</source>
        <translation> 说道：玉面小狐狸通知，这周六不补课，学校组织高一年纪组老师春游，具体事宜详见6月15号的潇湘晚报：（</translation>
    </message>
    <message>
        <source>come6</source>
        <translation> 说道：我是谁，活着，还是死去，这是个问题！</translation>
    </message>
    <message>
        <source>leave1</source>
        <translation>说道：我有事先走一步，各位继续！</translation>
    </message>
    <message>
        <source>leave2</source>
        <translation>悻悻的走了！</translation>
    </message>
    <message>
        <source>leave3</source>
        <translation>若有所思的离去了！</translation>
    </message>
    <message>
        <source>leave4</source>
        <translation>回家给他们家那口子做饭去了，悲哀啊！</translation>
    </message>
    <message>
        <source>leave5</source>
        <translation>去WC小蹲一会，你们谁去把门锁上，憋坏他：）</translation>
    </message>
    <message>
        <source>leave6</source>
        <translation> 说道：嘿，我得去找玉面小蛤蟆单挑了，几位明天等我的好消息！</translation>
    </message>
</context>
</TS>
