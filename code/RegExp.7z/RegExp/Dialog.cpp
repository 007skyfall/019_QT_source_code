#include "Dialog.h"
#include "ui_Dialog.h"

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::on_pushButton_clicked()
{
    ui->textEdit_2->clear();
    int pos = 0;
    QRegExp exp(ui->lineEdit->text());
    exp.setMinimal(ui->checkBox->isChecked());
    while((pos=exp.indexIn(ui->textEdit->toPlainText(), pos)) != -1){
        pos += exp.matchedLength();
        for(int i=0; i<=exp.captureCount(); i++)
            ui->textEdit_2->append(QString::number(i) + ": " + exp.cap(i));
    }
}
