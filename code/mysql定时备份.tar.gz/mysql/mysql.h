#ifndef MYSQL_H
#define MYSQL_H
#include <QApplication>
#include <QSystemTrayIcon>
#include <QDesktopWidget>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include <QCloseEvent>
#include <QMessageBox>
#include <QGridLayout>
#include <QHBoxLayout>
#include <QSpacerItem>
#include <QPushButton>
#include <QTextEdit>
#include <QAction>
#include <QProcess>
#include <QPalette>
#include <QMenu>
#include <QTime>
#include <QTimer>
#include "ConDialog.h"
class MainClass : public QWidget
{
    Q_OBJECT
	signals:
		void isCurrentTime();
    public:
	MainClass(QWidget *parent = 0);
    private slots:
	void Config();
    	void Exit();
	void AboutSlot();
	void Quitactions();
	void Mini();
	void StopRun();
	void ComToCur();
	void LoadFile();
	void IconActivated(QSystemTrayIcon::ActivationReason Reason);
    protected:
    	void hideEvent(QHideEvent *event);
    	void closeEvent(QCloseEvent *event);
    private:
	QPushButton 	*Configure;
	QPushButton 	*Run;
	QPushButton 	*Stop;
	QPushButton 	*Quit;
	QPushButton 	*About;
	QTextEdit 	*Announcement;
	QGridLayout 	*MainLayout;
	QVBoxLayout 	*MainRig;
	QVBoxLayout	*MainLeft;
	QHBoxLayout 	*MainTop;
	QHBoxLayout 	*MainBottom;
	QSpacerItem 	*Hspacer;
	QSpacerItem 	*Vspacer;
	QAction 	*ReConfig;
	QAction 	*Restore;
	QAction 	*Rehide;
	QAction 	*QuitAction;
	QMenu 		*TrayMenu;
	QTimer  	*RTimer;
	QSystemTrayIcon *TrayIcon;
	QString 	Serverip;
	QString 	UserName;
	QString 	PassWord;
	QString 	DataName;
	QString 	BackTime;
	QString 	BackPath;
	QString 	ReturnStr(const QString &Str);
	QSqlDatabase 	*db; 
	QSqlQuery  	query;
	QSqlError 	err;
	DialogClass 	*ConDialog;
	void Init();
	void Conn();
	void Layout();
	void TrayIcons();
	void SqlBack();
};
#endif
