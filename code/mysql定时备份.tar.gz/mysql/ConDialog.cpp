#include "ConDialog.h"
DialogClass::DialogClass(QWidget *parent):QWidget(parent)
{
    ConInit();
    ConLayout();
    Conn();
};

void DialogClass::ConInit()
{
    Local = new QLabel(tr("Server:"));
    User = new QLabel(tr("UserName:"));
    Pass = new QLabel(tr("PassWorld:"));
    Data = new QLabel(tr("DataName:"));
    BackTime = new QLabel(tr("BackTime:"));
    QBack = new QLabel(tr("BackPath:"));

    LocalSql = new QLineEdit;
    UserSql = new QLineEdit;
    PassSql = new QLineEdit;
    Dataname = createComboBox();
    Backtime = new QTimeEdit;
    Backtime->setDisplayFormat("hh:mm:ss");
    BackPath = createComboBox(QDir::currentPath());
    BrowseButton = createbutton(tr("..."),SLOT(browse()));
    BrowseButton->setFixedWidth(20);

    ConnSql = new QPushButton(tr("&Connect")); 
    Submit = new QPushButton(tr("&Save"));
    Submit->setEnabled(false);
    Cancel = new QPushButton(tr("&Cancel"));
    Cancel->setEnabled(false);
    LoadFile();
    if(LocalSql->text().isEmpty() | UserSql->text().isEmpty() | PassSql->text().isEmpty())
    {
    Data->hide();
    BackTime->hide();
    QBack->hide();
    Dataname->hide();
    Backtime->hide();
    BackPath->hide();
    BrowseButton->hide();
    }
    else
    {
    Data->show();
    BackTime->show();
    QBack->show();
    Dataname->show();
    Backtime->show();
    BackPath->show();
    BrowseButton->show();
    Submit->setEnabled(true);
    }

    MainLayout = new QGridLayout;
    MainLeft = new QGridLayout;
    MainRight = new QVBoxLayout;
    TwoButton = new QHBoxLayout;
};

void DialogClass::ConLayout()
{
    MainRight->addWidget(ConnSql,Qt::AlignTop);
    MainRight->addWidget(Submit);
    MainRight->addWidget(Cancel);
    MainRight->addStretch();

    MainLeft->addWidget(Local,0,0);
    MainLeft->addWidget(User,1,0);
    MainLeft->addWidget(Pass,2,0);
    MainLeft->addWidget(Data,3,0);
    MainLeft->addWidget(BackTime,5,0);
    MainLeft->addWidget(QBack,4,0);
    MainLeft->addWidget(LocalSql,0,1);
    MainLeft->addWidget(UserSql,1,1);
    MainLeft->addWidget(PassSql,2,1);
    MainLeft->addWidget(Dataname,3,1);
    MainLeft->addWidget(Backtime,5,1);
    TwoButton->addWidget(BackPath);
    TwoButton->addWidget(BrowseButton);
    MainLeft->addLayout(TwoButton,4,1);

    MainLayout->addLayout(MainLeft,0,0);
    MainLayout->addLayout(MainRight,0,2);

    setLayout(MainLayout);
    setWindowIcon(QIcon("IMG/tray.png"));
    setWindowTitle(tr("Backup Setting"));
    setWindowFlags(Qt::WindowStaysOnTopHint);
    setWindowModality(Qt::ApplicationModal);
    QDesktopWidget *desktop = QApplication::desktop();
    move((desktop->width()-this->width())/2,(desktop->height()-this->height())/2);
};

void DialogClass::Conn()
{
    connect(ConnSql,SIGNAL(clicked()),this,SLOT(Sqlcheck()));
    connect(Submit,SIGNAL(clicked()),this,SLOT(SaveInfo()));
    connect(Submit,SIGNAL(clicked()),this,SLOT(CheckMini()));
    connect(Cancel,SIGNAL(clicked()),this,SLOT(CancelHand()));
};

void DialogClass::Sqlcheck()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName(LocalSql->text());
    db.setUserName(UserSql->text());
    db.setPassword(PassSql->text());
    bool ok = db.open();
    if(ok)
    {
    Data->show();
    BackTime->show();
    QBack->show();
    Dataname->show();
    Backtime->show();
    BackPath->show();
    BrowseButton->show();
    Submit->setEnabled(true);
    Cancel->setEnabled(true);
    query = QSqlQuery(db);
    bool r = query.exec("show databases;");
    if(r)
    {
	Dataname->clear();
	while(query.next())
	{
	    Dataname->addItem(query.value(0).toString());
	}
    }
    else
    {
	err = query.lastError();
	QString str = err.text();
	QMessageBox::information(0,"Information",str);
	qDebug() << "Error:" << query.lastError();
    }
    if(query.exec("select version();"))
    {
	while(query.next())
	{
	    version = query.value(0).toString();
	}
    }
    db.close(); 
    }
    else
    {
	err = db.lastError();
	QString str = err.text();
	QMessageBox::warning(this,tr("Con't Connect SQL:"),str);
	qDebug() << "Error:" << db.lastError();
    }
};

void DialogClass::CancelHand()
{
    LocalSql->clear();
    UserSql->clear();
    PassSql->clear();
    Dataname->clear();
    Backtime->setTime(QTime(0,0,0));
    BackPath->setCurrentIndex(BackPath->currentIndex()-1);
};

void DialogClass::closeEvent(QCloseEvent *event)
{
    if(this->isVisible())
    {
	hide();
	event->ignore();
    }
};

void DialogClass::browse()
{
    QString directort = QFileDialog::getExistingDirectory(this,tr("Path"),QDir::currentPath());
    if(!directort.isEmpty())
    {
	BackPath->addItem(directort);
	BackPath->setCurrentIndex(BackPath->currentIndex()+1);
    }
};

void DialogClass::SaveInfo()
{
    if(isRun == 1)
    {
	QMessageBox::warning(this,tr("Error:"),tr("Service is Runing!\nPlease Stop Service!"));
    }
   else
    {
    QFile savefile("./info.ini");
    if(!savefile.open(QIODevice::WriteOnly | QIODevice::Text))
    {
	QMessageBox::information(0,"Information:","Save Error!");
    }
    else
    {
	    QString Localtext = "Serverip = ";
            QString Usertext = "UserName = ";
	    QString Passtext = "PassWord = ";
	    QString Datatext = "DataName = ";
	    QString BTtext = "BackTime = ";
	    QString BPtext = "BackPath = ";
	    QString Version = "Versions = ";
	    QTextStream SaveStream(&savefile);
         	QStringList ConfigInfo;
           	ConfigInfo << Localtext.append(LocalSql->text()) << Usertext.append(UserSql->text()) << Passtext.append(PassSql->text()) << Datatext.append(QString(Dataname->currentText())) << BTtext.append(Backtime->time().toString()) << BPtext.append(QString(BackPath->currentText())) << Version.append(version);
        	for (QStringList::Iterator conut = ConfigInfo.begin (); conut != ConfigInfo.end (); ++conut)
            SaveStream << *conut << "\n";
	    SaveStream.atEnd();
	    savefile.close();
        }
    hide();
    }
};

QString DialogClass::ReturnStr(const QString &Str)
{
    QString Sec;
    QStringList Ret;
    Sec = Str.section("=",1,1);
    Ret = Sec.split(" ",QString::SkipEmptyParts);
    if(!Ret.isEmpty())
    {
        return QString(Ret[0]);
    }
    else
    {
	return QString("");
    }
};

QTime DialogClass::ReturnTim(const QString &Str)
{
    QString Timestring;
    QStringList X;
    Timestring = Str.section("=", 1, 1);
    X = Timestring.split(":");
    if(!X.isEmpty())
    {
    return QTime(X[0].toInt(),X[1].toInt(),X[2].toInt());
    }
    else
    {
	return QTime();
    }
};

QComboBox *DialogClass::createComboBox(const QString &text)
{
    QComboBox *combobox = new QComboBox;
    combobox->setEditable(true);
    combobox->addItem(text);
    combobox->setSizePolicy(QSizePolicy::Expanding,QSizePolicy::Preferred);
    return combobox;
};

QPushButton *DialogClass::createbutton(const QString &text, const char *member)
{
    QPushButton *button = new QPushButton(text);
    connect(button,SIGNAL(clicked()),this,member);
    return button;
};

void DialogClass::LoadFile()
{
    QFile loadfile("./info.ini");
    if(loadfile.open(QIODevice::ReadOnly | QIODevice::Text))
    {
	QTextStream LoadStream(&loadfile);
	QString LoadInfo;
	while(!LoadStream.atEnd())
	{
	    LoadInfo = LoadStream.readLine();
	    if(LoadInfo.contains("Serverip"))
	    {
		LocalSql->setText(ReturnStr(LoadInfo));
	    }
	    if(LoadInfo.contains("UserName"))
	    {
		UserSql->setText(ReturnStr(LoadInfo));
	    }
	    if(LoadInfo.contains("PassWord"))
	    {
		PassSql->setText(ReturnStr(LoadInfo));
	    }
	    if(LoadInfo.contains("DataName"))
	    {
		Dataname->clear();
		Dataname->addItem(ReturnStr(LoadInfo));
	    }
	    if(LoadInfo.contains("BackTime"))
	    {
		Backtime->setTime(ReturnTim(LoadInfo));
	    }
	    if(LoadInfo.contains("BackPath"))
	    {
		BackPath->clear();
		BackPath->addItem(ReturnStr(LoadInfo));
	    }
	}
	loadfile.close();
    }
};

void DialogClass::CheckMini()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QMYSQL");
    db.setHostName(LocalSql->text());
    db.setUserName(UserSql->text());
    db.setPassword(PassSql->text());
    bool ok = db.open();
    if(!ok)
    {
	err = db.lastError();
	QString str = err.text();
	QMessageBox::warning(this,tr("Con't Connect SQL:"),str);
    }
};

void DialogClass::setValue(const int Run)
{
    isRun = Run;
};
