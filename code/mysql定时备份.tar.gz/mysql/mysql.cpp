#include "mysql.h"
MainClass::MainClass(QWidget *parent):QWidget(parent)
{
    Init();
    Layout();
    TrayIcons();
    Conn();
};

void MainClass::Init()
{
    Configure = new QPushButton(tr("&Configure"));
    Run = new QPushButton(tr("&Run"));
    Stop = new QPushButton(tr("&Stop"));
    Stop->hide();
    Quit = new QPushButton(tr("&Quit"));
    About = new QPushButton(tr("&About"));
    Announcement = new QTextEdit;
    Announcement->setReadOnly(true);
    MainTop = new QHBoxLayout;
    MainBottom = new QHBoxLayout;
    MainLayout = new QGridLayout;
    RTimer = new QTimer;
    ConDialog = new DialogClass;
};

void MainClass::Conn()
{
    connect(Configure,SIGNAL(clicked()),this,SLOT(Config()));

    connect(Quit,SIGNAL(clicked()),this,SLOT(Exit()));

    connect(About,SIGNAL(clicked()),this,SLOT(AboutSlot()));

    connect(TrayIcon,SIGNAL(activated(QSystemTrayIcon::ActivationReason)),this,SLOT(IconActivated(QSystemTrayIcon::ActivationReason)));

    connect(ReConfig,SIGNAL(triggered()),this,SLOT(Config()));

    connect(Restore,SIGNAL(triggered()),this,SLOT(show()));

    connect(Rehide,SIGNAL(triggered()),this,SLOT(hide()));

    connect(QuitAction,SIGNAL(triggered()),this,SLOT(Exit()));

    connect(Run,SIGNAL(clicked()),this,SLOT(Mini()));

    connect(Run,SIGNAL(clicked()),this,SLOT(LoadFile()));

    connect(Stop,SIGNAL(clicked()),this,SLOT(StopRun()));

    connect(RTimer,SIGNAL(timeout()),this,SLOT(ComToCur()));
};

void MainClass::Layout()
{
    MainTop->addWidget(Announcement);

    MainBottom->addWidget(Configure);
    MainBottom->addWidget(Run);
    MainBottom->addWidget(Stop);
    MainBottom->addWidget(Quit);
    MainBottom->addWidget(About);

    MainLayout->addLayout(MainTop,0,0);
    MainLayout->addLayout(MainBottom,1,0);

    setLayout(MainLayout);

    setWindowIcon(QIcon("./IMG/tray.png"));
    setWindowTitle(tr("Data Backup"));
    setFixedSize(QSize(550,256));
    QDesktopWidget* desktop = QApplication::desktop(); 
    move((desktop->width()-this->width())/2,(desktop->height()-this->height())/2);
};

void MainClass::closeEvent(QCloseEvent *event)
{
    if(TrayIcon->isVisible())
    {
	hide();
	event->ignore();
    }
};

void MainClass::hideEvent(QHideEvent *event)
{
    if (TrayIcon->isVisible()) 
    {
        hide();
        event->ignore();
    }
};

void MainClass::Config()
{
    ConDialog->show();
};

void MainClass::Exit()
{
    exit(0);
};

void MainClass::AboutSlot()
{
    QMessageBox::about(this,tr("About"),QString::fromLocal8Bit("This program is written by Johan! \nE-Mail:johaness@qq.com \nBlog:http://www.sky6.cn"));
};

void MainClass::TrayIcons()
{
   ReConfig = new QAction(tr("&Config"),this);
   Restore = new QAction(tr("&Show"),this);
   Rehide = new QAction(tr("&Hide"),this);
   QuitAction = new QAction(tr("Quit"),this);
   TrayMenu = new QMenu;
   TrayMenu->addAction(ReConfig);
   TrayMenu->addAction(Restore);
   TrayMenu->addAction(Rehide);
   TrayMenu->addSeparator();
   TrayMenu->addAction(QuitAction);
   TrayIcon = new QSystemTrayIcon(this);
   TrayIcon->setContextMenu(TrayMenu);
   TrayIcon->setIcon(QIcon("./IMG/tray.png"));
   TrayIcon->show();
};

void MainClass::IconActivated(QSystemTrayIcon::ActivationReason Reason)
{
    switch(Reason)
    {
	case QSystemTrayIcon::DoubleClick:
	    setVisible(isHidden());
	    break;
	default:
	    ;
    }
};

void MainClass::Quitactions()
{
    int r=QMessageBox::warning(this,tr("NetSharer"),QString::fromLocal8Bit("Service is running!\nYou sure to quit?"),QMessageBox::Yes|QMessageBox::Cancel,QMessageBox::Cancel);
    if (r==QMessageBox::Yes)
    {
        Exit();
    }
};

void MainClass::Mini()
{
    Run->hide();
    Stop->show();
    RTimer->start(1000);
    hide();
    ConDialog->setValue(1);
};

void MainClass::StopRun()
{
    Run->show();
    Stop->hide();
    RTimer->stop();
    ConDialog->setValue(0);
};

void MainClass::ComToCur()
{
    if(QVariant(QTime::currentTime()).toString() == QVariant(BackTime))
    {
	SqlBack();
    }
};

void MainClass::LoadFile()
{
    QFile loadfile("./info.ini");
    if(loadfile.open(QIODevice::ReadOnly | QIODevice::Text))
    {
	QTextStream LoadStream(&loadfile);
	QString LoadInfo;
	while(!LoadStream.atEnd())
	{
	    LoadInfo = LoadStream.readLine();
	    if(LoadInfo.contains("Serverip"))
	    {
		Serverip = ReturnStr(LoadInfo);
	    }
	    if(LoadInfo.contains("UserName"))
	    {
		UserName = ReturnStr(LoadInfo);
	    }
	    if(LoadInfo.contains("PassWord"))
	    {
		PassWord = ReturnStr(LoadInfo);
	    }
	    if(LoadInfo.contains("DataName"))
	    {
		DataName = ReturnStr(LoadInfo);
	    }
	    if(LoadInfo.contains("BackTime"))
	    {
		BackTime = ReturnStr(LoadInfo);
		qDebug() << "GrabTime;" << BackTime;
	    }
	    if(LoadInfo.contains("BackPath"))
	    {
		BackPath = ReturnStr(LoadInfo);
	    }
	}
	loadfile.close();
    }
};

QString MainClass::ReturnStr(const QString &Str)
{
    QString Sec;
    QStringList Ret;
    Sec = Str.section("=",1,1);
    Ret = Sec.split(" ",QString::SkipEmptyParts);
    return QString(Ret[0]);
};

void MainClass::SqlBack()
{
    QString Cmd = QString("mysqldump -u%1 -p%2 -h%3 %4").arg(UserName,PassWord,Serverip,DataName);
    QString Path = QString("%4/%5.Sql").arg(BackPath,QDateTime::currentDateTime().toString());
    QProcess *poc=new QProcess;
    poc->setStandardOutputFile(Path);
    poc->start(Cmd);
};
