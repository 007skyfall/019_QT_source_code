#include "mysql.h"
#include "ConDialog.h"
int main(int argc, char **argv)
{
    QApplication app(argc,argv);
    MainClass Main;
    Main.show();
    return app.exec();
}
