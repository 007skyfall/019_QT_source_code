#ifndef CONDIALOG_H
#define CONDIALOG_H
#include <QApplication>
#include <QDesktopWidget>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include <QCloseEvent>
#include <QMessageBox>
#include <QGridLayout>
#include <QHBoxLayout>
#include <QVBoxLayout>
#include <QPushButton>
#include <QComboBox>
#include <QFileDialog>
#include <QLineEdit>
#include <QTimeEdit>
#include <QTextStream>
#include <QLabel>
#include <QDebug>
#include <QFile>
#include <QDir>
class DialogClass : public QWidget
{
    Q_OBJECT
    public:
	DialogClass(QWidget *parent = 0);
	void setValue(int);
    protected:
    	void closeEvent(QCloseEvent *event);
    private slots:
	void Sqlcheck();
	void CancelHand();
	void browse();
	void SaveInfo();
	void CheckMini();
    private:
	QLabel 		*Local;
	QLabel 		*User;
	QLabel 		*Pass;
	QLabel 		*Data;
	QLabel 		*BackTime;
	QLabel 		*QBack;
	QLineEdit 	*LocalSql;
	QLineEdit 	*UserSql;
	QLineEdit 	*PassSql;
	QTimeEdit 	*Backtime;
	QComboBox 	*createComboBox(const QString &text = QString());
	QComboBox 	*Dataname;
	QComboBox 	*BackPath;
	QPushButton 	*createbutton(const QString &text, const char *member);
	QPushButton 	*BrowseButton;
	QPushButton 	*ConnSql;
	QPushButton 	*Submit;
	QPushButton 	*Cancel;
	QGridLayout  	*MainLayout;
	QGridLayout 	*MainLeft;
	QVBoxLayout 	*MainRight;
	QHBoxLayout 	*TwoButton;
	QSqlDatabase 	*db; 
	QSqlQuery  	query;
	QSqlError 	err;
	QString  	version;
	QString 	ReturnStr(const QString &Str);
	QTime		ReturnTim(const QString &Str);
	int		isRun;
	void ConInit();
	void ConLayout();
	void Conn();
	void LoadFile();
	};
#endif
