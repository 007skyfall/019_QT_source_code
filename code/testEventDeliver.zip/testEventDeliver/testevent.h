/*!
	@author zengxy
	@date 2013-02-26
*/

#ifndef TESTEVENT_H
#define TESTEVENT_H

#include "widgetbase.h"

class SomeWidget : public WidgetBase
{
	Q_OBJECT
public:
	SomeWidget(WidgetBase* pParent = NULL);
	virtual ~SomeWidget(){}

public slots:
	void on_clicked();
};

class TestFilterWidget : public WidgetBase
{
public:
	TestFilterWidget(WidgetBase* pParent = NULL);
	virtual ~TestFilterWidget(){}

	void handleEvent(class Event* pEvent);
};

class TestEventTop : public WidgetBase
{
public:
	TestEventTop(WidgetBase* pParent = NULL);
	virtual ~TestEventTop(){}

	void handleEvent(class Event* pEvent);
};


#endif // TESTEVENT_H
