/*!
	@author zengxy
	@date 2013-02-26
*/

#include <QtGui/QApplication>
#include "testevent.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
//	TestFilterWidget *widget = new TestFilterWidget;
//	widget->show();
	TestEventTop *topWidget = new TestEventTop;
	topWidget->setGeometry(20, 20, 200, 200);
	topWidget->show();
    return a.exec();
}
