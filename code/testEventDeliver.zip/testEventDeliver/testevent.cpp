/*!
	@author zengxy
	@date 2013-02-26
*/

#include "testevent.h"
#include "event.h"
#include <QDebug>
#include <QPushButton>

SomeWidget::SomeWidget(WidgetBase* pParent)
	: WidgetBase(pParent)
{
	QPushButton *pBtn = new QPushButton(this);
	pBtn->setText("TEST!");
	connect(pBtn, SIGNAL(clicked()), SLOT(on_clicked()));
}



void SomeWidget::on_clicked()
{
	static bool ifOpen = false;
	Event *event;
	if(!ifOpen)
	{
		event = new Event(1);
		ifOpen = true;
	}
	else
	{
		event = new Event(2);
		ifOpen = false;
	}

	sendEvent(event);
}

TestFilterWidget::TestFilterWidget(WidgetBase* pParent)
	: WidgetBase(pParent)
{
	new SomeWidget(this);
}

void TestFilterWidget::handleEvent(class Event* pEvent)
{
	if(NULL != pEvent)
	{
		int eventId = pEvent->getEventId();
		qDebug() << eventId;
		if(1 == eventId)
		{
			qDebug() << "eventId -- 1";
		}
		else
		{
			WidgetBase::handleEvent(pEvent);
		}
	}
}

TestEventTop::TestEventTop(WidgetBase* pParent)
	: WidgetBase(pParent)
{
	new TestFilterWidget(this);
}

void TestEventTop::handleEvent(class Event* pEvent)
{
	if(NULL != pEvent)
	{
		int eventId = pEvent->getEventId();
		qDebug() << eventId;
		if(2 == eventId)
		{
			qDebug() << "eventId -- 2";
		}
		else
		{
			WidgetBase::handleEvent(pEvent);
		}
	}
}


