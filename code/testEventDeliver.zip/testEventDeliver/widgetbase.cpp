/*!
	@author zengxy
	@date 2013-02-26
*/

#include "widgetbase.h"

WidgetBase::WidgetBase(WidgetBase *pDeliver)
	: QWidget(pDeliver)
	, m_pWidget(pDeliver)
{

}

void WidgetBase::setEventHandler(WidgetBase *pHandler)
{
	m_pWidget = pHandler;
}

void WidgetBase::sendEvent(class Event* pEvent)
{
	handleEvent(pEvent);
}

void WidgetBase::handleEvent(class Event* pEvent)
{
	if(NULL != m_pWidget)
	{
		m_pWidget->handleEvent(pEvent);
	}
}
