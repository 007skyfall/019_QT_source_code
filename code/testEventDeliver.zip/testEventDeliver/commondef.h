/*!
	@author zengxy
	@date 2013-02-26
*/

#ifndef COMMONDEF_H
#define COMMONDEF_H

#include "eventdeliver.h"
#include <QWidget>

EventDeliver *getEventDeliver(QWidget *pParent)
{
	return new EventDeliver();
}

#endif // COMMONDEF_H
