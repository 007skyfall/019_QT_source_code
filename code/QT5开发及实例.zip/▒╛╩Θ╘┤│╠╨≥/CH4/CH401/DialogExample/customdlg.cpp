#include "customdlg.h"

CustomDlg::CustomDlg(QWidget *parent) :
    QDialog(parent)
{
}
