#ifndef CUSTOMDLG_H
#define CUSTOMDLG_H

#include <QDialog>

class CustomDlg : public QDialog
{
    Q_OBJECT
public:
    explicit CustomDlg(QWidget *parent = 0);
    
signals:
    
public slots:
    
};

#endif // CUSTOMDLG_H
