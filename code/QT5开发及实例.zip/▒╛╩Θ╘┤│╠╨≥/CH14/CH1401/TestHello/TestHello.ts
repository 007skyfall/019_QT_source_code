<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="zh_CN">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="14"/>
        <source>MainWindow</source>
        <translation>主窗口</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="27"/>
        <source>hello</source>
        <translation>你好</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="40"/>
        <source>china</source>
        <translation>中国</translation>
    </message>
</context>
</TS>
