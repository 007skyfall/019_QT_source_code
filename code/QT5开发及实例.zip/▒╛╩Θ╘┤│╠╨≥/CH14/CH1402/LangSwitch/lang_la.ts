<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="zh">
<context>
    <name>LangSwitch</name>
    <message>
        <location filename="langswitch.cpp" line="38"/>
        <source>TXT_HELLO_WORLD</source>
        <comment>Hello World</comment>
        <translation>Orbis,te saluto</translation>
    </message>
</context>
</TS>
