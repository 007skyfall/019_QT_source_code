/****************************************************************************
** Meta object code from reading C++ file 'myword.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.0.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../MyselfWord/myword.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'myword.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.0.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_MyWord_t {
    QByteArrayData data[36];
    char stringdata[324];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    offsetof(qt_meta_stringdata_MyWord_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData) \
    )
static const qt_meta_stringdata_MyWord_t qt_meta_stringdata_MyWord = {
    {
QT_MOC_LITERAL(0, 0, 6),
QT_MOC_LITERAL(1, 7, 7),
QT_MOC_LITERAL(2, 15, 0),
QT_MOC_LITERAL(3, 16, 8),
QT_MOC_LITERAL(4, 25, 8),
QT_MOC_LITERAL(5, 34, 10),
QT_MOC_LITERAL(6, 45, 9),
QT_MOC_LITERAL(7, 55, 16),
QT_MOC_LITERAL(8, 72, 12),
QT_MOC_LITERAL(9, 85, 9),
QT_MOC_LITERAL(10, 95, 4),
QT_MOC_LITERAL(11, 100, 4),
QT_MOC_LITERAL(12, 105, 3),
QT_MOC_LITERAL(13, 109, 4),
QT_MOC_LITERAL(14, 114, 5),
QT_MOC_LITERAL(15, 120, 5),
QT_MOC_LITERAL(16, 126, 8),
QT_MOC_LITERAL(17, 135, 10),
QT_MOC_LITERAL(18, 146, 13),
QT_MOC_LITERAL(19, 160, 9),
QT_MOC_LITERAL(20, 170, 8),
QT_MOC_LITERAL(21, 179, 1),
QT_MOC_LITERAL(22, 181, 9),
QT_MOC_LITERAL(23, 191, 10),
QT_MOC_LITERAL(24, 202, 10),
QT_MOC_LITERAL(25, 213, 1),
QT_MOC_LITERAL(26, 215, 8),
QT_MOC_LITERAL(27, 224, 1),
QT_MOC_LITERAL(28, 226, 9),
QT_MOC_LITERAL(29, 236, 11),
QT_MOC_LITERAL(30, 248, 16),
QT_MOC_LITERAL(31, 265, 13),
QT_MOC_LITERAL(32, 279, 8),
QT_MOC_LITERAL(33, 288, 18),
QT_MOC_LITERAL(34, 307, 8),
QT_MOC_LITERAL(35, 316, 6)
    },
    "MyWord\0fileNew\0\0fileOpen\0fileSave\0"
    "fileSaveAs\0filePrint\0filePrintPreview\0"
    "printPreview\0QPrinter*\0undo\0redo\0cut\0"
    "copy\0paste\0about\0textBold\0textItalic\0"
    "textUnderline\0textAlign\0QAction*\0a\0"
    "textStyle\0styleIndex\0textFamily\0f\0"
    "textSize\0p\0textColor\0updateMenus\0"
    "updateWindowMenu\0createMyChild\0MyChild*\0"
    "setActiveSubWindow\0QWidget*\0window\0"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MyWord[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      25,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  139,    2, 0x08,
       3,    0,  140,    2, 0x08,
       4,    0,  141,    2, 0x08,
       5,    0,  142,    2, 0x08,
       6,    0,  143,    2, 0x08,
       7,    0,  144,    2, 0x08,
       8,    1,  145,    2, 0x08,
      10,    0,  148,    2, 0x08,
      11,    0,  149,    2, 0x08,
      12,    0,  150,    2, 0x08,
      13,    0,  151,    2, 0x08,
      14,    0,  152,    2, 0x08,
      15,    0,  153,    2, 0x08,
      16,    0,  154,    2, 0x08,
      17,    0,  155,    2, 0x08,
      18,    0,  156,    2, 0x08,
      19,    1,  157,    2, 0x08,
      22,    1,  160,    2, 0x08,
      24,    1,  163,    2, 0x08,
      26,    1,  166,    2, 0x08,
      28,    0,  169,    2, 0x08,
      29,    0,  170,    2, 0x08,
      30,    0,  171,    2, 0x08,
      31,    0,  172,    2, 0x08,
      33,    1,  173,    2, 0x08,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 9,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 20,   21,
    QMetaType::Void, QMetaType::Int,   23,
    QMetaType::Void, QMetaType::QString,   25,
    QMetaType::Void, QMetaType::QString,   27,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    0x80000000 | 32,
    QMetaType::Void, 0x80000000 | 34,   35,

       0        // eod
};

void MyWord::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MyWord *_t = static_cast<MyWord *>(_o);
        switch (_id) {
        case 0: _t->fileNew(); break;
        case 1: _t->fileOpen(); break;
        case 2: _t->fileSave(); break;
        case 3: _t->fileSaveAs(); break;
        case 4: _t->filePrint(); break;
        case 5: _t->filePrintPreview(); break;
        case 6: _t->printPreview((*reinterpret_cast< QPrinter*(*)>(_a[1]))); break;
        case 7: _t->undo(); break;
        case 8: _t->redo(); break;
        case 9: _t->cut(); break;
        case 10: _t->copy(); break;
        case 11: _t->paste(); break;
        case 12: _t->about(); break;
        case 13: _t->textBold(); break;
        case 14: _t->textItalic(); break;
        case 15: _t->textUnderline(); break;
        case 16: _t->textAlign((*reinterpret_cast< QAction*(*)>(_a[1]))); break;
        case 17: _t->textStyle((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 18: _t->textFamily((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 19: _t->textSize((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 20: _t->textColor(); break;
        case 21: _t->updateMenus(); break;
        case 22: _t->updateWindowMenu(); break;
        case 23: { MyChild* _r = _t->createMyChild();
            if (_a[0]) *reinterpret_cast< MyChild**>(_a[0]) = _r; }  break;
        case 24: _t->setActiveSubWindow((*reinterpret_cast< QWidget*(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 24:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QWidget* >(); break;
            }
            break;
        }
    }
}

const QMetaObject MyWord::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MyWord.data,
      qt_meta_data_MyWord,  qt_static_metacall, 0, 0}
};


const QMetaObject *MyWord::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MyWord::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MyWord.stringdata))
        return static_cast<void*>(const_cast< MyWord*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MyWord::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 25)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 25;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 25)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 25;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
