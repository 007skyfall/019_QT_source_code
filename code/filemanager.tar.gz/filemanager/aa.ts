<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>QFileSystemModel</name>
    <message>
        <location filename="qfilesystemmodel.cpp" line="744"/>
        <source>%1 TB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qfilesystemmodel.cpp" line="746"/>
        <source>%1 GB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qfilesystemmodel.cpp" line="748"/>
        <source>%1 MB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qfilesystemmodel.cpp" line="750"/>
        <source>%1 KB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qfilesystemmodel.cpp" line="751"/>
        <source>%1 bytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qfilesystemmodel.cpp" line="828"/>
        <source>Invalid filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qfilesystemmodel.cpp" line="829"/>
        <source>&lt;b&gt;The name &quot;%1&quot; can not be used.&lt;/b&gt;&lt;p&gt;Try using another name, with fewer characters or no punctuations marks.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qfilesystemmodel.cpp" line="893"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qfilesystemmodel.cpp" line="895"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qfilesystemmodel.cpp" line="899"/>
        <source>Kind</source>
        <comment>Match OS X Finder</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qfilesystemmodel.cpp" line="901"/>
        <source>Type</source>
        <comment>All other platforms</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="qfilesystemmodel.cpp" line="908"/>
        <source>Date Modified</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
