<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="zh_CN">
<context>
    <name>QFileDialog</name>
    <message>
        <location filename="qfileiconprovider.cpp" line="461"/>
        <source>Drive</source>
        <translation type="unfinished">磁盘</translation>
    </message>
    <message>
        <location filename="qfileiconprovider.cpp" line="464"/>
        <location filename="qfileiconprovider.cpp" line="465"/>
        <source>File</source>
        <translation type="unfinished">文件</translation>
    </message>
    <message>
        <location filename="qfileiconprovider.cpp" line="470"/>
        <source>File Folder</source>
        <comment>Match Windows Explorer</comment>
        <translation type="unfinished">文件目录</translation>
    </message>
    <message>
        <location filename="qfileiconprovider.cpp" line="472"/>
        <source>Folder</source>
        <comment>All other platforms</comment>
        <translation type="unfinished">文件夹</translation>
    </message>
    <message>
        <location filename="qfileiconprovider.cpp" line="481"/>
        <source>Alias</source>
        <comment>Mac OS X Finder</comment>
        <translation type="unfinished">别名</translation>
    </message>
    <message>
        <location filename="qfileiconprovider.cpp" line="483"/>
        <source>Shortcut</source>
        <comment>All other platforms</comment>
        <translation type="unfinished">快捷方式</translation>
    </message>
    <message>
        <location filename="qfileiconprovider.cpp" line="490"/>
        <source>Unknown</source>
        <translation type="unfinished">未知</translation>
    </message>
</context>
</TS>
