<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="zh_CN">
<context>
    <name>QApplication</name>
    <message>
        <source>Folder</source>
        <comment>All other platforms</comment>
        <translation type="obsolete">文件夹</translation>
    </message>
</context>
<context>
    <name>QFileDialog</name>
    <message>
        <source>Folder</source>
        <comment>All other platforms</comment>
        <translation type="obsolete">文件夹</translation>
    </message>
</context>
<context>
    <name>QFileSystemModel</name>
    <message>
        <source>Folder</source>
        <comment>All other platforms</comment>
        <translation type="obsolete">文件夹</translation>
    </message>
</context>
<context>
    <name>QTreeView</name>
    <message>
        <source>Folder</source>
        <comment>All other platforms</comment>
        <translation type="obsolete">文件夹</translation>
    </message>
</context>
<context>
    <name>QWidget</name>
    <message>
        <source>Folder</source>
        <comment>All other platforms</comment>
        <translation type="obsolete">文件夹</translation>
    </message>
</context>
<context>
    <name>fileview</name>
    <message>
        <location filename="fileview.ui" line="14"/>
        <source>Widget</source>
        <translation type="unfinished">窗口</translation>
    </message>
    <message>
        <location filename="fileview.ui" line="197"/>
        <location filename="fileview.ui" line="204"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="fileview.ui" line="217"/>
        <source>关闭</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fileview.cpp" line="17"/>
        <source>open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fileview.cpp" line="18"/>
        <source>å¤å¶æä»¶</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fileview.cpp" line="19"/>
        <source>ç²è´´å°è¿é</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fileview.cpp" line="20"/>
        <source>å é¤æä»¶</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fileview.cpp" line="66"/>
        <source>æµè¯</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
