#ifndef MYBUTTON_H
#define MYBUTTON_H
#include<QPushButton>

//!支持3种状态的图片按纽
class QMyButton : public QPushButton
{
public:
	QMyButton(QWidget *parent);
	~QMyButton();
	//!设置正常图片
	void SetPicture(QString sFilename);
	//!设置按下图片
	void SetDownPicture(QString sFilename);
	//!设置鼠标移入图片
	void SetMovePicture(QString sFilename);
	//!设置按纽位置
	void SetPos(int x,int y);
	
	//!正常图片
	QPixmap m_pixmap;
	//!按下图片
	QPixmap m_pixmap_down;
	//!移动图片
	QPixmap m_pixmap_move;
	
private:
protected:
	void paintEvent(QPaintEvent * event);
};
#endif

