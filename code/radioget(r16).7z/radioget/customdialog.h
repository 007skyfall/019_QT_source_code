#ifndef CUSTOMDIALOG_H
#define CUSTOMDIALOG_H

#include <QtGui/QDialog>

namespace Ui {
    class CustomDialog;
}

class CustomDialog : public QDialog {
    Q_OBJECT
    Q_DISABLE_COPY(CustomDialog)
public:
    explicit CustomDialog(QWidget *parent = 0);
    virtual ~CustomDialog();

protected:
    virtual void changeEvent(QEvent *e);

private:
    Ui::CustomDialog *m_ui;

private slots:
void on_buttonBox_rejected();
		void on_buttonBox_accepted();
};

#endif // CUSTOMDIALOG_H
