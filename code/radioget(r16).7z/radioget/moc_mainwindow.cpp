/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created: Sun Dec 20 16:06:17 2009
**      by: The Qt Meta Object Compiler version 61 (Qt 4.5.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "mainwindow.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 61
#error "This file was generated using the moc from 4.5.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MainWindow[] = {

 // content:
       2,       // revision
       0,       // classname
       0,    0, // classinfo
      14,   12, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors

 // slots: signature, parameters, type, tag, flags
      12,   11,   11,   11, 0x08,
      34,   11,   11,   11, 0x08,
      55,   11,   11,   11, 0x08,
      82,   76,   11,   11, 0x08,
     129,  120,   11,   11, 0x08,
     166,   11,   11,   11, 0x08,
     195,   11,   11,   11, 0x08,
     226,   11,   11,   11, 0x08,
     248,   11,   11,   11, 0x08,
     284,  272,   11,   11, 0x08,
     339,  332,   11,   11, 0x08,
     392,   11,   11,   11, 0x08,
     429,   11,   11,   11, 0x08,
     471,  465,   11,   11, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_MainWindow[] = {
    "MainWindow\0\0on_btnPause_clicked()\0"
    "on_btnStop_clicked()\0on_btnPlay_clicked()\0"
    "value\0on_horizontalSlider_valueChanged(int)\0"
    "position\0on_horizontalSlider_sliderMoved(int)\0"
    "on_action_Custom_triggered()\0"
    "on_action_RadioGet_triggered()\0"
    "on_action_triggered()\0on_pushButton_clicked()\0"
    "item,column\0on_treeWidget_itemClicked(QTreeWidgetItem*,int)\0"
    "reason\0on_tray_activated(QSystemTrayIcon::ActivationReason)\0"
    "on_mplayer_readyReadStandardOutput()\0"
    "on_mplayer_readyReadStandardError()\0"
    "error\0on_radiolist_done(bool)\0"
};

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow,
      qt_meta_data_MainWindow, 0 }
};

const QMetaObject *MainWindow::metaObject() const
{
    return &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: on_btnPause_clicked(); break;
        case 1: on_btnStop_clicked(); break;
        case 2: on_btnPlay_clicked(); break;
        case 3: on_horizontalSlider_valueChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: on_horizontalSlider_sliderMoved((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: on_action_Custom_triggered(); break;
        case 6: on_action_RadioGet_triggered(); break;
        case 7: on_action_triggered(); break;
        case 8: on_pushButton_clicked(); break;
        case 9: on_treeWidget_itemClicked((*reinterpret_cast< QTreeWidgetItem*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2]))); break;
        case 10: on_tray_activated((*reinterpret_cast< QSystemTrayIcon::ActivationReason(*)>(_a[1]))); break;
        case 11: on_mplayer_readyReadStandardOutput(); break;
        case 12: on_mplayer_readyReadStandardError(); break;
        case 13: on_radiolist_done((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 14;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
