#ifndef ABOUTWIDGET_H
#define ABOUTWIDGET_H

#include <QTabWidget>

namespace Ui {
    class AboutWidget;
}

class AboutWidget : public QTabWidget {
    Q_OBJECT
public:
    AboutWidget(QWidget *parent = 0);
    ~AboutWidget();

protected:
    void changeEvent(QEvent *e);

private:
    Ui::AboutWidget *ui;
};

#endif // ABOUTWIDGET_H
