#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QtGui/QMainWindow>
#include <QDomDocument>
#include <QTreeWidgetItem>
#include <QProcess>
#include <QSystemTrayIcon>
#include <QHttp>
#include "aboutwidget.h"

namespace Ui
{
	class MainWindowClass;
}

class MainWindow : public QMainWindow
{
	Q_OBJECT

public:
	MainWindow(QWidget *parent = 0);
	~MainWindow();

	bool ReadXml();
	bool UpdateTree();
	void PlayUrl(QString& strUrl);
	void setVisible(bool visible);

private:
	void createActions();
	Ui::MainWindowClass *ui;
	QDomDocument m_domDocument;
	QMap<QString,QString> m_map;
	QProcess* m_pProcess;
	QSystemTrayIcon *m_pTray;
	QHttp m_http;
	QByteArray m_baRadioData;
	QString m_strCurrentUrl;
	QAction *playAction;
	QAction *pauseAction;
	QAction *stopAction;
	QAction *minimizeAction;
	QAction *maximizeAction;
	QAction *restoreAction;
	QAction *quitAction;
	QMenu *trayIconMenu;
	AboutWidget *aw;

private slots:
	void on_btnPause_clicked();
	void on_btnStop_clicked();
	void on_btnPlay_clicked();
	void on_horizontalSlider_valueChanged(int value);
	void on_horizontalSlider_sliderMoved(int position);
	void on_action_Custom_triggered();
	void on_action_RadioGet_triggered();
	void on_action_triggered();
	void on_pushButton_clicked();
	void on_treeWidget_itemClicked(QTreeWidgetItem* item, int column);
	void on_tray_activated(QSystemTrayIcon::ActivationReason reason);
	void on_mplayer_readyReadStandardOutput();
	void on_mplayer_readyReadStandardError();
	void on_radiolist_done(bool error);
};

#endif // MAINWINDOW_H
