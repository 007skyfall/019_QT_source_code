#include <QPainter>
#include <QPaintEvent>
#include "qmybutton.h"
#include <QtGui>

QMyButton::QMyButton(QWidget *parent=0)
	:QPushButton(parent)
{
}

QMyButton::~QMyButton()
{

}

void QMyButton::SetPos(int x,int y)
{
	this->setGeometry(x,y,m_pixmap.width(),m_pixmap.height());
}

void QMyButton::SetPicture(QString sFilename)
{
	m_pixmap=QPixmap(sFilename);
}

void QMyButton::SetDownPicture(QString sFilename)
{
	m_pixmap_down=QPixmap(sFilename);
}

void QMyButton::SetMovePicture(QString sFilename)
{
	m_pixmap_move=QPixmap(sFilename);
}

void QMyButton::paintEvent(QPaintEvent * event)
{
	//QPushButton::paintEvent(event);

	event->setAccepted(true);
	QPainter painter(this);

	if(isDown())
		painter.drawPixmap(0,0,m_pixmap_down);
	else if(underMouse())
		painter.drawPixmap(0,0,m_pixmap_move);
	else painter.drawPixmap(0,0,m_pixmap);
}

