<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="zh_CN">
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.ui" line="14"/>
        <source>MainWindow</source>
        <translation>应用程序主窗口</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="27"/>
        <source>PushButton</source>
        <translation>按钮</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="42"/>
        <source>&amp;File</source>
        <translation>文件(&amp;F)</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="59"/>
        <source>&amp;New</source>
        <translation>新建(&amp;N)</translation>
    </message>
    <message>
        <location filename="mainwindow.ui" line="62"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="10"/>
        <source>hello Qt!</source>
        <translation>你好 Qt！</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="13"/>
        <source>password</source>
        <comment>mainwindow</comment>
        <translation>密码</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="18"/>
        <source>ID is %1,Name is %2</source>
        <translation>账号是%1，名字是%2</translation>
    </message>
</context>
</TS>
