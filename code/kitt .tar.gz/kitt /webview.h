#ifndef WEBVIEW_H
#define WEBVIEW_H
#include <QtWebKit/QWebView>
class WebView : public QWebView
{
public:
    WebView();
private:
    QWebView * createWindow ( QWebPage::WebWindowType);

};


#endif // WEBVIEW_H
