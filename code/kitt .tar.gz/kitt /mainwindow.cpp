#include "mainwindow.h"
#include "webview.h"
#include <QtGui/QtGui>
#include <QtWebKit/QWebView>
#include <QtWebKit/QWebPage>
#include <QtWebKit/QWebHistory>

MainWindow::MainWindow()
{
    webView = new WebView;
    webView->load(QUrl("http://www.google.com"));
    webPage = webView->page();
    webHistory = webPage->history();
    
    urlAddr = new QLineEdit;
    statusLabel = new QLabel;
    progressBar = new QProgressBar;
    
    createActions();
    createMenus();
    createToolBars();
    createCentralWidget();
    createStatusBar();
 
    connect(urlAddr, SIGNAL(returnPressed()), this, SLOT(loadUrlAddr()));
	connect(webView, SIGNAL(urlChanged(const QUrl &)), this, SLOT(displayUrlAddr(const QUrl &)));
	connect(webView, SIGNAL(titleChanged(const QString &)), this, SLOT(showTitle(const QString &)));
    connect(webView, SIGNAL(statusBarMessage(const QString &)),statusLabel, SLOT(setText(const QString &)));
    
    connect(webView, SIGNAL(loadStarted()), this, SLOT(webLoadStarted()));
    connect(webView, SIGNAL(loadProgress(int)), this, SLOT(webLoadProgress(int)));
    connect(webView, SIGNAL(loadFinished(bool)), this, SLOT(webLoadFinished(bool)));
}
void MainWindow::createActions()
{
    exitAction = new QAction(tr("E&xit"),this);
    exitAction->setShortcut(tr("Ctrl+X"));
    connect(exitAction, SIGNAL(triggered()), qApp, SLOT(quit()));
    
    lockToolBarACtion = new QAction(tr("&LockToolBar"),this);
    lockToolBarACtion->setCheckable(true);
    connect(lockToolBarACtion, SIGNAL(toggled(bool)),this, SLOT(toolBarMovable(bool)));
    
    aboutAction = new QAction(tr("&AboutQt"),this); 
    connect(aboutAction, SIGNAL(triggered()), qApp, SLOT(aboutQt())); 
    
    backAction = new QAction(tr("&Back"),this);
    backAction->setIcon(QIcon(":/images/back.png"));
    backAction->setStatusTip(tr("Back"));
    backAction->setEnabled(false);
    connect(backAction, SIGNAL(triggered()), webView, SLOT(back()));
    
    forwardAction = new QAction(tr("&Forwar"),this);
    forwardAction->setIcon(QIcon(":/images/forward.png"));
    forwardAction->setStatusTip(tr("Forward"));
    forwardAction->setEnabled(false);
    connect(forwardAction, SIGNAL(triggered()), webView, SLOT(forward()));
    
    reloadAction = new QAction(tr("&Reload"),this);
    reloadAction->setIcon(QIcon(":/images/reload.png"));
    reloadAction->setStatusTip(tr("Reload"));
    connect(reloadAction, SIGNAL(triggered()), webView, SLOT(reload()));
    
    stopAction = new QAction(tr("&Stop"),this);
    stopAction->setIcon(QIcon(":/images/stop.png"));
    stopAction->setStatusTip(tr("Stop"));
    stopAction->setEnabled(false);
    connect(stopAction, SIGNAL(triggered()), webView, SLOT(stop()));
}
void MainWindow::createMenus()
{
    fileMenu = menuBar()->addMenu(tr("&File"));
    fileMenu->addAction(exitAction);
    
    viewMenu = menuBar()->addMenu(tr("&View"));
    viewMenu->addAction(lockToolBarACtion);
    
    helpMenu = menuBar()->addMenu(tr("&Help"));
    helpMenu->addAction(aboutAction);
    
}

void MainWindow::createToolBars()
{
    
    navToolBar = addToolBar(tr("Navigation"));
    navToolBar->addAction(backAction);
    navToolBar->addAction(forwardAction);
    navToolBar->addAction(reloadAction);
    navToolBar->addAction(stopAction);
    navToolBar->addWidget(urlAddr);
}

void MainWindow::createCentralWidget()
{

	setCentralWidget(webView);   
}
void MainWindow::createStatusBar()
{

    statusBar()->addWidget(statusLabel);
    statusBar()->addWidget(progressBar);
    progressBar->setMaximumWidth(100);
    progressBar->hide();
}

void MainWindow::loadUrlAddr()
{
    QString url = urlAddr->text();
    if (url.left(5) != "http:" && url.left(5) != "file:")
        url.prepend("http://");
    webView->load(QUrl(url));
}

void MainWindow::displayUrlAddr(const QUrl &url)
{
    
    urlAddr->setText(url.toString());
    if (webHistory->canGoBack())
        backAction->setEnabled(true);
    else 
        backAction->setEnabled(false);
        
    if (webHistory->canGoForward())
        forwardAction->setEnabled(true);
    else 
        forwardAction->setEnabled(false);
}

void MainWindow::showTitle(const QString &title)
{
    this->setWindowTitle(title);
}
void MainWindow::toolBarMovable(bool move)
{
    navToolBar->setMovable(!move);
}
void MainWindow::webLoadStarted()
{
    stopAction->setEnabled(true);
}
void MainWindow::webLoadFinished(bool ok)
{
    if (ok)
        stopAction->setEnabled(false);
}
void MainWindow::webLoadProgress(int progress)
{
    progressBar->show();
    statusLabel->setText(tr("loading  "));
    progressBar->setValue(progress);
    if (100 == progress)
    {
        progressBar->hide();
        statusLabel->setText(tr("load finished"));
    }
}
    

