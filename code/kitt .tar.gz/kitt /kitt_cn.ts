<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="zh_CN">
<defaultcodec></defaultcodec>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="mainwindow.cpp" line="37"/>
        <source>&amp;LockToolBar</source>
        <translation type="unfinished">锁定工具条</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="41"/>
        <source>&amp;AboutQt</source>
        <translation type="unfinished">关于Qt</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="44"/>
        <source>&amp;Back</source>
        <translation type="unfinished">后退</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="46"/>
        <source>Back</source>
        <translation type="unfinished">后退</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="50"/>
        <source>&amp;Forwar</source>
        <translation type="unfinished">前进</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="52"/>
        <source>Forward</source>
        <translation type="unfinished">前进</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="56"/>
        <source>&amp;Reload</source>
        <translation type="unfinished">刷新</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="58"/>
        <source>Reload</source>
        <translation type="unfinished">刷新</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="61"/>
        <source>&amp;Stop</source>
        <translation type="unfinished">停止</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="63"/>
        <source>Stop</source>
        <translation type="unfinished">停止</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="69"/>
        <source>&amp;File</source>
        <translation type="unfinished">文件</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="72"/>
        <source>&amp;View</source>
        <translation type="unfinished">查看</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="75"/>
        <source>&amp;Help</source>
        <translation type="unfinished">帮助</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="83"/>
        <source>Navigation</source>
        <translation type="unfinished">导航工具栏</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="33"/>
        <source>E&amp;xit</source>
        <translation type="unfinished">退出</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="34"/>
        <source>Ctrl+X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="140"/>
        <source>loading  </source>
        <translation type="unfinished">载入</translation>
    </message>
    <message>
        <location filename="mainwindow.cpp" line="142"/>
        <source>load finished</source>
        <translation type="unfinished">完成</translation>
    </message>
</context>
</TS>
