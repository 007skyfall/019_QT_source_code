#include "mainwindow.h"
#include "webview.h"
WebView::WebView()
{
}
QWebView *WebView::createWindow ( QWebPage::WebWindowType type)
{
    Q_UNUSED(type);
    MainWindow *newMainwindow = new MainWindow;
    newMainwindow->showMaximized();
    return newMainwindow->webView;
}
