#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <Qt/qmainwindow.h>
#include <Qt/qurl.h>


class QAction;
class QLineEdit;
class QLabel;
class WebView;
class QWebPage;
class QWebHistory;
class QProgressBar;

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    MainWindow();
    WebView *webView;
private:
    void createActions();
    void createMenus();
    void createToolBars();
    void createCentralWidget();
    void createStatusBar();
    
    QLineEdit *urlAddr;

    QWebPage *webPage;
    QWebHistory * webHistory;
    
    QAction *openAction;
    QAction *exitAction;
    QAction *lockToolBarACtion;
    QAction *aboutAction;
    QAction *backAction;
    QAction *forwardAction;
    QAction *reloadAction;
    QAction *stopAction;
    
    
    QMenu *fileMenu;
    QMenu *viewMenu;
    QMenu *helpMenu;   
    QToolBar *navToolBar;
    QLabel *statusLabel;
    QProgressBar *progressBar;
    
private slots:
    void loadUrlAddr();
    void displayUrlAddr(const QUrl &);
    void showTitle(const QString &);
    void toolBarMovable(bool);
    void webLoadStarted();
    void webLoadFinished(bool);
    void webLoadProgress(int);
}; 
#endif
