#include "mainwindow.h"
#include <QtGui/QtGui>

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    QTranslator translator;
    translator.load(":/kitt_cn");
    app.installTranslator(&translator);

    MainWindow *mainwindow = new MainWindow; 
    mainwindow->showMaximized();
	return app.exec();
}
