/*******************************************************
 **
 ** Provided by ���ɽ�, Fuzhou University
 ** Email: mileden@126.com
 ** Homepage: http://sonew.512j.com/
 ** This product is free for use.
 ** last changed 2009-2-14
 **
 *******************************************************/

#include "vmsmainwindow.h"
#include "videocaptureview.h"
#include "camerasettings.h"
#include "thumbbutton.h"
#include "xvidencode.h"

static const int thmarg=2;

VMSMainWindow::VMSMainWindow(QWidget *parent, Qt::WFlags flags)
    : QMainWindow(parent, flags)
{
    ui.setupUi(this);
    isViewingPhoto = false;
    mp4Buffer = 0;
    encoder = 0;
    videoFile = 0;
    isVideoRecording = false;
    storagePath = "./";
    settings = new CameraSettings( this );

    QWidget *cameraWidget = new QWidget(this);
    camera = new Ui::CameraBase();
    camera->setupUi(cameraWidget);
    setCentralWidget(cameraWidget);

    thumb[0] = camera->thumb1;
    thumb[1] = camera->thumb2;
    thumb[2] = camera->thumb3;
    thumb[3] = camera->thumb4;
    thumb[4] = camera->thumb5;
    cur_thumb = -1;

    QSignalMapper* sm = new QSignalMapper(this);
    for (int i=0; i<nthumb; i++) {
        sm->setMapping(thumb[i],i);
        connect(thumb[i],SIGNAL(clicked()),sm,SLOT(map()));
        thumb[i]->installEventFilter(this);
    }
    connect(sm,SIGNAL(mapped(int)),this,SLOT(thumbClicked(int)));

    init();

    connect( camera->photo, SIGNAL( clicked() ),
             this, SLOT( on_actionTake_Photo_triggered() ) );
    connect( camera->video, SIGNAL( clicked() ),
             this, SLOT( toggleVideo() ) );

    setWindowTitle( tr( "Video Monitor System" ) );
}

VMSMainWindow::~VMSMainWindow()
{

}

void VMSMainWindow::init()
{
    photo_size = camera->videocaptureview->photoSizes();
    pquality = settings->photo_quality->value();
    for ( psize = 0; psize < (int)photo_size.count()-1; ++psize );
    settings->photo_size->clear();
    for (int i=0; i<(int)photo_size.count(); i++) {
        QString s = QString("%1 x %2").arg(photo_size[i].width())
                    .arg(photo_size[i].height());
        settings->photo_size->addItem( s );
    }

    ui.actionStop_Recording->setEnabled( false );
    if ( camera->videocaptureview->available() ) {
        camera->video->setEnabled( false );
    } else {
        // ui.action_Options->setEnabled( false );
        ui.actionTake_Photo->setEnabled( false );
        camera->photo->setEnabled( false );
        camera->video->setEnabled( false );
        ui.actionStart_Recording->setEnabled( false );
    }

    camera->photo->setFocus();
}

void VMSMainWindow::resizeEvent(QResizeEvent*)
{
    thumbw = width()/5-4;
    thumbh = thumbw*3/4;
    qDebug() << "thumb width: " << thumbw << "\t thumb height: " << thumbh;
    camera->thumbs->setFixedHeight(thumbh+thmarg*2);

    loadThumbs();
}

bool VMSMainWindow::event(QEvent* e)
{
    /*
    if ( e->type() == QEvent::WindowActivate ) {
        if ( cur_thumb < 0 ) {
            toggleVideo();
        }
    } else if ( e->type() == QEvent::WindowDeactivate ) {
        camera->videocaptureview->setLive(-1);
    }
    */
    return QMainWindow::event(e);
}

void VMSMainWindow::toggleVideo()
{
    if ( camera->videocaptureview->available() ) {
        isViewingPhoto = false;
        camera->video->setEnabled( false );
        camera->photo->setEnabled( true );
        camera->videocaptureview->setLive();
    }
}

void VMSMainWindow::loadThumbs()
{
    QDir dir( storagePath, "*.jpg", QDir::Time );
    QStringList fileNameList = dir.entryList();
    qDebug() << "picture numbers: " << fileNameList.size();

    for ( int i = 0; i < nthumb; ++i) {
        QString file = storagePath;
        QPixmap pm;

        if (i < fileNameList.size() ) {
            file.append( fileNameList.at(i) );
            picturefile[i] = file;
            QImage img( file );
            pm = QPixmap::fromImage(img.scaled(QSize( thumbw, thumbh ),
                       Qt::KeepAspectRatio, Qt::SmoothTransformation));
        }

        thumb[i]->setIcon( pm );
        thumb[i]->setEnabled( !pm.isNull() );
    }

    if ( isViewingPhoto ) {
        if ( cur_thumb < fileNameList.size() )
            selectThumb(cur_thumb);
        else
            selectThumb( fileNameList.size() - 1 );
    }

    ui.action_Delete->setVisible( fileNameList.size() > 0 );
}

void VMSMainWindow::selectThumb(int i)
{
    isViewingPhoto = true;
    cur_thumb = i;
    if ( i >= 0 ) {
        QImage img( picturefile[i] );
        camera->videocaptureview->setStill(img);
        thumb[i]->setFocus();
        camera->photo->setEnabled( false );
        if ( camera->videocaptureview->available() )
            camera->video->setEnabled( true );
    } else {
        toggleVideo();
    }
}

void VMSMainWindow::delThumb(int th)
{
    QString file = picturefile[th];
    file.replace(storagePath, "" );
    switch(QMessageBox::warning(0, tr("Confirmation"),
            tr("<qt>Delete '%1'?</qt>", "%1 = file name").arg( file ),
            QMessageBox::Yes,
            QMessageBox::No))
    {
        case QMessageBox::Yes:
            QFile::remove( picturefile[th] );
            loadThumbs();

            // Rhys Hack - if we have just deleted the last image and there
            // is no camera connected, then exit the application.  This
            // avoids a focus problem where it is impossible to exit with
            // the back button due to the focus being in a stupid place.
            if ( !camera->videocaptureview->available() &&
                 !(thumb[0]->isEnabled()) ) {
                close();
            }
            break;
        default:
            //nothing
            break;
    }
}

void VMSMainWindow::pushThumb(const QString file, const QImage& img)
{
    for (int i=nthumb; --i; ) {
        bool en = thumb[i-1]->isEnabled();
        thumb[i]->setEnabled(en);
        QIcon icon = thumb[i-1]->icon();
        if ( en && !icon.isNull() ) {
            thumb[i]->setIcon(icon);
            picturefile[i] = picturefile[i-1];
        } else {
            thumb[i]->setText("");
        }
    }
    thumb[0]->setIcon(QPixmap::fromImage(img.scaled(
            QSize( thumbw, thumbh ), Qt::KeepAspectRatio, Qt::SmoothTransformation)));
    thumb[0]->setEnabled(true);
    picturefile[0] = file;

    // updateAction();
    ui.action_Delete->setVisible( true );
}

void VMSMainWindow::on_action_Exit_triggered()
{
    qApp->quit();
}

void VMSMainWindow::on_action_Open_triggered()
{
    QString file = QFileDialog::getOpenFileName( this, tr("Open File"),
                                                 storagePath,
                                                 tr("MPEG (*.m4v)") );
    camera->videocaptureview->setCaptureSource( file );
    toggleVideo();
    init();
}

void VMSMainWindow::thumbClicked(int i)
{
    selectThumb(i);
    qDebug() << "thumb " << i << " clicked.";
}

void VMSMainWindow::on_action_About_triggered()
{
    QMessageBox::about( this, tr( "About Video Monitor System" ),
                        tr( "<p><b>Video Monitor System</b></p><p></p>"
                            "<p>Version 0.0.3 (2009-2-14)</p><p></p>"
                            "<p>Provided by Songjian Su (mileden@126.com)</p><p></p>"
                            "<p>For more infomation, please visit</p>"
                            "<p><a href = http://sonew.512j.com>http://sonew.512j.com</a></p>" ) );
}

void VMSMainWindow::on_action_Options_triggered()
{
    settings->show();

    settings->photo_size->setCurrentIndex( psize );
    settings->photo_quality->setValue( pquality );

    if ( settings->exec() ) {
        storagePath = settings->getStoragePath();
        storagePath.append( "/" );
        psize = settings->photo_size->currentIndex();
        pquality = settings->photo_quality->value();

        qDebug() << "storage path" << storagePath;
        qDebug() << "psize: " << psize;
        qDebug() << "pquality: " << pquality;

        loadThumbs();
    }
}

void VMSMainWindow::on_actionTake_Photo_triggered()
{
    QSize size = photo_size[psize];
    if ( size == camera->videocaptureview->captureSize() ) {
        // We can grab the current image immediately.
        takePhotoNow();
    }
}

void VMSMainWindow::on_action_Delete_triggered()
{
    if ( cur_thumb >= 0 ) {
        delThumb(cur_thumb);
    }
}

void VMSMainWindow::on_actionStart_Recording_triggered()
{
    if ( isVideoRecording )
        return;

    if ( camera->videocaptureview->available() ) {
        QString videoFileName = storagePath;
        videoFileName.append( QDateTime::currentDateTime().toString("yyMMddhhmmsszzz") );
        videoFileName.append( ".m4v" );
        videoFile = new QFile( videoFileName );
        if ( !videoFile->open( QIODevice::WriteOnly ) )
            return;

        QSize size = camera->videocaptureview->captureSize();
        int w = size.width();
        int h = size.height();
        encoder = new XvidEncode( w, h);
        if ( !encoder->hasEncoder() )
            return;
        mp4Buffer = new unsigned char[w*h*8];

        ui.actionStart_Recording->setEnabled( false );
        ui.actionStop_Recording->setEnabled( true );

        connect( camera->videocaptureview, SIGNAL( frameChanged() ),
                 this, SLOT( recordFrame() ) );

        isVideoRecording = true;
    }
}

void VMSMainWindow::on_actionStop_Recording_triggered()
{
    if ( isVideoRecording ) {
        delete []mp4Buffer;
        mp4Buffer = 0;
        delete encoder;
        encoder = 0;
        videoFile->close();
        delete videoFile;
        videoFile = 0;
        ui.actionStart_Recording->setEnabled( true );
        ui.actionStop_Recording->setEnabled( false );
        isVideoRecording = false;
        disconnect( camera->videocaptureview, SIGNAL( frameChanged() ),
                 this, SLOT( recordFrame() ) );
    }
}

void VMSMainWindow::recordFrame()
{
    QImage img = camera->videocaptureview->image();
    qint64 m4vsize = encoder->encode( img.bits(), mp4Buffer );
    do {
        qint64 size = videoFile->write( (const char*)mp4Buffer, m4vsize );
        m4vsize -= size;
    } while ( m4vsize>0 );
}

void VMSMainWindow::takePhotoNow()
{
    /* set the filename to the current date and time,
     * such as "081231195001222.jpg" for "Dec 31, 2008. 19:50:01.222".
     */
    QString file = storagePath;
    file.append( QDateTime::currentDateTime().toString("yyMMddhhmmsszzz") );
    file.append( ".jpg" );
    QImage img = camera->videocaptureview->image();
    img.save( file, "JPEG", pquality );

    pushThumb( file, img );
}

void ThumbButton::paintEvent( QPaintEvent* )
{
    // copy from 'qtoolbutton.cpp'
    QStylePainter p(this);
    QStyleOptionToolButton opt;
    initStyleOption(&opt);
    p.drawComplexControl(QStyle::CC_ToolButton, opt);

    // QPainter p(this);
    QIcon ic = icon();
    if ( !ic.isNull() ) {
        ic.paint( &p, rect() );
    }
}

ThumbButton::ThumbButton( QWidget *parent ) : QToolButton(parent)
{
}
