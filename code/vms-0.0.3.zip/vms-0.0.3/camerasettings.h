/*******************************************************
 **
 ** Provided by ���ɽ�, Fuzhou University
 ** Email: mileden@126.com
 ** Homepage: http://sonew.512j.com/
 ** This product is free for use.
 ** last changed 2009-1-7
 **
 *******************************************************/

#ifndef CAMERASETTINGS_H
#define CAMERASETTINGS_H

#include <QtGui>

class CameraSettings : public QDialog
{
    Q_OBJECT

public:
    CameraSettings(QWidget* parent = 0, Qt::WindowFlags f = 0);
    ~CameraSettings();
    QString getStoragePath() const;

    friend class VMSMainWindow;

private slots:
    void setStoragePath();

private:
    void setupUi();

    QLineEdit* storagePath;
    QToolButton* browseButton;
    QComboBox *photo_size;
    QSlider *photo_quality;
};

#endif // CAMERASETTINGS_H
