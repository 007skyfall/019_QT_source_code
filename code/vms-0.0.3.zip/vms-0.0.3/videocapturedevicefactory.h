/*******************************************************
 **
 ** Provided by ���ɽ�, Fuzhou University
 ** Email: mileden@126.com
 ** Homepage: http://sonew.512j.com/
 ** This product is free for use.
 ** last changed 2009-1-7
 **
 *******************************************************/

// source code from: Qtopia-opensource-4.2.4

#ifndef VIDEOCAPTUREDEVICEFACTORY_H
#define VIDEOCAPTUREDEVICEFACTORY_H

#include <QString>

namespace camera
{

class VideoCaptureDevice;

class VideoCaptureDeviceFactory
{
public:

    static VideoCaptureDevice* createVideoCaptureDevice(const QString file = 0);
};

}   // ns camera

#endif // VIDEOCAPTUREDEVICEFACTORY_H
