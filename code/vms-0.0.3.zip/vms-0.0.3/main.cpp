/*******************************************************
 **
 ** Provided by ���ɽ�, Fuzhou University
 ** Email: mileden@126.com
 ** Homepage: http://sonew.512j.com/
 ** This product is free for use.
 ** last changed 2009-1-7
 **
 *******************************************************/

#include <QtGui/QApplication>
#include "vmsmainwindow.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    VMSMainWindow w;
    w.show();
    return a.exec();
}
