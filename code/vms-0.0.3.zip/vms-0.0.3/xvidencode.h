/*******************************************************
 **
 ** Provided by ���ɽ�, Fuzhou University
 ** Email: mileden@126.com
 ** Homepage: http://sonew.512j.com/
 ** This product is free for use.
 ** last changed 2009-2-14
 **
 *******************************************************/

#ifndef XVIDENCODE_H
#define XVIDENCODE_H

class XvidEncode
{
public:
    XvidEncode(int w, int h);
    ~XvidEncode();
    bool hasEncoder() const { return encoderAvailable; }
    int encode(unsigned char* image, unsigned char* bitstream);

private:
    int enc_init();
    int enc_stop();

    int width;
    int height;
    bool encoderAvailable;
    void* enc_handle;
};

#endif // XVIDENCODE_H
