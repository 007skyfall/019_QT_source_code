/*******************************************************
 **
 ** Provided by ���ɽ�, Fuzhou University
 ** Email: mileden@126.com
 ** Homepage: http://sonew.512j.com/
 ** This product is free for use.
 ** last changed 2009-2-14
 **
 *******************************************************/

// source code from: Qtopia-opensource-4.2.4

#ifndef VIDEOCAPTUREVIEW_H
#define VIDEOCAPTUREVIEW_H

#include <QWidget>
#include <QImage>
#include <QList>


namespace camera
{
class VideoCaptureDevice;
}


class VideoCaptureView : public QWidget
{
    Q_OBJECT

public:
    VideoCaptureView(QWidget *parent = 0, Qt::WFlags fl = 0);
    ~VideoCaptureView();

    void setCaptureSource(const QString source);

    bool available() const;

    QImage image() const { return m_image; }
    void setLive(int period = 0);
    void setStill(const QImage&);

    QList<QSize> photoSizes() const;
    QList<QSize> videoSizes() const;

    QSize recommendedPhotoSize() const;
    QSize recommendedVideoSize() const;
    QSize recommendedPreviewSize() const;

    QSize captureSize() const;
    void setCaptureSize( QSize size );

    uint refocusDelay() const;

signals:
    void frameChanged();

protected:
    void moveEvent(QMoveEvent* moveEvent);
    void resizeEvent(QResizeEvent* resizeEvent);
    void paintEvent(QPaintEvent* paintEvent);
    void timerEvent(QTimerEvent* timerEvent);

private:
    bool                m_cleared;
    int                 m_tidUpdate;
    QImage              m_image;
    camera::VideoCaptureDevice  *m_capture;
};

#endif // VIDEOCAPTUREVIEW_H
