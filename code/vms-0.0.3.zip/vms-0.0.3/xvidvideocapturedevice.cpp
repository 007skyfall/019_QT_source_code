/*******************************************************
 **
 ** Provided by ���ɽ�, Fuzhou University
 ** Email: mileden@126.com
 ** Homepage: http://sonew.512j.com/
 ** This product is free for use.
 ** last changed 2009-2-14
 **
 *******************************************************/

#include <QtGui>

#include "xvidvideocapturedevice.h"

#define BUFFER_SIZE (2*1024*1024)
#define MIN_USEFUL_BYTES 1

namespace camera
{

bool XvidVideoCaptureDevice::hasCamera() const
{
    return decoderAvailable;
}

QSize XvidVideoCaptureDevice::captureSize() const
{
    return QSize(width, height);
}

uint XvidVideoCaptureDevice::refocusDelay() const
{
    return 250;
}

int XvidVideoCaptureDevice::minimumFramePeriod() const
{
    return 40; // milliseconds
}

XvidVideoCaptureDevice::XvidVideoCaptureDevice(const QString fileName)
{
    width = height = 0;
    dec_handle = 0;
    decodeBuffer = 0;
    mp4_buffer = 0;
    decoderAvailable = false;
    done = false;

    file = new QFile(fileName);
    qDebug() << fileName;

    setupCamera( QSize(0, 0) );
}

XvidVideoCaptureDevice::~XvidVideoCaptureDevice()
{
    shutdown();
}

void XvidVideoCaptureDevice::setupCamera(QSize size)
{
    size = size;
    xvid_dec_stats_t xvid_dec_stats;

    if (!file->open(QIODevice::ReadOnly))
        return;
    if (file->atEnd()) {
        done = true;
        return;
    }
    qDebug() << "file open OK";

    if (dec_init())
        return;

    mp4_buffer = new unsigned char[BUFFER_SIZE];
    /* Fill the buffer */
    useful_bytes = file->read((char*)mp4_buffer, BUFFER_SIZE);
    mp4_ptr = mp4_buffer;
    used_bytes = decode(mp4_ptr, useful_bytes, &xvid_dec_stats);

    /* Resize image buffer if needed */
    if(xvid_dec_stats.type == XVID_TYPE_VOL) {
        qDebug() << "VOL";

        /* Check if old buffer is smaller */
        if ( width*height < xvid_dec_stats.data.vol.width*xvid_dec_stats.data.vol.height) {

            /* Copy new witdh and new height from the vol structure */
            width = xvid_dec_stats.data.vol.width;
            height = xvid_dec_stats.data.vol.height;

            /* Free old output buffer*/
            if ( decodeBuffer )
                delete []decodeBuffer;

            /* Allocate the new buffer */
            decodeBuffer = new unsigned char[ width * height * 4 ];
        }
    }

    /* Update buffer pointers */
    if(used_bytes > 0) {
        mp4_ptr += used_bytes;
        useful_bytes -= used_bytes;
    }

    decoderAvailable = true;
}

void XvidVideoCaptureDevice::shutdown()
{
    delete []decodeBuffer;
    delete []mp4_buffer;
    dec_stop();
    decoderAvailable = false;
}

void XvidVideoCaptureDevice::getCameraImage( QImage& img, bool copy )
{
    if ( !decoderAvailable || done ) {
        if ( img.isNull() ) {
            img = QImage(width, height, QImage::Format_RGB32);
        }
        return;
    }

    xvid_dec_stats_t xvid_dec_stats;

    // Start capturing the next frame

    /*
     * If the buffer is half empty or there are no more bytes in it
     * then fill it.
     */
    if (mp4_ptr > mp4_buffer + BUFFER_SIZE/2) {
        int already_in_buffer = (mp4_buffer + BUFFER_SIZE - mp4_ptr);

        /* Move data if needed */
        if (already_in_buffer > 0)
            memcpy(mp4_buffer, mp4_ptr, already_in_buffer);

        /* Update mp4_ptr */
        mp4_ptr = mp4_buffer;

        /* read new data */
        if ( !file->atEnd() )
            useful_bytes += file->read( (char*)mp4_buffer + already_in_buffer,
                                        BUFFER_SIZE - already_in_buffer );
    }

    /* This loop is needed to handle VOL/NVOP reading */
    do {
        used_bytes = decode(mp4_ptr, useful_bytes, &xvid_dec_stats);

        /* Resize image buffer if needed */
        if(xvid_dec_stats.type == XVID_TYPE_VOL) {
            qDebug() << "size changed.";

            /* Check if old buffer is smaller */
            if ( width*height < xvid_dec_stats.data.vol.width*xvid_dec_stats.data.vol.height) {

                /* Copy new witdh and new height from the vol structure */
                width = xvid_dec_stats.data.vol.width;
                height = xvid_dec_stats.data.vol.height;

                /* Free old output buffer*/
                if ( decodeBuffer )
                    delete []decodeBuffer;

                /* Allocate the new buffer */
                decodeBuffer = new unsigned char[ width * height * 4 ];
            }
        }

        /* Update buffer pointers */
        if(used_bytes > 0) {
            mp4_ptr += used_bytes;
            useful_bytes -= used_bytes;
        }
    } while (xvid_dec_stats.type <= 0 && useful_bytes > MIN_USEFUL_BYTES);

    /*
     * Check if there is a negative number of useful bytes left in buffer
     * This means we went too far
     */
    if (useful_bytes < 0) {
        decoderAvailable = false;
        return;
    }

    if ( !copy ) {
        img = QImage( decodeBuffer, width, height, QImage::Format_RGB32 );
    } else {
        img = QImage( width, height, QImage::Format_RGB32 );
        memcpy( img.bits(), decodeBuffer, width * height * 4 );
    }

    // XXX - hack to work around QImage bug... must remove!
    for(int ii = 0; ii < width; ++ii)
        for(int jj = 0; jj < height; ++jj)
            img.setPixel(ii, jj, img.pixel(ii, jj) | 0xFF000000);

    if ( useful_bytes < MIN_USEFUL_BYTES && file->atEnd() )
        done = true;
}

int XvidVideoCaptureDevice::dec_init()
{
    int ret;

    xvid_gbl_init_t xvid_gbl_init;
    xvid_dec_create_t xvid_dec_create;

    /* Reset the structure with zeros */
    memset(&xvid_gbl_init, 0, sizeof(xvid_gbl_init_t));
    memset(&xvid_dec_create, 0, sizeof(xvid_dec_create_t));

    /*------------------------------------------------------------------------
     * XviD core initialization
     *----------------------------------------------------------------------*/

    /* Version */
    xvid_gbl_init.version = XVID_VERSION;

    xvid_global(NULL, 0, &xvid_gbl_init, NULL);

    /*------------------------------------------------------------------------
     * XviD encoder initialization
     *----------------------------------------------------------------------*/

    /* Version */
    xvid_dec_create.version = XVID_VERSION;

    /*
     * Image dimensions -- set to 0, xvidcore will resize when ever it is
     * needed
     */
    xvid_dec_create.width = 0;
    xvid_dec_create.height = 0;

    ret = xvid_decore(0, XVID_DEC_CREATE, &xvid_dec_create, 0);

    dec_handle = xvid_dec_create.handle;

    return ret;
}

/* close decoder to release resources */
int XvidVideoCaptureDevice::dec_stop()
{
    int ret;

    ret = xvid_decore(dec_handle, XVID_DEC_DESTROY, 0, 0);

    return ret;
}


int XvidVideoCaptureDevice::decode(unsigned char *istream, int istream_size,
                                   xvid_dec_stats_t *xvid_dec_stats)
{
    int ret;

    xvid_dec_frame_t xvid_dec_frame;

    /* Reset all structures */
    memset(&xvid_dec_frame, 0, sizeof(xvid_dec_frame_t));
    memset(xvid_dec_stats, 0, sizeof(xvid_dec_stats_t));

    /* Set version */
    xvid_dec_frame.version = XVID_VERSION;
    xvid_dec_stats->version = XVID_VERSION;

    /* No general flags to set */
    xvid_dec_frame.general = 0;

    /* Input stream */
    xvid_dec_frame.bitstream = istream;
    xvid_dec_frame.length = istream_size;

    /* Output frame structure */
    xvid_dec_frame.output.plane[0]  = decodeBuffer;
    xvid_dec_frame.output.stride[0] = width*4;
    xvid_dec_frame.output.csp = XVID_CSP_BGRA;

    ret = xvid_decore(dec_handle, XVID_DEC_DECODE, &xvid_dec_frame, xvid_dec_stats);

    return ret;
}

QList<QSize> XvidVideoCaptureDevice::photoSizes() const
{
    QList<QSize> list;
    list.append( QSize( width, height ) );

    return list;
}

QList<QSize> XvidVideoCaptureDevice::videoSizes() const
{
    // We use the same sizes for both.
    return photoSizes();
}

QSize XvidVideoCaptureDevice::recommendedPhotoSize() const
{
    return QSize( width, height );
}

QSize XvidVideoCaptureDevice::recommendedVideoSize() const
{
    return QSize( width, height );
}

QSize XvidVideoCaptureDevice::recommendedPreviewSize() const
{
    return QSize( width, height );
}

void XvidVideoCaptureDevice::setCaptureSize( QSize size )
{
    size = size;
}

} // ns camera


