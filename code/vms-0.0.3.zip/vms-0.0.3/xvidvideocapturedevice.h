/*******************************************************
 **
 ** Provided by ���ɽ�, Fuzhou University
 ** Email: mileden@126.com
 ** Homepage: http://sonew.512j.com/
 ** This product is free for use.
 ** last changed 2009-2-14
 **
 *******************************************************/

#ifndef XVIDVIDEOCAPTUREDEVICE_H
#define XVIDVIDEOCAPTUREDEVICE_H

#include "videocapturedevice.h"
#include "xvid.h"
#include <QFile>

namespace camera
{

class XvidVideoCaptureDevice : public VideoCaptureDevice
{
public:

    XvidVideoCaptureDevice(const QString fileName);
    ~XvidVideoCaptureDevice();

    bool hasCamera() const;
    void getCameraImage( QImage& img, bool copy = false );

    QList<QSize> photoSizes() const;
    QList<QSize> videoSizes() const;

    QSize recommendedPhotoSize() const;
    QSize recommendedVideoSize() const;
    QSize recommendedPreviewSize() const;

    QSize captureSize() const;
    void setCaptureSize( QSize size );

    uint refocusDelay() const;
    int minimumFramePeriod() const;

private:

    int width, height;
    void* dec_handle;
    unsigned char* decodeBuffer;
    unsigned char* mp4_buffer;
    qint64 useful_bytes, used_bytes;
    unsigned char* mp4_ptr;
    bool decoderAvailable;
    bool done;
    QFile* file;

    int dec_init();
    int dec_stop();
    int decode(unsigned char *istream, int istream_size, xvid_dec_stats_t *xvid_dec_stats);
    void setupCamera( QSize size );
    void shutdown();
};

} // ns camera

#endif // XVIDVIDEOCAPTUREDEVICE_H
