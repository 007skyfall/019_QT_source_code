/*******************************************************
 **
 ** Provided by ���ɽ�, Fuzhou University
 ** Email: mileden@126.com
 ** Homepage: http://sonew.512j.com/
 ** This product is free for use.
 ** last changed 2009-1-7
 **
 *******************************************************/

#ifndef THUMBBUTTON_H
#define THUMBBUTTON_H

#include <QToolButton>

class ThumbButton : public QToolButton
{
    Q_OBJECT
public:
    ThumbButton( QWidget *parent );

protected:
    void paintEvent( QPaintEvent* );
};

#endif // THUMBBUTTON_H
