#include "keypad.h"

//
Keypad::Keypad( QWidget * parent, Qt::WFlags f) 
	: QDialog(parent, f)
{
	setupUi(this);
}

void Keypad::digit0Clicked()//0
{
	int digitValue = toolButton_0->text().toInt();
	if (display->text() == "0" && digitValue == 0)
		return;

	if(waitingForOperand) 
	{
		display->clear();
		waitingForOperand = false;
	}
	display->setText(display->text() + QString::number(digitValue));
}
void Keypad::digit1Clicked()//1
{
	int digitValue = toolButton_1->text().toInt();
	if (display->text() == "0" && digitValue == 0)
		return;

	if(waitingForOperand) 
	{
		display->clear();
		waitingForOperand = false;
	}
	display->setText(display->text() + QString::number(digitValue));
}
void Keypad::digit2Clicked()//2
{
	int digitValue = toolButton_2->text().toInt();
	if (display->text() == "0" && digitValue == 0)
		return;

	if(waitingForOperand) 
	{
		display->clear();
		waitingForOperand = false;
	}
	display->setText(display->text() + QString::number(digitValue));
}
void Keypad::digit3Clicked()//3
{
	int digitValue = toolButton_3->text().toInt();
	if (display->text() == "0" && digitValue == 0)
		return;

	if(waitingForOperand) 
	{
		display->clear();
		waitingForOperand = false;
	}
	display->setText(display->text() + QString::number(digitValue));
}
void Keypad::digit4Clicked()//4
{
	int digitValue = toolButton_4->text().toInt();
	if (display->text() == "0" && digitValue == 0)
		return;

	if(waitingForOperand) 
	{
		display->clear();
		waitingForOperand = false;
	}
	display->setText(display->text() + QString::number(digitValue));
}
void Keypad::digit5Clicked()//5
{
	int digitValue = toolButton_5->text().toInt();
	if (display->text() == "0" && digitValue == 0)
		return;

	if(waitingForOperand) 
	{
		display->clear();
		waitingForOperand = false;
	}
	display->setText(display->text() + QString::number(digitValue));
}
void Keypad::digit6Clicked()//6
{
	int digitValue = toolButton_6->text().toInt();
	if (display->text() == "0" && digitValue == 0)
		return;

	if(waitingForOperand) 
	{
		display->clear();
		waitingForOperand = false;
	}
	display->setText(display->text() + QString::number(digitValue));
}
void Keypad::digit7Clicked()//7
{
	int digitValue = toolButton_7->text().toInt();
	if (display->text() == "0" && digitValue == 0)
		return;

	if(waitingForOperand) 
	{
		display->clear();
		waitingForOperand = false;
	}
	display->setText(display->text() + QString::number(digitValue));
}
void Keypad::digit8Clicked()//8
{
	int digitValue = toolButton_8->text().toInt();
	if (display->text() == "0" && digitValue == 0)
		return;

	if(waitingForOperand) 
	{
		display->clear();
		waitingForOperand = false;
	}
	display->setText(display->text() + QString::number(digitValue));
}
void Keypad::digit9Clicked()//9
{
	int digitValue = toolButton_9->text().toInt();
	if (display->text() == "0" && digitValue == 0)
		return;

	if(waitingForOperand) 
	{
		display->clear();
		waitingForOperand = false;
	}
	display->setText(display->text() + QString::number(digitValue));
}

void Keypad::enterClicked()//确认键
{
	waitingForOperand = true;
	emit setvalue(display->text());
	this->close();
}

void Keypad::pointClicked()//小数点
{
	if (waitingForOperand)
		display->setText("0");
	if (!display->text().contains("."))
		display->setText(display->text() + tr("."));
	waitingForOperand = false;
}

void Keypad::changeSignClicked()//正负号
{
	QString text = display->text();
	double value = text.toDouble();
	
	if (value > 0.0) {
	    text.prepend(tr("-"));
	} else if (value < 0.0) {
	    text.remove(0, 1);
	}
	display->setText(text);
}

void Keypad::backspaceClicked()//退格键
{
	QString text = display->text();
	text.chop(1);
	if (text.isEmpty()) {
	    text = "0";
	    waitingForOperand = true;
	}
	display->setText(text);
}

void Keypad::clear()//清除键
{
	display->setText("0");
	waitingForOperand = true;
}
