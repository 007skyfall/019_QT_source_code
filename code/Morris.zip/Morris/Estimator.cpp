#include "Estimator.h"
#include "Morris.h"
#include "MoveGenerator.h"

// Attention: all estimations are based on startColor's view
// Do not use board's color, because it changes

int Estimator::getEstimation(const Board& board) 
{
	counter ++;
	return isOpening ? getOpeningEstimation(board) : getGameEstimation(board);
}

int Estimator::countMoves(const Board& board, QChar color) const 
{
	Board b(board.toString(), color);
	return MoveGenerator::countMoves(b, isOpening);
}

int BasicEstimator::getOpeningEstimation(const Board& board) const {
	return board.countNumber(startColor) - board.countNumber(Board::flipColor(startColor));
}

int BasicEstimator::getGameEstimation(const Board& board) const
{
	const QChar opponentColor = Board::flipColor(startColor);
	const int selfCount       = board.countNumber(startColor);
	const int opponentCount   = board.countNumber(opponentColor);
	const int opponentMoveCount = countMoves(board, opponentColor);
	if(opponentCount <= 2)
		return MAX_ESTIMATION;
	if(selfCount <= 2)
		return MIN_ESTIMATION;
	if(opponentMoveCount == 0)
		return MAX_ESTIMATION;
	return 1000 * (selfCount - opponentCount) - opponentMoveCount;
}

int ImprovedEstimator::getOpeningEstimation(const Board& board) const {
	return board.countJoints(startColor) - board.countJoints(Board::flipColor(startColor));
}

int ImprovedEstimator::getGameEstimation(const Board& board) const
{
	const QChar opponentColor   = Board::flipColor(startColor);
	const int selfJoints        = board.countJoints(startColor);
	const int opponentJoints    = board.countJoints(opponentColor);
	const int opponentMoveCount = countMoves(board, opponentColor);
	if(opponentJoints <= 2)
		return MAX_ESTIMATION;
	if(selfJoints <= 2)
		return MIN_ESTIMATION;
	if(opponentMoveCount == 0)
		return MAX_ESTIMATION;
	return 1000 * (selfJoints - opponentJoints) - opponentMoveCount;
}