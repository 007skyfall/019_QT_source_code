<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>BoardView</name>
    <message>
        <location filename="BoardView.cpp" line="181"/>
        <source>Arial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="BoardView.cpp" line="278"/>
        <source>%1&apos;s turn</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="BoardView.cpp" line="278"/>
        <source>White</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="BoardView.cpp" line="278"/>
        <source>Black</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BoardViewClass</name>
    <message>
        <location filename="BoardView.ui" line="14"/>
        <source>BoardView</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DlgSetting</name>
    <message>
        <location filename="DlgSetting.cpp" line="69"/>
        <source>White</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.cpp" line="70"/>
        <source>Black</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.cpp" line="78"/>
        <source>White - PC1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.cpp" line="79"/>
        <source>Black - PC2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.cpp" line="85"/>
        <source>White - Human</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.cpp" line="86"/>
        <source>Black - PC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.cpp" line="92"/>
        <source>White - Human1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.cpp" line="93"/>
        <source>Black - Human2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.cpp" line="132"/>
        <source>Reasonning depth = %1 (%2)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.cpp" line="134"/>
        <source>The greater the smarter, but slower</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.cpp" line="140"/>
        <source>fastest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.cpp" line="140"/>
        <source>faster</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.cpp" line="140"/>
        <source>middle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.cpp" line="140"/>
        <source>slower</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.cpp" line="140"/>
        <source>slowest</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.cpp" line="141"/>
        <source>Speed = %1  (%2)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DlgSettingClass</name>
    <message>
        <location filename="DlgSetting.ui" line="19"/>
        <source>Setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.ui" line="25"/>
        <source>Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.ui" line="31"/>
        <source>Single Step</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.ui" line="41"/>
        <source>PC - PC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.ui" line="48"/>
        <source>PC - Human</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.ui" line="55"/>
        <source>Human - Human</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.ui" line="65"/>
        <source>Start color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.ui" line="71"/>
        <source>White</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.ui" line="81"/>
        <source>Black</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.ui" line="91"/>
        <source>Language (Activate next time)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.ui" line="98"/>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
    <message utf8="true">
        <location filename="DlgSetting.ui" line="103"/>
        <source>中文</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.ui" line="114"/>
        <source>Algorithm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.ui" line="120"/>
        <source>MinMax</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.ui" line="130"/>
        <source>Alpha-Beta pruning (faster)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.ui" line="140"/>
        <source>Estimation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.ui" line="146"/>
        <source>Basic estimation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.ui" line="156"/>
        <source>Improved estimation (smarter)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.ui" line="166"/>
        <source>Computer Intelligence</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.ui" line="172"/>
        <source>Reasonning depth (The greater the smarter, but slower)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="DlgSetting.ui" line="201"/>
        <source>Speed</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GameManager</name>
    <message>
        <location filename="Manager.cpp" line="70"/>
        <source>Morris - </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Manager.cpp" line="134"/>
        <location filename="Manager.cpp" line="135"/>
        <source>%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Manager.cpp" line="204"/>
        <source>Game over</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Manager.cpp" line="205"/>
        <source>%1 wins</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Manager.cpp" line="205"/>
        <source>Black</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="Manager.cpp" line="205"/>
        <source>White</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HumanHumanModeManager</name>
    <message>
        <location filename="Manager.h" line="116"/>
        <source>Human-Human Mode</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Logger</name>
    <message>
        <location filename="Logger.h" line="16"/>
        <source>%1: %2</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWnd</name>
    <message>
        <location filename="MainWnd.cpp" line="47"/>
        <location filename="MainWnd.cpp" line="74"/>
        <source>Open File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="MainWnd.cpp" line="48"/>
        <location filename="MainWnd.cpp" line="75"/>
        <source>Text files (*.txt);;All files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="MainWnd.cpp" line="120"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="MainWnd.cpp" line="120"/>
        <source>&lt;h2&gt;&lt;b&gt;Morris&lt;/b&gt;&lt;/h2&gt; &lt;p&gt;Build 2010.3.6&lt;/p&gt;   &lt;p&gt;&lt;a href=mailto:CongChenUTD@Gmail.com&gt;CongChenUTD@Gmail.com&lt;/a&gt;&lt;/p&gt; &lt;h3&gt;Rules&lt;/h3&gt; &lt;p&gt;Opening phase: Players take turns placing pieces on any vacant board intersection spot until all pieces have been placed&lt;/p&gt; &lt;p&gt;Midgame: Once all the pieces are placed, then take turns moving one piece along a board line to any adjacent vacant spot&lt;/p&gt; &lt;p&gt;Endgame: When a player is down to only three game pieces, then he may move a piece to any open spot, not just an adjacent one (hopping)&lt;/p&gt; &lt;p&gt;Mills: At any stage if you get three pieces in a row along the same straight board line, then you may remove one isolated opponent piece from play. An isolated piece is a piece that is not part of a mill.&lt;/p&gt; The winner is the first player to reduce the opponent to only 2 tokens, or blocks the opponent from any further moves.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="MainWnd.cpp" line="168"/>
        <location filename="MainWnd.cpp" line="178"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="MainWnd.cpp" line="168"/>
        <location filename="MainWnd.cpp" line="178"/>
        <source>Open input file first</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWndClass</name>
    <message>
        <location filename="MainWnd.ui" line="19"/>
        <source>MinMaxOpening</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="MainWnd.ui" line="42"/>
        <source>Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="MainWnd.ui" line="52"/>
        <source>  Output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="MainWnd.ui" line="62"/>
        <source>  # of Estimation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="MainWnd.ui" line="79"/>
        <source>  Estimation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="MainWnd.ui" line="96"/>
        <source>  Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="MainWnd.ui" line="109"/>
        <source>Tool bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="MainWnd.ui" line="144"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="MainWnd.ui" line="153"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="MainWnd.ui" line="162"/>
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="MainWnd.ui" line="171"/>
        <source>Opening</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="MainWnd.ui" line="180"/>
        <source>Mid_End</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="MainWnd.ui" line="189"/>
        <source>Setting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="MainWnd.ui" line="198"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="MainWnd.ui" line="207"/>
        <source>Step</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="MainWnd.ui" line="216"/>
        <source>Run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="MainWnd.ui" line="225"/>
        <source>Restart</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PCHumanModeManager</name>
    <message>
        <location filename="Manager.h" line="104"/>
        <source>PC-Human Mode</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PCPCModeManager</name>
    <message>
        <location filename="Manager.h" line="84"/>
        <source>PC-PC Mode</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SingleStepModeManager</name>
    <message>
        <location filename="Manager.h" line="68"/>
        <source>Single Step Mode</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
