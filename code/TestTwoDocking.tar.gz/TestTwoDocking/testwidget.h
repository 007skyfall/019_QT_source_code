#ifndef TESTWIDGET_H
#define TESTWIDGET_H

#include <QWidget>
#include <QHBoxLayout>
#include <QPushButton>

class TestWidget : public QWidget
{
public:
    TestWidget(QString str1,QString str2);

private:

    QPushButton *createBtn;
    QPushButton *delBtn;
};

#endif // TESTWIDGET_H
