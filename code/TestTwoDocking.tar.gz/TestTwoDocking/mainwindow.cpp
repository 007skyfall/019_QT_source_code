#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "testwidget.h"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    initLeftDocking();
    initRightDocking();
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::initLeftDocking(){


    m_leftWidget = new TestWidget(tr("Left Create Btn"),tr("LeftRemove"));
    m_leftDock = new QDockWidget(tr("Left"),this);
    m_leftDock->setAllowedAreas(Qt::LeftDockWidgetArea);
    m_leftDock->setFeatures(QDockWidget::DockWidgetClosable);
    m_leftDock->setFloating(false);
    m_leftDock->setVisible(true);
    m_leftDock->setWidget(m_leftWidget);


    addDockWidget(Qt::LeftDockWidgetArea,m_leftDock,Qt::Horizontal);

}//end of method initDockWiget

void MainWindow::initRightDocking(){

    m_rightWidget = new TestWidget(tr("Right Create Btn"),tr("RightRemove"));
    m_rightDock = new QDockWidget(tr("Right"),this);
    m_rightDock->setAllowedAreas(Qt::RightDockWidgetArea);
    m_rightDock->setFeatures(QDockWidget::DockWidgetClosable);
    m_rightDock->setFloating(false);
    m_rightDock->setVisible(true);
    m_rightDock->setWidget(m_rightWidget);

    addDockWidget(Qt::RightDockWidgetArea,m_rightDock,Qt::Horizontal);

}//end of method initPropertiesDock

