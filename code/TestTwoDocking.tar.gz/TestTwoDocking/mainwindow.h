#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QtGui/QMainWindow>
#include <QWidget>
#include <QDockWidget>
#include <QHBoxLayout>
#include <QPushButton>

namespace Ui
{
    class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = 0);
    ~MainWindow();

private:
    Ui::MainWindow *ui;
    QDockWidget *m_leftDock;
    QDockWidget *m_rightDock;
    QWidget *m_leftWidget;
    QWidget *m_rightWidget;

    void initLeftDocking();
    void initRightDocking();
};

#endif // MAINWINDOW_H
