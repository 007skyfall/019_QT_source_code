#include "testwidget.h"

TestWidget::TestWidget(QString str1,QString str2)
{
    QHBoxLayout *btnLayout = new QHBoxLayout;
    createBtn = new QPushButton(str1);
    delBtn = new QPushButton(str2);
    btnLayout->addWidget(createBtn);
    btnLayout->addWidget(delBtn);
    this->setLayout(btnLayout);
}
