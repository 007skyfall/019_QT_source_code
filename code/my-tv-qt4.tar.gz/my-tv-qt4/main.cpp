#include <QApplication>
#include <QtGui>

#include "windowtv.h"

int main(int argc,char *argv[])
{
	Q_INIT_RESOURCE(resource);

	QApplication app(argc,argv);

	QTranslator translator;
	translator.load(":/zh_CN");
	app.installTranslator(&translator);
	
	WindowTV window;
	window.show();
	return app.exec();
}
