#ifndef WINDOWTV_H
#define WINDOWTV_H

#include <QtGui>


 class WindowTV : public QWidget
{
	Q_OBJECT
			
	public:
		WindowTV();

	private:

		QFile file;
		void readFile();
		void saveFile();

		QSettings *settings;

		QTreeWidget *channelTreeWidget;
		QTreeWidgetItem *radioTreeItem;
		QTreeWidgetItem *tvTreeItem;
		
		QTreeWidgetItem *addTreeItem;
		QTreeWidgetItem *playTreeItem;

		QString playerName;
		QProcess *playProcess;
		QProcess *stopProcess;

		QDialog *optionDialog;
		QLineEdit *playerLineEdit;

		QDialog *addDialog;
		QComboBox *typeComboBox;
		QLineEdit *nameLineEdit;
		QLineEdit *urlLineEdit;

		QString fileRadio;
		QString fileTV;

	public slots:

		void selectPlayer();
		void setPlayer();
		
		void play();
		
		void add();
		void submitAddChannel();
				
		void del();
		void option();
		void about();
};

#endif
