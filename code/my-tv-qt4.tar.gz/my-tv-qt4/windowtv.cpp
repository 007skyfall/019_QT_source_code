#include <QtGui>
#include <windowtv.h>

 WindowTV::WindowTV()
{
	setWindowTitle(tr("My TV"));
	resize(640,480);
	//Ƶ���б�
	channelTreeWidget = new QTreeWidget(this);
	channelTreeWidget->setSelectionMode(QAbstractItemView::SingleSelection);

	QStringList headerLabels;
	headerLabels << tr("Channel") <<  tr("URL");
	channelTreeWidget->setHeaderLabels(headerLabels);
	channelTreeWidget->setSortingEnabled(true);

	channelTreeWidget->header()->resizeSection(0,150);

	radioTreeItem = new QTreeWidgetItem(channelTreeWidget);
	radioTreeItem->setText(0, tr("Net Radio"));
	tvTreeItem = new QTreeWidgetItem(channelTreeWidget);
	tvTreeItem->setText(0, tr("Net TV"));
	
	connect(channelTreeWidget, SIGNAL(itemDoubleClicked(QTreeWidgetItem *, int)), this, SLOT(play()));
	
	//��ť����
	QPushButton *playButton = new QPushButton(tr("&Play"),this);
	connect( playButton, SIGNAL( clicked()), this, SLOT( play()));

	QPushButton *addButton = new QPushButton(tr("&Add"),this);
	connect( addButton, SIGNAL( clicked()), this, SLOT( add()));

	QPushButton *delButton = new QPushButton(tr("&Del"),this);
	connect( delButton, SIGNAL( clicked()), this, SLOT( del()));

	QPushButton *quitButton = new QPushButton(tr("&Quit"),this);
	connect( quitButton, SIGNAL( clicked()), this, SLOT( close()));

	QPushButton *optionButton = new QPushButton(tr("&Option"),this);
	connect( optionButton, SIGNAL( clicked()), this, SLOT( option()));

	QPushButton *aboutButton = new QPushButton(tr("&About"),this);
	connect( aboutButton, SIGNAL( clicked()), this, SLOT( about()));

	//���ϲ���
	QVBoxLayout *rightLayout = new QVBoxLayout;
	rightLayout->addWidget(addButton);
	rightLayout->addWidget(delButton);
	rightLayout->addStretch(1);
	rightLayout->addWidget(playButton);
	rightLayout->addWidget(optionButton);
	rightLayout->addStretch(1);

	//�ϲ���
	QHBoxLayout *topLayout = new QHBoxLayout;
	topLayout->addWidget(channelTreeWidget);
	topLayout->addLayout(rightLayout);

	//�²���
	QHBoxLayout *bottomLayout = new QHBoxLayout;
	bottomLayout->addWidget(aboutButton);
	bottomLayout->addStretch(1);
	bottomLayout->addWidget(quitButton);

	//���岼��
	QVBoxLayout *mainLayout = new QVBoxLayout(this);
	mainLayout->addLayout(topLayout);
	mainLayout->addLayout(bottomLayout);

	fileRadio = QString("channel-radio.txt");
	fileTV = QString("channel-tv.txt");

	settings = new QSettings("My-TV", "Mofei");
	
	if(settings->value("playerName").toString().isEmpty())
	{
		playerName = QString("kaffeine");
	}
	else
	{
		playerName = settings->value("playerName").toString();
	}
	
	playProcess = new QProcess(this);

	//��ȡ���̵�Ƶ���б��ļ�
	readFile();
}

//����
void WindowTV::about()
{
	QMessageBox::information(this, tr("About"),
				 tr("My-TV mofei 2006"
				   "\nQt4.12  MagicLinux2.0"));
}

//����
void WindowTV::option()
{
	optionDialog = new QDialog(this);
	QGroupBox *optionGroupBox = new QGroupBox(tr("&Option"), optionDialog);
	
	QLabel *optionLabel = new QLabel(tr("Select the player:"));
	playerLineEdit = new QLineEdit(playerName);
	optionLabel->setBuddy(playerLineEdit);
	
	QPushButton *selectButton = new QPushButton("...");
	connect(selectButton, SIGNAL(clicked()), this, SLOT(selectPlayer()));

	QPushButton *okButton = new QPushButton(tr("&Ok"), optionDialog);
	connect(okButton, SIGNAL(clicked()), this, SLOT(setPlayer()));
	
	QPushButton *cancelButton = new QPushButton(tr("&Cancel"), optionDialog);
	connect(cancelButton, SIGNAL(clicked()), optionDialog, SLOT(close()));

	QHBoxLayout *playerLayout = new QHBoxLayout;
	playerLayout->addWidget(playerLineEdit);
	playerLayout->addWidget(selectButton);

	QVBoxLayout *groupLayout = new QVBoxLayout;
	groupLayout->addWidget(optionLabel);
	groupLayout->addLayout(playerLayout);

	optionGroupBox->setLayout(groupLayout);

	QHBoxLayout *buttonLayout = new QHBoxLayout;
	buttonLayout->addStretch(1);
	buttonLayout->addWidget(okButton);
	buttonLayout->addWidget(cancelButton);


	QVBoxLayout *mainLayout = new QVBoxLayout(optionDialog);
	mainLayout->addWidget(optionGroupBox);
	mainLayout->addLayout(buttonLayout);

	optionDialog->exec();
}

//ѡ�񲥷���
void WindowTV::selectPlayer()
{
	QString playerFile = QFileDialog::getOpenFileName(this,
			tr("Select Player"),
			tr("/"),
			tr("All Files (*)"));
	
	if(playerFile.isEmpty())
	{
		return;
	}
	
	playerLineEdit->setText(playerFile); 
}

//���õ�ǰ������
void WindowTV::setPlayer()
{
	if(playerLineEdit->text().isEmpty())
	{
		QMessageBox::critical(0, tr("Error"), tr("player name  is empty!")
				,QMessageBox::NoButton, QMessageBox::NoButton, QMessageBox::NoButton);
		return;
	}
	playerName = playerLineEdit->text();
	settings->setValue("playerName",playerName);
	optionDialog->close();
}

//����
void WindowTV::play()
{
	//��ⲥ����ָ��
	if(playerName.isEmpty())
	{
		QMessageBox::critical(0, tr("Error"), tr("player name  is empty!")
				,QMessageBox::NoButton, QMessageBox::NoButton, QMessageBox::NoButton);
		return;
	}
	
	playTreeItem = channelTreeWidget->currentItem();
	if(playTreeItem == NULL || playTreeItem->text(1).isEmpty())
	{
		return;
	}
	
	playProcess->start(QString(playerName + (" ") + playTreeItem->text(1)));
}

//����
void WindowTV::add()
{
	addDialog = new QDialog(this);

	QGroupBox *addGroupBox = new QGroupBox(tr("add new channel"), addDialog);

	QLabel *typeLabel = new QLabel(tr("&Type"), addGroupBox);
	typeComboBox = new QComboBox(addGroupBox);
	typeComboBox->addItem("Net radio");
	typeComboBox->addItem("Net TV");
	typeLabel->setBuddy(typeComboBox);
	
	QLabel *nameLabel = new QLabel(tr("&Name"), addGroupBox);
	nameLineEdit = new QLineEdit(addGroupBox);
	nameLabel->setBuddy(nameLineEdit);

	QLabel *urlLabel = new QLabel(tr("&Url"), addGroupBox);
	urlLineEdit = new QLineEdit(addGroupBox);
	urlLabel->setBuddy(urlLineEdit);

	QGridLayout *groupLayout = new QGridLayout(addGroupBox);
	groupLayout->addWidget(typeLabel,0,0);
	groupLayout->addWidget(typeComboBox,0,1);
	groupLayout->addWidget(nameLabel,1,0);
	groupLayout->addWidget(nameLineEdit,1,1);
	groupLayout->addWidget(urlLabel,2,0);
	groupLayout->addWidget(urlLineEdit,2,1);


	QPushButton *okButton = new QPushButton(tr("&Ok"), addDialog);
	connect(okButton, SIGNAL(clicked()), this, SLOT(submitAddChannel()));
	
	QPushButton *cancelButton = new QPushButton(tr("&Cancel"), addDialog);
	connect(cancelButton, SIGNAL(clicked()), addDialog, SLOT(close()));

	QHBoxLayout *buttonLayout = new QHBoxLayout;
	buttonLayout->addStretch(1);
	buttonLayout->addWidget(okButton);
	buttonLayout->addWidget(cancelButton);

			
	QVBoxLayout *mainLayout = new QVBoxLayout(addDialog);
	mainLayout->addWidget(addGroupBox);
	mainLayout->addLayout(buttonLayout);
	
	addDialog->exec();
}

//�ύ��Ƶ��
void WindowTV::submitAddChannel()
{
	if(typeComboBox->currentIndex() < 0 || nameLineEdit->text().isEmpty() || urlLineEdit->text().isEmpty())
	{
		QMessageBox::critical(0, tr("Add error"), tr("Fragmentary channel information")
				,QMessageBox::NoButton, QMessageBox::NoButton, QMessageBox::NoButton);
		return;
	}

	if(typeComboBox->currentIndex() == 0)
	{
		addTreeItem = new QTreeWidgetItem(radioTreeItem);
	}
	else
		if(typeComboBox->currentIndex() == 1)
		{
			addTreeItem = new QTreeWidgetItem(tvTreeItem);
		}
		else
		{
			return;
		}
		
	addTreeItem->setText(0, nameLineEdit->text());
	addTreeItem->setText(1, urlLineEdit->text());

	saveFile();
	addTreeItem = 0;
	addDialog->close();
}

//ɾ��
void WindowTV::del()
{
	addTreeItem = channelTreeWidget->currentItem();
	if(addTreeItem == NULL || addTreeItem->text(1).isEmpty())
	{
		return;
	}

	//ȷ��
	int reply = QMessageBox::question(this, tr("Delete Item"),
					  tr("Are you sure to delete the item?"),
					  QMessageBox::Yes,
					  QMessageBox::No);
	if (reply == QMessageBox::Yes)
	{
		QTreeWidgetItem *parentItem;
		parentItem = addTreeItem->parent();
		parentItem->takeChild(parentItem->indexOfChild(addTreeItem));
	}
	
	//����
	saveFile();
	addTreeItem = 0;
}

//����Ƶ���������ļ�
void WindowTV::saveFile()
{
	//����RadioƵ��
	file.setFileName(fileRadio);
	if (file.open(QFile::WriteOnly))
	{
		QTextStream out(&file);
		for(int i = 0; i < radioTreeItem->childCount(); i++)
		{
			out << radioTreeItem->child(i)->text(0);
			out << ",";
			out << radioTreeItem->child(i)->text(1);
			out << "\n";
		}
		file.close();
	}
	else
	{
		QMessageBox::critical(0, tr("Save error"), tr("Cannot open file:%1").arg(fileRadio)
				,QMessageBox::NoButton, QMessageBox::NoButton, QMessageBox::NoButton);
	}

	//����TVƵ��
	file.setFileName(fileTV);
	if (file.open(QFile::WriteOnly))
	{
		QTextStream out(&file);
		for(int i = 0; i < tvTreeItem->childCount(); i++)
		{
			out << tvTreeItem->child(i)->text(0);
			out << ",";
			out << tvTreeItem->child(i)->text(1);
			out << "\n";
		}
		file.close();
	}
	else
	{
		QMessageBox::critical(0, tr("Save error"), tr("Cannot open file:%1").arg(fileTV)
				,QMessageBox::NoButton, QMessageBox::NoButton, QMessageBox::NoButton);
	}
}


void WindowTV::readFile()
{	
	//��ȡRadioƵ��
	file.setFileName(fileRadio);
	if (file.open(QFile::ReadOnly | QIODevice::Text))
	{
		QTextStream in(&file);
		while( !in.atEnd() )
		{
			QStringList streamList = in.readLine().split(",");
			if(streamList.count() == 0)
			{
				break;
			}
			
			addTreeItem = new QTreeWidgetItem(radioTreeItem);
			addTreeItem->setText(0, streamList.at(0));
			addTreeItem->setText(1, streamList.at(1));
		}
		addTreeItem = 0;
		file.close();
	}
	else
	{
		QMessageBox::critical(0, tr("Read error"), tr("Cannot open file:%1").arg(fileRadio)
				,QMessageBox::NoButton, QMessageBox::NoButton, QMessageBox::NoButton);
	}
	

	//��ȡTVƵ��
	file.setFileName(fileTV);
	if (file.open(QFile::ReadOnly | QIODevice::Text))
	{
		QTextStream in(&file);
		while( !in.atEnd() )
		{
			QStringList streamList = in.readLine().split(",");
			if(streamList.count() == 0)
			{
				break;
			}
			
			addTreeItem = new QTreeWidgetItem(tvTreeItem);
			addTreeItem->setText(0, streamList.at(0));
			addTreeItem->setText(1, streamList.at(1));
		}
		addTreeItem = 0;
		file.close();
	}
	else
	{
		QMessageBox::critical(0, tr("Read error"), tr("Cannot open file:%1").arg(fileTV)
				,QMessageBox::NoButton, QMessageBox::NoButton, QMessageBox::NoButton);
	}
}
