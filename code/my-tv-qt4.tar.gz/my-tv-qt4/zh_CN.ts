<!DOCTYPE TS><TS>
<context>
    <name>WindowTV</name>
    <message>
        <source>My TV</source>
        <translation>MY TV - 网络电视</translation>
    </message>
    <message>
        <source>Channel</source>
        <translation>频道</translation>
    </message>
    <message>
        <source>URL</source>
        <translation>网址</translation>
    </message>
    <message>
        <source>Net Radio</source>
        <translation>网络电台</translation>
    </message>
    <message>
        <source>Net TV</source>
        <translation>网络电视</translation>
    </message>
    <message>
        <source>&amp;Play</source>
        <translation>播放(&amp;P)</translation>
    </message>
    <message>
        <source>&amp;Add</source>
        <translation>添加(&amp;A)</translation>
    </message>
    <message>
        <source>&amp;Del</source>
        <translation>删除(&amp;D)</translation>
    </message>
    <message>
        <source>&amp;Quit</source>
        <translation>退出(&amp;Q)</translation>
    </message>
    <message>
        <source>&amp;Option</source>
        <translation>选项(&amp;O)</translation>
    </message>
    <message>
        <source>&amp;About</source>
        <translation>关于(&amp;A)</translation>
    </message>
    <message>
        <source>About</source>
        <translation>关于</translation>
    </message>
    <message>
        <source>My-TV mofei 2006
Qt4.12  MagicLinux2.0</source>
        <translation>MY TV 网络电视
一个简单的网络电视的QT前端
地址都是从网上搜集,可能存在一些废弃的资源
莫非 MagicLinux Qt4 2006</translation>
    </message>
    <message>
        <source>Select the player:</source>
        <translation>选择播放器:</translation>
    </message>
    <message>
        <source>&amp;Ok</source>
        <translation>确定(&amp;O)</translation>
    </message>
    <message>
        <source>&amp;Cancel</source>
        <translation>取消(&amp;C)</translation>
    </message>
    <message>
        <source>Select Player</source>
        <translation>选择播放器</translation>
    </message>
    <message>
        <source>/</source>
        <translation></translation>
    </message>
    <message>
        <source>All Files (*)</source>
        <translation></translation>
    </message>
    <message>
        <source>Error</source>
        <translation>错误</translation>
    </message>
    <message>
        <source>player name  is empty!</source>
        <translation>请设置正确的播放器!</translation>
    </message>
    <message>
        <source>add new channel</source>
        <translation>添加新的频道</translation>
    </message>
    <message>
        <source>&amp;Type</source>
        <translation>类型(&amp;T)</translation>
    </message>
    <message>
        <source>&amp;Name</source>
        <translation>名称(&amp;N)</translation>
    </message>
    <message>
        <source>&amp;Url</source>
        <translation>网址(&amp;U)</translation>
    </message>
    <message>
        <source>Add error</source>
        <translation>添加频道错误</translation>
    </message>
    <message>
        <source>Fragmentary channel information</source>
        <translation>频道信息不完整</translation>
    </message>
    <message>
        <source>Delete Item</source>
        <translation>删除频道</translation>
    </message>
    <message>
        <source>Are you sure to delete the item?</source>
        <translation>确定要删除吗?</translation>
    </message>
    <message>
        <source>Save error</source>
        <translation>保存文件出错</translation>
    </message>
    <message>
        <source>Cannot open file:%1</source>
        <translation>不能打开文件: %1</translation>
    </message>
    <message>
        <source>Read error</source>
        <translation>读取文件出错</translation>
    </message>
</context>
</TS>
