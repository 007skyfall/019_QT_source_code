#ifndef WEBPAGETHUMBNAIL_H
#define WEBPAGETHUMBNAIL_H

#include <QtGui/QLabel>
#include <QtCore/QUrl>
#include <QtWebKit/QWebPage>
#include <QtWebKit/QWebFrame>

class WebPageThumbnail : public QLabel
{
Q_OBJECT

public:
    WebPageThumbnail(const QUrl& webSiteUrl, QWidget* parent = 0);
    virtual ~WebPageThumbnail();

signals:
    // Emitted when this object is double-clicked
    void doubleClicked(const QUrl& webSiteUrl);

public slots:
    // Re-load the thumbnail contents
    void refresh();
    // Set a new URL and re-load
    void setUrl(const QUrl& newWebSiteUrl);

private slots:
    // Render the page contents on QPixmap to be displayed
    // on this label
    void render();
    // Receive information on how page loading progresses
    void pageLoadProgress(int progress);

private:
    // Re-implement base class's handler function for mouse
    // double-clicks
    void mouseDoubleClickEvent(QMouseEvent* event);

private:
    // The web page of which thumbnail is created
    QWebPage m_page;
};

#endif // WEBPAGETHUMBNAIL_H
