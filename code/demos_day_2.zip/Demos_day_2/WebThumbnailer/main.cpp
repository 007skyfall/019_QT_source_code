#include <QtGui/QApplication>
#include "browsermainwindow.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    BrowserMainWindow w;
    w.show();
    return a.exec();
}
