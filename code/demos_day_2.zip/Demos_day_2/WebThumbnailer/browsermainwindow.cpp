#include <QtCore/QUrl>
#include <QtGui/QResizeEvent>
#include "browsermainwindow.h"
#include "ui_browsermainwindow.h"
#include "webpagethumbnail.h"

BrowserMainWindow::BrowserMainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::BrowserMainWindow)
{
    ui->setupUi(this);

    // TODO 1) Create the m_activeView and m_urlLineEdit widgets (see
    //         the header file for the definitions/types of these). The
    //         widgets will be added to the UI later in this constructor.
    m_activeView = new QWebView(this);
    m_urlLineEdit = new QLineEdit(this);

    // TODO 2) QWebView contains useful page actions built-in - get
    // Back, Forward and Reload actions from m_activeView and add them to the
    // ui->mainToolBar.
    // Also add m_urlLineEdit to the toolbar.
    QAction* backAction = m_activeView->pageAction(QWebPage::Back);
    QAction* forwardAction = m_activeView->pageAction(QWebPage::Forward);
    QAction* reloadAction = m_activeView->pageAction(QWebPage::Reload);

    ui->mainToolBar->addAction(backAction);
    ui->mainToolBar->addAction(forwardAction);
    ui->mainToolBar->addAction(reloadAction);
    ui->mainToolBar->addSeparator();
    ui->mainToolBar->addWidget(m_urlLineEdit);

    // TODO 3) Create a QVBoxLayout object and add a few WebPageThumbnail
    // objects to it. Use any web sites you wish as the URL!
    // Set the created layout to ui->thumbnailGroupBox.
    //    Hint: If network connection is not available, a dummy HTML file file
    //    can be loaded from the resource file with the notation
    //    QUrl("qrc:/testhtml/qtwebkit_exercise.html").
    QVBoxLayout* thumbnailLayout = new QVBoxLayout();
    WebPageThumbnail* thumbnail = new WebPageThumbnail(QUrl("qrc:/testhtml/qtwebkit_exercise.html"), this);
    WebPageThumbnail* thumbnail2 = new WebPageThumbnail(QUrl("http://www.google.com"), this);
    WebPageThumbnail* thumbnail3 = new WebPageThumbnail(QUrl("http://www.wikipedia.com"), this);
    WebPageThumbnail* thumbnail4 = new WebPageThumbnail(QUrl("http://www.youtube.com"), this);
    thumbnailLayout->addWidget(thumbnail);
    thumbnailLayout->addWidget(thumbnail2);
    thumbnailLayout->addWidget(thumbnail3);
    thumbnailLayout->addWidget(thumbnail4);
    thumbnailLayout->addStretch(1);
    ui->thumbnailGroupBox->setLayout(thumbnailLayout);

    // TODO 4) Create another QVBoxLayout and add m_activeView to it.
    // Set the layout to ui->activeWebPageGroupBox.
    QVBoxLayout* activeWebPageLayout = new QVBoxLayout();
    activeWebPageLayout->addWidget(m_activeView);
    ui->activeWebPageGroupBox->setLayout(activeWebPageLayout);

    // TODO 5) When a WebPageThumbnail is double-clicked it emits a
    // certain signal. When that happens, we want to show the given
    // URL in m_activeView. Make the needed signal-slot connections from
    // thumbnails you created in TODO 3 to a slot in this class.
    connect(thumbnail, SIGNAL(doubleClicked(QUrl)), this, SLOT(showWebPage(QUrl)));
    connect(thumbnail2, SIGNAL(doubleClicked(QUrl)), this, SLOT(showWebPage(QUrl)));
    connect(thumbnail3, SIGNAL(doubleClicked(QUrl)), this, SLOT(showWebPage(QUrl)));
    connect(thumbnail4, SIGNAL(doubleClicked(QUrl)), this, SLOT(showWebPage(QUrl)));

    // TODO 6) When user types an address to m_urlLineEdit and presses return,
    // a signal is emitted. Connect that signal to urlEdited() in this class.
    connect(m_urlLineEdit, SIGNAL(returnPressed()), this, SLOT(urlEdited()));

    // TODO 7) When user activates the web view's reload action, each
    // WebPageThumnail needs also to be refreshed. Make the needed connections
    // thumbnails' slots here.
    connect(reloadAction, SIGNAL(triggered()), thumbnail, SLOT(refresh()));
    connect(reloadAction, SIGNAL(triggered()), thumbnail2, SLOT(refresh()));
    connect(reloadAction, SIGNAL(triggered()), thumbnail3, SLOT(refresh()));
    connect(reloadAction, SIGNAL(triggered()), thumbnail4, SLOT(refresh()));

    // TODO 8) We want to know when m_activeView has finished loading and also
    // the load progress before that. Make the needed connections to this class's
    // slots here.
    connect(m_activeView, SIGNAL(loadFinished(bool)), this, SLOT(webViewLoadFinished(bool)));
    connect(m_activeView, SIGNAL(loadProgress(int)), this, SLOT(webViewLoadProgress(int)));

    // Finally, load the first page in the main web view.
    showWebPage(QUrl("qrc:/testhtml/qtwebkit_exercise.html"));
}

BrowserMainWindow::~BrowserMainWindow()
{
    delete ui;
}

void BrowserMainWindow::showWebPage(const QUrl& url)
{
    // TODO: Load the given URL in m_activeView
    m_activeView->load(url);
}

void BrowserMainWindow::urlEdited()
{
    // TODO: Get the user-typed URL and show the web page in question
    QUrl url(m_urlLineEdit->text());
    showWebPage(url);
}

void BrowserMainWindow::resizeEvent(QResizeEvent* event)
{
    int toolBarHeight = ui->mainToolBar->height();

    // By default the tool bar is on the top part of the window
    // (i.e. height of the area available for other widgets
    // is less than the full new height of the main window)
    int newWidth = event->size().width();
    int newHeight = event->size().height() - toolBarHeight;

    ui->layoutWidget->setGeometry(0, 0, newWidth, newHeight);
}

void BrowserMainWindow::webViewLoadFinished(bool ok)
{
    // TODO: If wanted, you can inform the user about page being
    // successfully loaded by e.g. setting the title of
    // ui->activeWebPageGroupBox to a suitable value (host name
    // of the web page or something similar).
    // Argument ok will tell if the page was loaded successfully and if
    // not, an error message could be shown in the title.
    if (ok)
    {
        QString host = m_activeView->url().host();
        if (host.length() > 0)
        {
            ui->activeWebPageGroupBox->setTitle(host);
        }
        else
        {
            ui->activeWebPageGroupBox->setTitle("WebKit Exercise");
        }
    }
    else
    {
        ui->activeWebPageGroupBox->setTitle("Load error occurred!");
    }
}

void BrowserMainWindow::webViewLoadProgress(int progress)
{
    // Display progress information to the user.
    ui->activeWebPageGroupBox->setTitle(QString("Loading... %1%").arg(progress));
}
