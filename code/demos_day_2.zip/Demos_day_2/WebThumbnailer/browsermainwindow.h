#ifndef BROWSERMAINWINDOW_H
#define BROWSERMAINWINDOW_H

#include <QtGui/QMainWindow>
#include <QtGui/QLineEdit>
#include <QtCore/QUrl>
#include <QtWebKit/QWebView>

namespace Ui
{
    class BrowserMainWindow;
}

class BrowserMainWindow : public QMainWindow
{
    Q_OBJECT

public:
    BrowserMainWindow(QWidget *parent = 0);
    virtual ~BrowserMainWindow();

public slots:
    // Loads the given URL and shows the page in the main QWebView
    void showWebPage(const QUrl& url);

private slots:
    // React to the page load finishing
    void webViewLoadFinished(bool ok);
    // Displays load progress information
    void webViewLoadProgress(int progress);
    // Called when user enters a new URL to the urlLineEdit
    void urlEdited();

private:
    void resizeEvent(QResizeEvent* event);

private:
    Ui::BrowserMainWindow *ui;
    // The main web view
    QWebView* m_activeView;
    // The line edit widget for user URL input
    QLineEdit* m_urlLineEdit;
};

#endif // BROWSERMAINWINDOW_H
