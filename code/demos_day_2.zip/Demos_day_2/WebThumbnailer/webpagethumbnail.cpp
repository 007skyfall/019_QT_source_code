#include <QtGui/QPainter>
#include "webpagethumbnail.h"

WebPageThumbnail::WebPageThumbnail(const QUrl& webSiteUrl, QWidget* parent)
        : QLabel(parent)
{
    // TODO 1) Connect two m_page's signals to existing slots in this class so that
    //    1) we can display the page load progress on this label, and
    //    2) when the contained web page finishes loading, we create
    //       a thumbnail of the page contents and display it.
    connect(&m_page, SIGNAL(loadProgress(int)), this, SLOT(pageLoadProgress(int)));
    connect(&m_page, SIGNAL(loadFinished(bool)), this, SLOT(render()));

    // TODO 2) Disable scroll bars in the contained m_page's main frame
    // [Hint: set the scroll bar policies accordingly]
    m_page.mainFrame()->setScrollBarPolicy(Qt::Horizontal, Qt::ScrollBarAlwaysOff);
    m_page.mainFrame()->setScrollBarPolicy(Qt::Vertical, Qt::ScrollBarAlwaysOff);

    // TODO 3) Start loading the given webSiteUrl
    setUrl(webSiteUrl);
}

WebPageThumbnail::~WebPageThumbnail()
{
    // Nothing to do here
}

void WebPageThumbnail::refresh()
{
    // TODO: Reload m_page by using a suitable function in
    // QWebPage - see the API doc, this might be tricky to figure out!
    m_page.triggerAction(QWebPage::Reload);
}

void WebPageThumbnail::render()
{
    // TODO: 1) Determine the content's size of the page's main frame
    // 2) Set page's viewport size to be e.g. a half or a quarter
    //    of the content's size
    // 3) Also create a QPixmap of that size
    // 4) Initiliaze a QPainter that will draw onto the QPixmap
    // 5) Use page's main frame's render() function to get a thumbnail
    //    of the frame's contents
    // 6) Scale the QPixmap to be 200 pixels wide
    //      - Try both SmoothTransformation and FastTransformation and notice
    //        the considerable difference!
    // 7) Set the QPixmap to this label
    QSize contentsSize = m_page.mainFrame()->contentsSize();
    m_page.setViewportSize(QSize(contentsSize.width(), contentsSize.width()/2));
    QPixmap pixmap(m_page.viewportSize());

    QPainter painter(&pixmap);
    m_page.mainFrame()->render(&painter);

    QPixmap scaledPixmap = pixmap.scaledToWidth(200, Qt::SmoothTransformation);
    setPixmap(scaledPixmap);
}

void WebPageThumbnail::pageLoadProgress(int progress)
{
    setText(QString("Loading... %1%").arg(progress));
}

void WebPageThumbnail::setUrl(const QUrl& newWebSiteUrl)
{
    // Set the given URL the page's main frame
    // (causes also the page to be re-loaded)
    m_page.mainFrame()->setUrl(newWebSiteUrl);
}

void WebPageThumbnail::mouseDoubleClickEvent(QMouseEvent* event)
{
    // Let observer(s) know that this label was double-clicked
    doubleClicked(m_page.mainFrame()->url());
}
