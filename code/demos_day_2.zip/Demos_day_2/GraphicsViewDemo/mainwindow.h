#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QtGui/QMainWindow>
#include <QtGui/QGraphicsEllipseItem>
#include <QtCore/QTimeLine>

namespace Ui
{
    class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void startAnimation();

private:
    Ui::MainWindow *ui;
    QGraphicsEllipseItem* m_ellipse;
    QTimeLine m_timeLine;
};

#endif // MAINWINDOW_H
