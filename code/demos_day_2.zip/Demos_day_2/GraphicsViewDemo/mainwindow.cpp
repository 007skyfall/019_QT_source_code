#include <QtGui/QGraphicsItemAnimation>
#include <QtGui/QGraphicsScene>
#include <QtGui/QLinearGradient>
#include <QtGui/QRadialGradient>
#include <QtCore/QRectF>
#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    connect(ui->startButton, SIGNAL(clicked()), this, SLOT(startAnimation()));


    QGraphicsScene* scene = new QGraphicsScene(0, 0, 450, 350, this);
    ui->graphicsView->setScene(scene);

    QPen pen;
    pen.setWidth(10);
    scene->addRect(0,0,450,350)->setPen(pen);

    QGraphicsEllipseItem* myitem = new QGraphicsEllipseItem(10, 10, 100, 80);
    scene->addItem(myitem);

    m_timeLine.setDuration(3000);
    m_timeLine.setCurveShape(QTimeLine::EaseInOutCurve);
    m_timeLine.setFrameRange(0,200);
    QGraphicsItemAnimation* animation = new QGraphicsItemAnimation;
    animation->setItem(myitem);
    animation->setTimeLine(&m_timeLine);
    animation->setPosAt(0.0,QPointF(10.0, 10.0));
    animation->setPosAt(0.5,QPointF(300.0, 250.0));
    animation->setPosAt(1.0,QPointF(300.0, 10.0));

    QLinearGradient gradient(myitem->rect().topLeft(),
                             myitem->rect().bottomRight());
    gradient.setColorAt(0, Qt::red);
    gradient.setColorAt(0.5, Qt::green);
    gradient.setColorAt(1, Qt::blue);
    myitem->setBrush(gradient);

    QRadialGradient viewGradient(225, 175, 50);
   viewGradient.setSpread(QGradient::RepeatSpread);
    ui->graphicsView->setBackgroundBrush(viewGradient);

    ui->graphicsView->rotate(45);
    ui->graphicsView->scale(0.50, 0.50);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::startAnimation()
{
    m_timeLine.start();
}
